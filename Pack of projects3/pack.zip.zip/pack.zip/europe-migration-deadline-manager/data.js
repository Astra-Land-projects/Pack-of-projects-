window.APP = {
 "slug": "europe-migration-deadline-manager",
 "title": "Europe Migration Deadline Manager",
 "subtitle": "مدیریت ددلاین‌های مهاجرت اروپا",
 "type": "deadlines",
 "desc": "ددلاین‌های اپلای، ویزا، ثبت آدرس، تمدید کارت و بورسیه را با شمارش معکوس، اعلان مرورگر و خروجی تقویم مدیریت کنید.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "deadlines": {
  "presetTitle": "یادآوری از تاریخ ورود",
  "baseLabel": "تاریخ ورود به کشور",
  "presets": [
   {
    "t": "ثبت آدرس (مثلاً Anmeldung آلمان ظرف ۱۴ روز)",
    "off": 14,
    "c": "ویزا/اقامت"
   },
   {
    "t": "درخواست کارت اقامت پیش از پایان اعتبار ویزای D",
    "off": 60,
    "c": "ویزا/اقامت"
   },
   {
    "t": "ثبت بیمه/مالیات/تأمین اجتماعی",
    "off": 30,
    "c": "مالی"
   },
   {
    "t": "Italy: درخواست permesso ظرف ۸ روز کاری",
    "off": 8,
    "c": "ویزا/اقامت"
   }
  ],
  "note": "مهلت‌ها بین کشورها متفاوت است؛ موارد نامرتبط را حذف کنید."
 },
 "id": "astra-europe-migration-deadline-manager",
 "verified": "2026-10-01"
};
