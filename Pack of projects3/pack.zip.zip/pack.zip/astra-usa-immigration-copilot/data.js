window.APP = {
 "slug": "astra-usa-immigration-copilot",
 "title": "Astra USA Immigration Copilot",
 "subtitle": "پروفایل ← مسیرها ← مدارک ← ددلاین ← هزینه ← شغل/دانشگاه ← منابع رسمی",
 "type": "copilot",
 "desc": "پروفایل خود را وارد کنید تا یک داشبورد شخصی ساخته شود؛ دستیار هوشمند با بازیابی از پایگاه دانش منابع رسمی پاسخ می‌دهد و (با API key اختیاری) پاسخ تولیدی مبتنی بر همان منابع می‌سازد.",
 "sources": [
  {
   "t": "USCIS — U.S. Citizenship and Immigration Services",
   "u": "https://www.uscis.gov/"
  },
  {
   "t": "U.S. Department of State — U.S. Visas",
   "u": "https://travel.state.gov/content/travel/en/us-visas.html"
  },
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/"
  },
  {
   "t": "USCIS Fee Schedule (G-1055)",
   "u": "https://www.uscis.gov/g-1055"
  },
  {
   "t": "Visa Bulletin — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
  }
 ],
 "code": "US",
 "country": "USA",
 "questions": [
  {
   "id": "goal",
   "q": "هدف اصلی",
   "options": [
    {
     "v": "visit",
     "l": "سفر کوتاه / تجاری"
    },
    {
     "v": "study",
     "l": "تحصیل"
    },
    {
     "v": "work",
     "l": "کار"
    },
    {
     "v": "family",
     "l": "خانواده"
    },
    {
     "v": "invest",
     "l": "سرمایه‌گذاری / کسب‌وکار"
    },
    {
     "v": "exchange",
     "l": "تبادل / پژوهش / کارآموزی"
    },
    {
     "v": "lottery",
     "l": "لاتاری (DV)"
    }
   ]
  },
  {
   "id": "edu",
   "q": "بالاترین مدرک",
   "options": [
    {
     "v": "hs",
     "l": "دیپلم"
    },
    {
     "v": "ba",
     "l": "کارشناسی"
    },
    {
     "v": "ma",
     "l": "کارشناسی ارشد"
    },
    {
     "v": "phd",
     "l": "دکتری"
    }
   ]
  },
  {
   "id": "offer",
   "q": "پیشنهاد کار از کارفرمای آمریکایی",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "relative",
   "q": "بستگان در آمریکا",
   "options": [
    {
     "v": "usc_spouse",
     "l": "همسر شهروند آمریکا"
    },
    {
     "v": "usc_other",
     "l": "والد/فرزند/خواهر/برادر شهروند"
    },
    {
     "v": "lpr",
     "l": "همسر/والد دارای گرین‌کارت"
    },
    {
     "v": "none",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "talent",
   "q": "دستاورد برجسته (جوایز، مقالات پراستناد، رسانه، داوری)",
   "options": [
    {
     "v": "high",
     "l": "بله، قابل‌توجه"
    },
    {
     "v": "some",
     "l": "تا حدی"
    },
    {
     "v": "no",
     "l": "خیر"
    }
   ]
  },
  {
   "id": "capital",
   "q": "سرمایه قابل سرمایه‌گذاری",
   "options": [
    {
     "v": "none",
     "l": "ندارم"
    },
    {
     "v": "mid",
     "l": "متوسط"
    },
    {
     "v": "large",
     "l": "زیاد (چند صد هزار دلار به بالا)"
    }
   ]
  },
  {
   "id": "nat",
   "q": "تابعیت",
   "options": [
    {
     "v": "vwp",
     "l": "کشور عضو Visa Waiver"
    },
    {
     "v": "canmex",
     "l": "کانادا یا مکزیک"
    },
    {
     "v": "treaty",
     "l": "کشور دارای پیمان E-2"
    },
    {
     "v": "other",
     "l": "سایر کشورها"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "ESTA / Visa Waiver Program",
   "desc": "سفر توریستی/تجاری تا ۹۰ روز برای اتباع کشورهای عضو VWP با مجوز ESTA.",
   "when": {
    "goal": [
     "visit"
    ],
    "nat": [
     "vwp"
    ]
   },
   "steps": [
    "بررسی واجد شرایط بودن کشور در VWP",
    "درخواست ESTA در سایت رسمی CBP",
    "سفر و ثبت I-94"
   ],
   "docs": [
    "گذرنامه الکترونیکی",
    "بلیت/برنامه سفر"
   ],
   "sources": [
    {
     "t": "ESTA — U.S. Customs and Border Protection",
     "u": "https://esta.cbp.dhs.gov/"
    },
    {
     "t": "I-94 Official Website (CBP)",
     "u": "https://i94.cbp.dhs.gov/"
    }
   ],
   "timeline": [
    {
     "t": "درخواست ESTA",
     "days": 3
    },
    {
     "t": "سفر",
     "days": 30
    }
   ],
   "costs": [
    {
     "t": "هزینه ESTA",
     "u": "https://esta.cbp.dhs.gov/"
    }
   ]
  },
  {
   "name": "B-1/B-2 — ویزای بازدید/تجاری",
   "desc": "ویزای غیرمهاجرتی برای سفر کوتاه، توریسم، درمان یا جلسات تجاری.",
   "when": {
    "goal": [
     "visit"
    ]
   },
   "steps": [
    "تکمیل DS-160",
    "پرداخت هزینه MRV",
    "وقت مصاحبه در کنسولگری",
    "مصاحبه و اثبات قصد بازگشت"
   ],
   "docs": [
    "گذرنامه",
    "تأییدیه DS-160",
    "رسید MRV",
    "مدارک مالی",
    "مدارک وابستگی به کشور مبدأ"
   ],
   "sources": [
    {
     "t": "U.S. Department of State — U.S. Visas",
     "u": "https://travel.state.gov/content/travel/en/us-visas.html"
    },
    {
     "t": "DS-160 Online Nonimmigrant Visa Application (CEAC)",
     "u": "https://ceac.state.gov/genniv/"
    },
    {
     "t": "Global Visa Wait Times — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html"
    }
   ],
   "timeline": [
    {
     "t": "DS-160 و پرداخت",
     "days": 7
    },
    {
     "t": "انتظار وقت مصاحبه",
     "days": 90
    },
    {
     "t": "مصاحبه و صدور",
     "days": 14
    }
   ],
   "costs": [
    {
     "t": "MRV fee",
     "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html"
    }
   ]
  },
  {
   "name": "F-1 — ویزای دانشجویی",
   "desc": "تحصیل تمام‌وقت در مؤسسه دارای تأیید SEVP؛ امکان CPT/OPT طبق قوانین.",
   "when": {
    "goal": [
     "study"
    ],
    "edu": [
     "hs",
     "ba",
     "ma"
    ]
   },
   "steps": [
    "پذیرش از مؤسسه SEVP",
    "دریافت فرم I-20",
    "پرداخت SEVIS I-901",
    "DS-160 و مصاحبه",
    "ورود حداکثر ۳۰ روز پیش از شروع دوره"
   ],
   "docs": [
    "گذرنامه",
    "فرم I-20",
    "رسید I-901",
    "مدارک مالی",
    "مدارک تحصیلی و نمرات زبان"
   ],
   "sources": [
    {
     "t": "Study in the States (DHS/SEVP)",
     "u": "https://studyinthestates.dhs.gov/"
    },
    {
     "t": "EducationUSA",
     "u": "https://educationusa.state.gov/"
    },
    {
     "t": "USCIS OPT for F-1 Students",
     "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
    }
   ],
   "timeline": [
    {
     "t": "اپلای و پذیرش",
     "days": 150
    },
    {
     "t": "I-20 و SEVIS",
     "days": 30
    },
    {
     "t": "وقت سفارت و مصاحبه",
     "days": 75
    },
    {
     "t": "ورود",
     "days": 30
    }
   ],
   "costs": [
    {
     "t": "SEVIS I-901",
     "u": "https://www.fmjfee.com/"
    },
    {
     "t": "MRV fee",
     "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html"
    }
   ]
  },
  {
   "name": "J-1 — تبادل/پژوهش",
   "desc": "برنامه‌های تبادل فرهنگی و پژوهشی با اسپانسر تأییدشده (DS-2019). برخی برنامه‌ها مشمول الزام دو سال اقامت خانگی هستند.",
   "when": {
    "goal": [
     "exchange",
     "study"
    ]
   },
   "steps": [
    "پذیرش در برنامه اسپانسر J",
    "دریافت DS-2019",
    "پرداخت SEVIS",
    "DS-160 و مصاحبه"
   ],
   "docs": [
    "DS-2019",
    "رسید SEVIS",
    "گذرنامه",
    "مدارک مالی"
   ],
   "sources": [
    {
     "t": "J-1 Visa — travel.state.gov",
     "u": "https://j1visa.state.gov/"
    },
    {
     "t": "U.S. Department of State — U.S. Visas",
     "u": "https://travel.state.gov/content/travel/en/us-visas.html"
    }
   ],
   "timeline": [
    {
     "t": "پذیرش برنامه",
     "days": 90
    },
    {
     "t": "DS-2019",
     "days": 30
    },
    {
     "t": "مصاحبه",
     "days": 60
    }
   ]
  },
  {
   "name": "H-1B — کار تخصصی",
   "desc": "شغل تخصصی نیازمند حداقل کارشناسی؛ کارفرما اسپانسر است و در بیشتر موارد ثبت‌نام در قرعه سالانه لازم است. قواعد و هزینه‌های جدید را از منبع رسمی بررسی کنید.",
   "when": {
    "goal": [
     "work"
    ],
    "edu": [
     "ba",
     "ma",
     "phd"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "کارفرما ثبت‌نام الکترونیکی cap را انجام می‌دهد (معمولاً مارس)",
    "در صورت انتخاب: LCA و فرم I-129",
    "تأیید و ویزا/تغییر وضعیت",
    "شروع کار از ۱ اکتبر برای cap"
   ],
   "docs": [
    "مدرک تحصیلی و ارزیابی معادل‌سازی",
    "رزومه و نامه پیشنهاد کار",
    "گذرنامه"
   ],
   "sources": [
    {
     "t": "USCIS H-1B Specialty Occupations",
     "u": "https://www.uscis.gov/working-in-the-united-states/h-1b-specialty-occupations"
    },
    {
     "t": "USCIS H-1B Employer Data Hub",
     "u": "https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub"
    }
   ],
   "timeline": [
    {
     "t": "ثبت‌نام cap",
     "days": 30
    },
    {
     "t": "اعلام نتایج",
     "days": 30
    },
    {
     "t": "ثبت I-129",
     "days": 90
    },
    {
     "t": "تأیید",
     "days": 90
    },
    {
     "t": "شروع کار",
     "days": 90
    }
   ],
   "costs": [
    {
     "t": "I-129 و هزینه‌های کارفرما",
     "u": "https://www.uscis.gov/g-1055"
    }
   ]
  },
  {
   "name": "L-1 — انتقال درون‌شرکتی",
   "desc": "مدیر یا متخصص با حداقل یک سال کار پیوسته در شرکت وابسته خارج از آمریکا در سه سال اخیر.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "تأیید رابطه شرکت‌ها",
    "I-129 توسط شرکت آمریکایی",
    "ویزا"
   ],
   "docs": [
    "سوابق کار در شرکت مادر",
    "ساختار شرکت‌ها"
   ],
   "sources": [
    {
     "t": "USCIS L-1A",
     "u": "https://www.uscis.gov/working-in-the-united-states/temporary-workers/l-1a-intracompany-transferee-executive-or-manager"
    }
   ]
  },
  {
   "name": "O-1 — توانایی خارق‌العاده",
   "desc": "برای افراد دارای دستاورد برجسته پایدار در علوم، هنر، آموزش، کسب‌وکار یا ورزش؛ نیاز به کارفرما یا agent.",
   "when": {
    "goal": [
     "work"
    ],
    "talent": [
     "high"
    ]
   },
   "steps": [
    "جمع‌آوری شواهد طبق معیارها",
    "Advisory opinion",
    "I-129"
   ],
   "docs": [
    "جوایز",
    "مقالات/استنادها",
    "پوشش رسانه‌ای",
    "نامه‌های حمایتی"
   ],
   "sources": [
    {
     "t": "USCIS O-1",
     "u": "https://www.uscis.gov/working-in-the-united-states/temporary-workers/o-1-visa-individuals-with-extraordinary-ability-or-achievement"
    }
   ]
  },
  {
   "name": "TN — کانادا/مکزیک (USMCA)",
   "desc": "برای شهروندان کانادا و مکزیک در فهرست مشاغل USMCA با پیشنهاد کار.",
   "when": {
    "goal": [
     "work"
    ],
    "nat": [
     "canmex"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "نامه پیشنهاد کار",
    "درخواست در مرز/کنسولگری (بسته به تابعیت)"
   ],
   "docs": [
    "نامه کارفرما",
    "مدرک تحصیلی"
   ],
   "sources": [
    {
     "t": "USCIS TN NAFTA/USMCA Professionals",
     "u": "https://www.uscis.gov/working-in-the-united-states/temporary-workers/tn-usmca-professionals"
    }
   ]
  },
  {
   "name": "E-2 — سرمایه‌گذار پیمانی",
   "desc": "سرمایه‌گذاری قابل‌توجه در کسب‌وکار آمریکایی برای اتباع کشورهای دارای پیمان.",
   "when": {
    "goal": [
     "invest"
    ],
    "nat": [
     "treaty"
    ],
    "capital": [
     "mid",
     "large"
    ]
   },
   "steps": [
    "بررسی کشور در فهرست پیمان",
    "ثبت و سرمایه‌گذاری کسب‌وکار",
    "درخواست کنسولی E-2"
   ],
   "docs": [
    "طرح کسب‌وکار",
    "اثبات منبع سرمایه",
    "اسناد شرکت"
   ],
   "sources": [
    {
     "t": "E-2 Treaty Investors",
     "u": "https://www.uscis.gov/working-in-the-united-states/temporary-workers/e-2-treaty-investors"
    },
    {
     "t": "Treaty Countries",
     "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/treaty.html"
    }
   ]
  },
  {
   "name": "EB-1 — اولویت اول اشتغال",
   "desc": "افراد با توانایی خارق‌العاده، استاد/پژوهشگر برجسته، یا مدیر چندملیتی. EB-1A نیاز به کارفرما ندارد.",
   "when": {
    "goal": [
     "work"
    ],
    "talent": [
     "high"
    ]
   },
   "steps": [
    "آماده‌سازی شواهد",
    "I-140",
    "انتظار تاریخ اولویت در Visa Bulletin",
    "I-485 یا مصاحبه کنسولی"
   ],
   "docs": [
    "شواهد دستاورد",
    "نامه‌های تخصصی",
    "مدارک هویتی"
   ],
   "sources": [
    {
     "t": "USCIS EB-1",
     "u": "https://www.uscis.gov/working-in-the-united-states/permanent-workers/employment-based-immigration-first-preference-eb-1"
    },
    {
     "t": "Visa Bulletin — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    }
   ],
   "timeline": [
    {
     "t": "آماده‌سازی پرونده",
     "days": 90
    },
    {
     "t": "I-140",
     "days": 180
    },
    {
     "t": "انتظار تاریخ اولویت",
     "days": 180
    },
    {
     "t": "I-485 / کنسولی",
     "days": 300
    }
   ],
   "costs": [
    {
     "t": "I-140 / I-485",
     "u": "https://www.uscis.gov/g-1055"
    }
   ]
  },
  {
   "name": "EB-2 NIW — معافیت منافع ملی",
   "desc": "مدرک پیشرفته یا توانایی استثنایی + کاری با اهمیت ملی؛ نیاز به پیشنهاد کار و Labor Certification ندارد (چارچوب Dhanasar).",
   "when": {
    "goal": [
     "work"
    ],
    "edu": [
     "ma",
     "phd"
    ],
    "talent": [
     "high",
     "some"
    ]
   },
   "steps": [
    "تعریف proposed endeavor",
    "جمع‌آوری شواهد سه شاخه Dhanasar",
    "I-140",
    "تاریخ اولویت و I-485"
   ],
   "docs": [
    "مدارک تحصیلی",
    "طرح کاری",
    "نامه‌های توصیه",
    "سوابق انتشار/پروژه"
   ],
   "sources": [
    {
     "t": "USCIS EB-2 / NIW",
     "u": "https://www.uscis.gov/working-in-the-united-states/permanent-workers/employment-based-immigration-second-preference-eb-2"
    },
    {
     "t": "Visa Bulletin — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    }
   ],
   "timeline": [
    {
     "t": "آماده‌سازی",
     "days": 90
    },
    {
     "t": "I-140",
     "days": 240
    },
    {
     "t": "انتظار Visa Bulletin",
     "days": 365
    },
    {
     "t": "I-485 / کنسولی",
     "days": 300
    }
   ],
   "costs": [
    {
     "t": "I-140 / I-485",
     "u": "https://www.uscis.gov/g-1055"
    }
   ]
  },
  {
   "name": "EB-2/EB-3 با PERM",
   "desc": "گرین‌کارت کاری با اسپانسر کارفرما و گواهی کار (PERM) از وزارت کار.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ],
    "edu": [
     "ba",
     "ma",
     "phd"
    ]
   },
   "steps": [
    "Prevailing wage",
    "فرآیند استخدام و PERM",
    "I-140",
    "تاریخ اولویت و I-485"
   ],
   "docs": [
    "نامه کارفرما",
    "مدارک تحصیلی و سوابق کار"
   ],
   "sources": [
    {
     "t": "DOL OFLC Performance Data (LCA/PERM disclosure)",
     "u": "https://www.dol.gov/agencies/eta/foreign-labor/performance"
    },
    {
     "t": "USCIS Green Card",
     "u": "https://www.uscis.gov/green-card"
    },
    {
     "t": "Visa Bulletin — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    }
   ],
   "timeline": [
    {
     "t": "Prevailing wage",
     "days": 180
    },
    {
     "t": "Recruitment",
     "days": 60
    },
    {
     "t": "PERM",
     "days": 450
    },
    {
     "t": "I-140",
     "days": 180
    },
    {
     "t": "I-485",
     "days": 300
    }
   ]
  },
  {
   "name": "EB-5 — سرمایه‌گذار مهاجر",
   "desc": "سرمایه‌گذاری در کسب‌وکار جدید آمریکایی و ایجاد شغل؛ مبالغ حداقلی را از USCIS ببینید.",
   "when": {
    "goal": [
     "invest"
    ],
    "capital": [
     "large"
    ]
   },
   "steps": [
    "انتخاب پروژه (مستقیم یا Regional Center)",
    "I-526E",
    "گرین‌کارت مشروط",
    "I-829"
   ],
   "docs": [
    "اثبات منبع قانونی سرمایه",
    "اسناد پروژه"
   ],
   "sources": [
    {
     "t": "USCIS EB-5",
     "u": "https://www.uscis.gov/working-in-the-united-states/permanent-workers/eb-5-immigrant-investor-program"
    }
   ]
  },
  {
   "name": "IR-1/CR-1 / I-130 همسر شهروند",
   "desc": "گرین‌کارت از طریق همسر شهروند آمریکا (بستگان نزدیک؛ بدون انتظار سهمیه).",
   "when": {
    "goal": [
     "family"
    ],
    "relative": [
     "usc_spouse"
    ]
   },
   "steps": [
    "I-130 توسط همسر",
    "NVC یا I-485 (در صورت حضور قانونی در آمریکا)",
    "مصاحبه",
    "در ازدواج کمتر از ۲ سال: گرین‌کارت مشروط و I-751"
   ],
   "docs": [
    "سند ازدواج",
    "شواهد واقعی بودن ازدواج",
    "I-864 حمایت مالی",
    "گذرنامه، شناسنامه"
   ],
   "sources": [
    {
     "t": "USCIS Family of U.S. Citizens / LPRs",
     "u": "https://www.uscis.gov/family"
    },
    {
     "t": "USCIS I-130",
     "u": "https://www.uscis.gov/i-130"
    }
   ],
   "timeline": [
    {
     "t": "I-130",
     "days": 365
    },
    {
     "t": "NVC / I-485",
     "days": 120
    },
    {
     "t": "مصاحبه",
     "days": 120
    }
   ],
   "costs": [
    {
     "t": "I-130 / I-485 / I-864",
     "u": "https://www.uscis.gov/g-1055"
    }
   ]
  },
  {
   "name": "اسپانسری خانوادگی سهمیه‌ای (F1–F4)",
   "desc": "فرزندان/والدین/خواهر و برادر شهروندان یا بستگان دارای گرین‌کارت؛ مشمول انتظار Visa Bulletin.",
   "when": {
    "goal": [
     "family"
    ],
    "relative": [
     "usc_other",
     "lpr"
    ]
   },
   "steps": [
    "I-130",
    "انتظار تاریخ اولویت",
    "NVC و مصاحبه"
   ],
   "docs": [
    "اثبات نسبت",
    "مدارک هویتی",
    "I-864"
   ],
   "sources": [
    {
     "t": "USCIS Family of U.S. Citizens / LPRs",
     "u": "https://www.uscis.gov/family"
    },
    {
     "t": "Visa Bulletin — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    }
   ]
  },
  {
   "name": "Diversity Visa (لاتاری)",
   "desc": "قرعه‌کشی سالانه برای اتباع کشورهای واجد شرایط؛ ثبت‌نام فقط در سایت رسمی dvprogram.state.gov و رایگان است.",
   "when": {
    "goal": [
     "lottery"
    ],
    "edu": [
     "hs",
     "ba",
     "ma",
     "phd"
    ]
   },
   "steps": [
    "ثبت‌نام در بازه رسمی (معمولاً پاییز)",
    "بررسی نتیجه با Confirmation Number",
    "DS-260 و مصاحبه در صورت انتخاب"
   ],
   "docs": [
    "گذرنامه",
    "عکس طبق مشخصات",
    "مدرک تحصیلی یا سابقه کار"
   ],
   "sources": [
    {
     "t": "Diversity Visa Program — travel.state.gov",
     "u": "https://travel.state.gov/content/travel/en/us-visas/immigrate/diversity-visa-program-entry.html"
    }
   ],
   "timeline": [
    {
     "t": "ثبت‌نام",
     "days": 30
    },
    {
     "t": "اعلام نتایج (معمولاً مه)",
     "days": 210
    },
    {
     "t": "DS-260 و انتظار نوبت",
     "days": 180
    },
    {
     "t": "مصاحبه",
     "days": 90
    }
   ]
  }
 ],
 "kb": [
  {
   "t": "شماره رسید USCIS",
   "text": "شماره رسید ۱۳ کاراکتر است: ۳ حرف (مثل IOE، EAC، WAC، LIN، SRC، MSC) و ۱۰ رقم؛ روی فرم I-797 درج می‌شود و در Case Status Online استفاده می‌شود.",
   "u": "https://egov.uscis.gov/",
   "k": "receipt case status i-797"
  },
  {
   "t": "Processing Times",
   "text": "زمان‌های رسیدگی هر فرم بر اساس دفتر (Service Center/Field Office) در صفحه Check Case Processing Times منتشر می‌شود؛ اگر پرونده خارج از بازه عادی باشد می‌توان e-Request ثبت کرد.",
   "u": "https://egov.uscis.gov/processing-times/",
   "k": "processing time inquiry outside normal"
  },
  {
   "t": "F-1 ورود",
   "text": "دانشجویان F-1 جدید می‌توانند حداکثر ۳۰ روز پیش از تاریخ شروع برنامه درج‌شده در I-20 وارد آمریکا شوند.",
   "u": "https://studyinthestates.dhs.gov/",
   "k": "f-1 student i-20 arrival 30 days"
  },
  {
   "t": "OPT",
   "text": "OPT تا ۱۲ ماه مجوز کار مرتبط با رشته برای F-1 است؛ رشته‌های STEM امکان تمدید ۲۴ ماهه دارند. درخواست post-completion OPT از ۹۰ روز پیش از پایان تحصیل تا ۶۰ روز پس از آن قابل ثبت است.",
   "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students",
   "k": "opt stem work after study"
  },
  {
   "t": "H-1B cap",
   "text": "سقف سالانه H-1B معمولاً ۶۵ هزار به‌علاوه ۲۰ هزار برای دارندگان مدرک ارشد آمریکایی است و از طریق ثبت‌نام الکترونیکی و انتخاب انجام می‌شود. تغییرات قوانین و هزینه‌های جدید را از USCIS بررسی کنید.",
   "u": "https://www.uscis.gov/working-in-the-united-states/temporary-workers/h-1b-specialty-occupations/h-1b-electronic-registration-process",
   "k": "h1b lottery registration cap"
  },
  {
   "t": "Visa Bulletin",
   "text": "برای گرین‌کارت‌های سهمیه‌ای، تاریخ اولویت باید در جدول Final Action Dates یا Dates for Filing ماهانه Visa Bulletin جاری باشد.",
   "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html",
   "k": "priority date bulletin green card"
  },
  {
   "t": "ESTA",
   "text": "اتباع کشورهای عضو Visa Waiver Program برای سفر توریستی/تجاری تا ۹۰ روز به‌جای ویزا ESTA می‌گیرند؛ فقط از سایت رسمی esta.cbp.dhs.gov.",
   "u": "https://esta.cbp.dhs.gov/",
   "k": "esta vwp visa waiver"
  },
  {
   "t": "DS-160",
   "text": "فرم DS-160 برای همه ویزاهای غیرمهاجرتی (B، F، J، H و…) آنلاین در CEAC تکمیل می‌شود و صفحه تأیید آن در مصاحبه لازم است.",
   "u": "https://ceac.state.gov/genniv/",
   "k": "ds-160 nonimmigrant form interview"
  },
  {
   "t": "SEVIS I-901",
   "text": "دانشجویان F/M و شرکت‌کنندگان J باید هزینه SEVIS I-901 را پیش از مصاحبه ویزا پرداخت کنند.",
   "u": "https://www.fmjfee.com/",
   "k": "sevis fee i-901"
  },
  {
   "t": "N-400 شهروندی",
   "text": "به‌طور کلی پس از ۵ سال اقامت دائم (یا ۳ سال در صورت ازدواج با شهروند و زندگی مشترک) و احراز شرایط حضور فیزیکی، می‌توان N-400 ثبت کرد.",
   "u": "https://www.uscis.gov/n-400",
   "k": "citizenship naturalization n-400"
  },
  {
   "t": "I-751",
   "text": "دارندگان گرین‌کارت مشروط ازدواج باید در ۹۰ روز پیش از سالگرد دو سالگی کارت، I-751 را برای رفع شرط ثبت کنند.",
   "u": "https://www.uscis.gov/i-751",
   "k": "conditional green card remove conditions"
  },
  {
   "t": "EB-2 NIW",
   "text": "در NIW متقاضی می‌تواند خودش I-140 ثبت کند و از پیشنهاد کار و PERM معاف شود اگر طبق چارچوب Matter of Dhanasar نشان دهد کارش شایستگی و اهمیت ملی دارد، در جایگاه خوبی برای پیشبرد آن است و معافیت به نفع آمریکاست.",
   "u": "https://www.uscis.gov/working-in-the-united-states/permanent-workers/employment-based-immigration-second-preference-eb-2",
   "k": "niw national interest waiver dhanasar"
  },
  {
   "t": "ترجمه مدارک",
   "text": "هر سند به زبان خارجی ارسالی به USCIS باید ترجمه کامل انگلیسی همراه با گواهی مترجم مبنی بر صلاحیت و صحت ترجمه داشته باشد.",
   "u": "https://www.ecfr.gov/current/title-8/chapter-I/subchapter-B/part-103/subpart-A/section-103.2",
   "k": "translation certified documents"
  },
  {
   "t": "هزینه‌ها",
   "text": "هزینه‌های رسمی USCIS در فرم G-1055 و Fee Calculator اعلام می‌شوند؛ USCIS تعدیل تورمی برخی هزینه‌ها را از ۱۶ اکتبر ۲۰۲۶ اعلام کرده است.",
   "u": "https://www.uscis.gov/newsroom/alerts/uscis-announces-fy-2027-inflation-increase-for-certain-immigration-related-fees",
   "k": "fee cost price g-1055"
  },
  {
   "t": "I-94",
   "text": "I-94 سابقه ورود/خروج و مدت مجاز اقامت است و از سایت رسمی CBP قابل دریافت است.",
   "u": "https://i94.cbp.dhs.gov/",
   "k": "i-94 admission record stay"
  },
  {
   "t": "لاتاری DV",
   "text": "ثبت‌نام Diversity Visa رایگان و فقط از وب‌سایت رسمی وزارت خارجه انجام می‌شود؛ ایمیل‌هایی که ادعای برنده‌شدن دارند معمولاً کلاهبرداری‌اند.",
   "u": "https://travel.state.gov/content/travel/en/us-visas/immigrate/diversity-visa-program-entry.html",
   "k": "dv lottery green card scam"
  }
 ],
 "opportunities": [
  {
   "t": "EducationUSA",
   "u": "https://educationusa.state.gov/",
   "d": "انتخاب دانشگاه"
  },
  {
   "t": "Study in the States",
   "u": "https://studyinthestates.dhs.gov/",
   "d": "مدارس دارای تأیید SEVP"
  },
  {
   "t": "H-1B Employer Data Hub",
   "u": "https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub",
   "d": "کارفرمایان اسپانسر"
  },
  {
   "t": "LinkedIn — visa sponsorship",
   "u": "https://www.linkedin.com/jobs/search/?keywords=visa%20sponsorship",
   "d": "جست‌وجوی شغل"
  }
 ],
 "id": "astra-astra-usa-immigration-copilot",
 "verified": "2026-10-01"
};
