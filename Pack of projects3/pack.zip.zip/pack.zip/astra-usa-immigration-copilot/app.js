/* Astra Global Migration — standalone tool engine (no build step, no server).
   Every project folder ships its own copy of this file + data.js, so each tool runs independently. */
(function () {
'use strict';
const A = window.APP;
const R = {};
const GATE = A.gate || ['goal', 'purpose', 'dest'];
/* ---------- helpers ---------- */
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k === 'value') e.value = v;
    else if (k === 'checked' || k === 'selected') e[k] = !!v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat(3)) { if (k == null || k === false) continue; e.append(k.nodeType ? k : document.createTextNode(String(k))); }
  return e;
}
const S = {
  get(k, d) { try { const v = localStorage.getItem(A.id + ':' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(A.id + ':' + k, JSON.stringify(v)); } catch (e) { alert('ذخیره‌سازی محلی ممکن نیست: ' + e.message); } }
};
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const today = () => new Date().toISOString().slice(0, 10);
function addDays(iso, n) { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + Number(n || 0)); return d.toISOString().slice(0, 10); }
function daysBetween(a, b) { return Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 864e5); }
function fmt(iso) {
  if (!iso) return '—';
  try { const d = new Date(iso + 'T12:00:00'); return iso + ' (' + d.toLocaleDateString('fa-IR-u-ca-persian', { year: 'numeric', month: 'short', day: 'numeric' }) + ')'; } catch (e) { return iso; }
}
const num = (n, c) => (isFinite(n) ? Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 }) : '—') + (c ? ' ' + c : '');
function download(name, text, type) { const b = new Blob([text], { type: type || 'text/plain;charset=utf-8' }); const a = h('a', { href: URL.createObjectURL(b), download: name }); document.body.append(a); a.click(); a.remove(); }
function icsEsc(s) { return String(s || '').replace(/[\\;,]/g, m => '\\' + m).replace(/\n/g, '\\n'); }
function ics(events) {
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Astra Global Migration//' + A.id, 'CALSCALE:GREGORIAN'];
  const stamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  events.filter(e => e.date).forEach((e, i) => {
    const d = e.date.replace(/-/g, ''), n = addDays(e.date, 1).replace(/-/g, '');
    L.push('BEGIN:VEVENT', 'UID:' + A.id + '-' + i + '-' + d + '@astra', 'DTSTAMP:' + stamp, 'DTSTART;VALUE=DATE:' + d, 'DTEND;VALUE=DATE:' + n,
      'SUMMARY:' + icsEsc(e.title), 'DESCRIPTION:' + icsEsc(e.desc), 'BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY', 'DESCRIPTION:' + icsEsc(e.title), 'END:VALARM', 'END:VEVENT');
  });
  L.push('END:VCALENDAR'); return L.join('\r\n');
}
const btn = (t, f, cls) => h('button', { class: cls || '', onclick: f, type: 'button' }, t);
const card = (t, ...k) => h('section', { class: 'card' }, t ? h('h2', {}, t) : null, ...k);
const field = (l, el) => h('label', { class: 'field' }, h('span', {}, l), el);
const link = s => h('a', { href: s.u, target: '_blank', rel: 'noopener' }, s.t || s.u);
const norm = x => typeof x === 'string' ? { t: x } : x;
function notify(title, body) {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'granted') new Notification(title, { body });
}
function askNotify() { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); }
function readFile(file, cb) { const r = new FileReader(); r.onload = () => cb(r.result); r.readAsText(file); }
function parseCSV(text) {
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); rows.push(row); row = []; cur = ''; }
    else cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim() !== ''));
}
const toCSV = rows => rows.map(r => r.map(v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\n');
const STOP = new Set('a an the and or of to in on for with by at from as is are be will you your we our this that it its can may must should have has who what their they them us not into using use per via etc job role work team years year experience strong ability skills skill including within across other such also more than all any about'.split(' '));
const tokens = t => (t.toLowerCase().match(/[a-z][a-z0-9+#.\-]{1,}/g) || []).map(w => w.replace(/[.\-]+$/, '')).filter(w => w.length > 1 && !STOP.has(w));
function routeCard(r, score, extra) {
  const pct = Math.round(score * 100);
  return h('div', { class: 'route' + (score === 0 ? ' faded' : '') },
    h('header', {}, h('h3', {}, r.name), score != null ? h('span', { class: 'badge' }, 'مطابقت اولیه ' + pct + '%') : null),
    r.desc ? h('p', {}, r.desc) : null,
    extra && extra.length ? h('p', { class: 'muted' }, 'موارد نامنطبق یا نیازمند بررسی: ' + extra.join('، ')) : null,
    r.steps ? h('details', { open: score >= 0.99 }, h('summary', {}, 'مراحل کلی'), h('ol', {}, r.steps.map(s => h('li', {}, typeof s === 'string' ? s : s.t)))) : null,
    r.docs ? h('details', {}, h('summary', {}, 'مدارک معمول'), h('ul', {}, r.docs.map(d => h('li', {}, d)))) : null,
    r.sources ? h('p', {}, 'منابع رسمی: ', r.sources.map((s, i) => [i ? ' · ' : '', link(s)])) : null);
}

/* ---------- 1. navigator ---------- */
R.navigator = (root) => {
  const ans = S.get('ans', {});
  const form = h('div', { class: 'grid2' });
  A.questions.forEach(q => {
    const sel = h('select', { onchange: e => { ans[q.id] = e.target.value; S.set('ans', ans); run(); } },
      h('option', { value: '' }, '— انتخاب کنید —'), q.options.map(o => h('option', { value: o.v, selected: ans[q.id] === o.v }, o.l)));
    form.append(field(q.q, sel));
  });
  const out = h('div');
  root.append(card(A.formTitle || 'شرایط شما', form, h('div', { class: 'row' },
    btn('پاک کردن پاسخ‌ها', () => { Object.keys(ans).forEach(k => delete ans[k]); S.set('ans', ans); location.reload(); }, 'ghost'),
    btn('خروجی گزارش', exportR, 'ghost'), btn('چاپ', () => print(), 'ghost'))), card('نتایج (مطابقت اولیه با معیارهای منتشرشده)', out));
  let last = [];
  function run() {
    out.innerHTML = '';
    if (!Object.values(ans).some(Boolean)) { out.append(h('p', { class: 'muted' }, 'به سؤال‌ها پاسخ دهید تا مسیرهای مرتبط رتبه‌بندی شوند.')); return; }
    last = A.routes.map(r => {
      let met = 0, tot = 0; const miss = [];
      Object.entries(r.when || {}).forEach(([k, vals]) => { if (!ans[k]) return; tot++; if (vals.includes(ans[k])) met++; else { const q = A.questions.find(q => q.id === k); miss.push(q ? q.q : k); } });
      const ex = Object.entries(r.not || {}).some(([k, vals]) => vals.includes(ans[k])) || GATE.some(k => r.when && r.when[k] && ans[k] && !r.when[k].includes(ans[k]));
      return { r, score: ex ? 0 : (tot ? met / tot : 0), miss };
    }).sort((a, b) => b.score - a.score);
    last.forEach(x => out.append(routeCard(x.r, x.score, x.miss)));
  }
  function exportR() {
    const t = [A.title, 'تاریخ: ' + today(), '', ...A.questions.map(q => q.q + ': ' + ((q.options.find(o => o.v === ans[q.id]) || {}).l || '—')), '',
      ...last.map(x => `${Math.round(x.score * 100)}% — ${x.r.name}\n  ${x.r.desc || ''}\n  ${(x.r.sources || []).map(s => s.u).join(' ')}`)].join('\n');
    download(A.id + '-report.txt', t);
  }
  run();
};

/* ---------- 2. checklist ---------- */
R.checklist = (root) => {
  const keys = Object.keys(A.cases);
  let cur = S.get('case', keys[0]); if (!A.cases[cur]) cur = keys[0];
  const st = S.get('st', {}), custom = S.get('custom', {});
  const sel = h('select', { onchange: e => { cur = e.target.value; S.set('case', cur); draw(); } }, keys.map(k => h('option', { value: k, selected: k === cur }, A.cases[k].label)));
  const list = h('div'), prog = h('div', { class: 'progress' }, h('i')), ptxt = h('b'), inp = h('input', { placeholder: 'افزودن مدرک دلخواه…' }), info = h('p', { class: 'muted' });
  root.append(card('نوع پرونده / هدف', sel, info, h('div', { class: 'row' }, prog, ptxt)),
    card('چک‌لیست مدارک', list, h('div', { class: 'row' }, inp,
      btn('افزودن', () => { const v = inp.value.trim(); if (!v) return; (custom[cur] = custom[cur] || []).push(v); S.set('custom', custom); inp.value = ''; draw(); }),
      btn('خروجی متن', exp, 'ghost'), btn('چاپ', () => print(), 'ghost'), btn('ریست', () => { if (confirm('همه تیک‌ها پاک شود؟')) { st[cur] = {}; S.set('st', st); draw(); } }, 'danger'))));
  const items = () => { const c = A.cases[cur]; return [...(A.common || []).map(x => ({ ...norm(x), g: 'مدارک عمومی' })), ...c.items.map(x => ({ ...norm(x), g: c.label })), ...(custom[cur] || []).map(x => ({ t: x, g: 'موارد دلخواه شما' }))]; };
  function draw() {
    const c = A.cases[cur]; info.innerHTML = ''; if (c.desc) info.append(c.desc + ' '); if (c.source) info.append(link(c.source));
    list.innerHTML = ''; const s = st[cur] = st[cur] || {}; const it = items(); let done = 0, g0;
    it.forEach(x => {
      const key = x.g + '|' + x.t; if (s[key]) done++;
      if (x.g !== g0) { g0 = x.g; list.append(h('h4', {}, x.g)); }
      list.append(h('label', { class: 'check' + (s[key] ? ' done' : '') }, h('input', { type: 'checkbox', checked: !!s[key], onchange: e => { s[key] = e.target.checked; S.set('st', st); draw(); } }),
        h('span', {}, x.t, x.opt ? h('em', { class: 'tag warn' }, 'در صورت نیاز') : null, x.note ? h('small', {}, x.note) : null)));
    });
    const p = it.length ? Math.round(done / it.length * 100) : 0; prog.firstChild.style.width = p + '%'; ptxt.textContent = `${done} از ${it.length} (${p}%)`;
  }
  function exp() { const s = st[cur] || {}; download(A.id + '-checklist.txt', A.title + ' — ' + A.cases[cur].label + '\n\n' + items().map(x => (s[x.g + '|' + x.t] ? '[x] ' : '[ ] ') + x.t).join('\n')); }
  draw();
};

/* ---------- 3. tracker ---------- */
R.tracker = (root) => {
  const T = A.tracker; let cases = S.get('cases', []);
  const f = { label: h('input', { placeholder: 'مثلاً: پرونده کار من' }), ref: h('input', { placeholder: T.refHint, class: 'ltr' }),
    type: h('select', {}, T.caseTypes.map(t => h('option', {}, t))), filed: h('input', { type: 'date', value: today() }),
    status: h('select', {}, T.statuses.map(t => h('option', {}, t))), remind: h('input', { type: 'date' }), note: h('input', { placeholder: 'یادداشت' }) };
  const msg = h('p', { class: 'muted' }), list = h('div'), alerts = h('div');
  root.append(alerts, card('افزودن پرونده', h('div', { class: 'grid2' }, field('عنوان', f.label), field(T.refLabel, f.ref), field('نوع', f.type), field('تاریخ ثبت', f.filed), field('وضعیت فعلی', f.status), field('یادآوری بعدی', f.remind), field('یادداشت', f.note)),
    msg, h('div', { class: 'row' }, btn('ثبت پرونده', add), btn('خروجی JSON', () => download(A.id + '-cases.json', JSON.stringify(cases, null, 2), 'application/json'), 'ghost'),
      h('label', { class: 'btn ghost' }, 'ورود JSON', h('input', { type: 'file', accept: '.json', hidden: true, onchange: e => readFile(e.target.files[0], t => { try { cases = JSON.parse(t); save(); } catch (er) { alert('فایل نامعتبر'); } }) })),
      btn('خروجی تقویم (ICS)', () => download(A.id + '-reminders.ics', ics(cases.filter(c => c.remind).map(c => ({ date: c.remind, title: 'پیگیری: ' + c.label, desc: c.ref }))), 'text/calendar'), 'ghost'),
      btn('فعال‌سازی اعلان', askNotify, 'ghost'))), card('پرونده‌های من', list));
  function add() {
    const ref = f.ref.value.trim().toUpperCase().replace(/\s/g, '');
    if (T.refRegex && ref && !new RegExp(T.refRegex).test(ref)) { msg.textContent = 'قالب شماره معتبر نیست: ' + T.refHint; msg.style.color = 'var(--bad)'; return; }
    cases.unshift({ id: uid(), label: f.label.value || ref || 'پرونده', ref, type: f.type.value, filed: f.filed.value, remind: f.remind.value, note: f.note.value, history: [{ date: f.filed.value || today(), status: f.status.value, note: f.note.value }] });
    msg.textContent = 'ثبت شد.'; msg.style.color = 'var(--ok)'; save();
  }
  function save() { S.set('cases', cases); draw(); }
  function draw() {
    list.innerHTML = ''; alerts.innerHTML = '';
    if (!cases.length) list.append(h('p', { class: 'muted' }, 'هنوز پرونده‌ای ثبت نشده است. داده‌ها فقط در مرورگر شما ذخیره می‌شوند.'));
    cases.forEach(c => {
      c.history.sort((a, b) => a.date.localeCompare(b.date));
      const curS = c.history[c.history.length - 1];
      const due = c.remind && c.remind <= today();
      if (due) { alerts.append(h('div', { class: 'note' }, 'یادآوری سررسید شده: ' + c.label + ' (' + c.remind + ')')); notify('یادآوری پرونده', c.label); }
      const ns = h('select', {}, T.statuses.map(t => h('option', {}, t))), nd = h('input', { type: 'date', value: today() }), nn = h('input', { placeholder: 'یادداشت' });
      const tl = h('div', { class: 'tl' }, c.history.map((e, i) => h('div', { class: 'ev' + (i === c.history.length - 1 ? '' : ' done') }, h('b', {}, e.status), ' — ', fmt(e.date),
        i ? h('span', { class: 'tag' }, '+' + daysBetween(c.history[i - 1].date, e.date) + ' روز') : null, e.note ? h('div', { class: 'muted' }, e.note) : null)));
      list.append(h('div', { class: 'route' }, h('header', {}, h('h3', {}, c.label), h('span', { class: 'badge' }, curS.status)),
        h('div', { class: 'kpis' }, h('div', { class: 'kpi' }, 'شماره', h('b', { class: 'ltr' }, c.ref || '—')), h('div', { class: 'kpi' }, 'نوع', h('b', {}, c.type)),
          h('div', { class: 'kpi' }, 'روز از ثبت', h('b', {}, c.filed ? daysBetween(c.filed, today()) : '—')), h('div', { class: 'kpi' }, 'یادآوری', h('b', {}, c.remind || '—'))),
        h('h4', {}, 'تاریخچه وضعیت'), tl,
        h('div', { class: 'row' }, ns, nd, nn, btn('افزودن وضعیت', () => { c.history.push({ date: nd.value || today(), status: ns.value, note: nn.value }); save(); }),
          T.checkUrl ? btn('بررسی در سایت رسمی', () => { try { navigator.clipboard.writeText(c.ref); } catch (e) {} window.open(T.checkUrl, '_blank'); }, 'ghost') : null,
          btn('تغییر یادآوری', () => { const v = prompt('تاریخ یادآوری (YYYY-MM-DD):', c.remind || addDays(today(), 30)); if (v !== null) { c.remind = v; save(); } }, 'ghost'),
          btn('حذف', () => { if (confirm('حذف شود؟')) { cases = cases.filter(x => x !== c); save(); } }, 'danger'))));
    });
  }
  if (T.checkUrl) root.append(h('p', { class: 'muted' }, 'دکمه «بررسی در سایت رسمی» شماره را کپی می‌کند و صفحه رسمی را باز می‌کند؛ وضعیت را خودتان ثبت کنید (این ابزار به حساب شما متصل نمی‌شود).'));
  draw();
};

/* ---------- 4. timeline (planned route timeline) ---------- */
R.timeline = (root) => {
  const keys = Object.keys(A.routes); let cur = S.get('route', keys[0]); if (!A.routes[cur]) cur = keys[0];
  let start = S.get('start', today()); const dur = S.get('dur', {}), done = S.get('done', {});
  const sel = h('select', { onchange: e => { cur = e.target.value; S.set('route', cur); draw(); } }, keys.map(k => h('option', { value: k, selected: k === cur }, A.routes[k].label)));
  const sd = h('input', { type: 'date', value: start, onchange: e => { start = e.target.value; S.set('start', start); draw(); } });
  const out = h('div'), chart = h('div'), kp = h('div', { class: 'kpis' });
  root.append(card('تنظیم مسیر', h('div', { class: 'grid2' }, field('مسیر', sel), field('تاریخ شروع', sd)), h('p', { class: 'muted' }, 'مدت‌ها تخمینی هستند؛ هر مرحله را با زمان واقعی یا اعلام‌شده در منبع رسمی ویرایش کنید.')),
    card('خلاصه', kp), card('نمودار زمانی', chart), card('مراحل', out, h('div', { class: 'row' }, btn('خروجی تقویم (ICS)', () => download(A.id + '-timeline.ics', ics(calc().map(s => ({ date: s.end, title: s.t, desc: A.routes[cur].label }))), 'text/calendar'), 'ghost'), btn('چاپ', () => print(), 'ghost'))));
  function calc() { let d = start; return A.routes[cur].steps.map((s, i) => { const k = cur + i; const days = dur[k] != null ? dur[k] : s.days; const st = d; d = addDays(d, days); return { ...s, i, k, days: Number(days), start: st, end: d }; }); }
  function draw() {
    const st = calc(); const total = st.reduce((a, b) => a + b.days, 0); const end = st.length ? st[st.length - 1].end : start;
    kp.innerHTML = ''; kp.append(h('div', { class: 'kpi' }, 'مدت کل تخمینی', h('b', {}, total + ' روز')), h('div', { class: 'kpi' }, 'حدود ماه', h('b', {}, (total / 30.4).toFixed(1))), h('div', { class: 'kpi' }, 'پایان تخمینی', h('b', {}, end)), h('div', { class: 'kpi' }, 'انجام‌شده', h('b', {}, st.filter(s => done[s.k]).length + '/' + st.length)));
    chart.innerHTML = ''; const W = 1000, rh = 26, H = st.length * rh + 30;
    let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="direction:ltr"><line x1="0" y1="${H - 18}" x2="${W}" y2="${H - 18}" stroke="currentColor" opacity=".2"/>`;
    let acc = 0; st.forEach((s, i) => { const x = total ? acc / total * (W - 260) : 0, w = total ? Math.max(3, s.days / total * (W - 260)) : 3; acc += s.days;
      svg += `<rect x="${x}" y="${i * rh + 4}" width="${w}" height="${rh - 8}" rx="4" fill="${done[s.k] ? '#1f7a4d' : '#0f5c8c'}" opacity=".85"/><text x="${x + w + 6}" y="${i * rh + rh / 2 + 4}" font-size="12">${(s.t || '').replace(/</g, '')} · ${s.days}d</text>`; });
    svg += `<text x="0" y="${H - 4}" font-size="11">${start}</text><text x="${W - 260}" y="${H - 4}" font-size="11" text-anchor="end">${end}</text></svg>`; chart.innerHTML = svg;
    out.innerHTML = ''; out.append(h('div', { class: 'tl' }, st.map(s => h('div', { class: 'ev' + (done[s.k] ? ' done' : '') },
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!done[s.k], onchange: e => { done[s.k] = e.target.checked; S.set('done', done); draw(); } }), h('b', {}, s.t)),
      h('div', { class: 'row' }, h('span', { class: 'muted' }, fmt(s.start) + ' ← ' + fmt(s.end)), h('input', { type: 'number', min: 0, value: s.days, style: 'max-width:110px', onchange: e => { dur[s.k] = Number(e.target.value); S.set('dur', dur); draw(); } }), 'روز'),
      s.note ? h('div', { class: 'muted' }, s.note) : null, s.u ? h('div', {}, link({ t: 'منبع رسمی', u: s.u })) : null))));
  }
  draw();
};

/* ---------- 5. visualizer (paste history -> graphic timeline) ---------- */
R.visualizer = (root) => {
  const ta = h('textarea', { class: 'ltr', placeholder: A.sample }); ta.value = S.get('txt', A.sample);
  const out = h('div'), kp = h('div', { class: 'kpis' });
  root.append(card('تاریخچه وضعیت پرونده', h('p', { class: 'muted' }, 'هر خط: تاریخ (YYYY-MM-DD یا مثلاً March 5, 2026) و سپس متن وضعیت. می‌توانید متن پیام‌های وضعیت را کپی کنید.'), ta,
    h('div', { class: 'row' }, btn('ساخت تایم‌لاین', run), btn('دانلود SVG', () => { const s = out.querySelector('svg'); if (s) download(A.id + '-timeline.svg', s.outerHTML, 'image/svg+xml'); }, 'ghost'), btn('بارگذاری نمونه', () => { ta.value = A.sample; run(); }, 'ghost'))),
    card('شاخص‌ها', kp), card('تایم‌لاین گرافیکی', out));
  function parseDate(s) {
    let m = s.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
    m = s.match(/([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})/); if (m) { const d = new Date(`${m[1]} ${m[2]}, ${m[3]} 12:00`); if (!isNaN(d)) return d.toISOString().slice(0, 10); }
    m = s.match(/(\d{1,2})[\/.](\d{1,2})[\/.](\d{4})/); if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`; return null;
  }
  function stage(t) { const l = t.toLowerCase(); for (const s of A.stages) if (s.k.some(k => l.includes(k))) return s; return { n: 'Other', c: '#888' }; }
  function run() {
    S.set('txt', ta.value);
    const ev = ta.value.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const d = parseDate(l); return d ? { d, t: l.replace(/^[^A-Za-z\u0600-\u06FF]*?\d{4}[^\sA-Za-z]*\s*[-–:|]?\s*/, '').trim() || l, s: stage(l) } : null; }).filter(Boolean).sort((a, b) => a.d.localeCompare(b.d));
    out.innerHTML = ''; kp.innerHTML = '';
    if (ev.length < 1) { out.append(h('p', { class: 'muted' }, 'تاریخ معتبری پیدا نشد.')); return; }
    const first = ev[0].d, last = ev[ev.length - 1].d, span = Math.max(1, daysBetween(first, last));
    let gap = 0, gapAt = ''; ev.forEach((e, i) => { if (i) { const g = daysBetween(ev[i - 1].d, e.d); if (g > gap) { gap = g; gapAt = ev[i - 1].s.n + ' → ' + e.s.n; } } });
    kp.append(h('div', { class: 'kpi' }, 'کل مدت', h('b', {}, span + ' روز')), h('div', { class: 'kpi' }, 'تا امروز', h('b', {}, daysBetween(first, today()) + ' روز')), h('div', { class: 'kpi' }, 'طولانی‌ترین وقفه', h('b', {}, gap + ' روز'), h('small', {}, gapAt)), h('div', { class: 'kpi' }, 'رویدادها', h('b', {}, ev.length)));
    const W = 1000, H = 120 + ev.length * 22; const X = d => 30 + daysBetween(first, d) / span * (W - 60);
    let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="direction:ltr;font-family:sans-serif"><line x1="30" y1="60" x2="${W - 30}" y2="60" stroke="#999" stroke-width="2"/>`;
    ev.forEach((e, i) => { const x = X(e.d); svg += `<circle cx="${x}" cy="60" r="8" fill="${e.s.c}"/><line x1="${x}" y1="68" x2="${x}" y2="${100 + i * 22}" stroke="${e.s.c}" stroke-dasharray="2 2"/><text x="${Math.min(x, W - 330)}" y="${104 + i * 22}" font-size="12">${e.d} · ${e.s.n}: ${e.t.slice(0, 48).replace(/[<&]/g, '')}</text>`; });
    svg += `<text x="30" y="40" font-size="12">${first}</text><text x="${W - 30}" y="40" font-size="12" text-anchor="end">${last}</text>`;
    const seen = []; A.stages.forEach(s => { if (ev.some(e => e.s.n === s.n)) seen.push(s); }); seen.forEach((s, i) => { svg += `<rect x="${30 + i * 140}" y="8" width="12" height="12" fill="${s.c}"/><text x="${46 + i * 140}" y="19" font-size="12">${s.n}</text>`; });
    out.innerHTML = svg + '</svg>';
  }
  run();
};

/* ---------- 6. cost calculator ---------- */
R.cost = (root) => {
  const C = A.costs; const vals = S.get('vals', {}); const qty = S.get('qty', {}); let rate = S.get('rate', C.rate || 1);
  const people = h('input', { type: 'number', min: 1, value: S.get('people', 1), onchange: e => { S.set('people', +e.target.value); draw(); } });
  const rateI = h('input', { type: 'number', step: 'any', value: rate, onchange: e => { rate = +e.target.value; S.set('rate', rate); draw(); } });
  const tbl = h('div', { class: 'tablewrap' }), sum = h('div', { class: 'kpis' }), bars = h('div');
  root.append(card('تنظیمات', h('div', { class: 'grid2' }, field('تعداد افراد (برای آیتم‌های «به ازای هر نفر»)', people), field(`نرخ تبدیل: هر ۱ ${C.currency} = ? ${C.alt || 'ارز دوم'}`, rateI)),
    h('p', { class: 'muted' }, 'مقادیر پیش‌فرض فقط برای شروع هستند. هزینه‌های دولتی را از صفحه رسمی هزینه‌ها (لینک‌ها) بررسی و وارد کنید.')),
    card('جمع‌بندی', sum, bars), card('آیتم‌های هزینه', tbl, h('div', { class: 'row' }, btn('خروجی CSV', exp, 'ghost'), btn('بازنشانی پیش‌فرض‌ها', () => { if (confirm('بازنشانی؟')) { S.set('vals', {}); S.set('qty', {}); location.reload(); } }, 'danger'), btn('چاپ', () => print(), 'ghost'))));
  const key = (g, i) => g + '#' + i;
  function lines() { const p = +people.value || 1; const L = []; C.groups.forEach(g => g.items.forEach((it, i) => { const k = key(g.g, i); const v = vals[k] != null ? vals[k] : it.v; const q = qty[k] != null ? qty[k] : (it.per ? p : 1); L.push({ g: g.g, it, k, v: +v || 0, q: +q || 0, total: (+v || 0) * (+q || 0) }); })); return L; }
  function draw() {
    const L = lines(); const tot = L.reduce((a, b) => a + b.total, 0);
    tbl.innerHTML = ''; const t = h('table', {}, h('tr', {}, h('th', {}, 'گروه'), h('th', {}, 'آیتم'), h('th', {}, 'مبلغ واحد (' + C.currency + ')'), h('th', {}, 'تعداد'), h('th', {}, 'جمع'), h('th', {}, 'مرجع')));
    L.forEach(l => t.append(h('tr', {}, h('td', {}, l.g), h('td', {}, l.it.t, l.it.official ? h('em', { class: 'tag' }, 'هزینه رسمی') : h('em', { class: 'tag warn' }, 'تخمینی')),
      h('td', {}, h('input', { type: 'number', step: 'any', value: l.v, style: 'max-width:120px', onchange: e => { vals[l.k] = +e.target.value; S.set('vals', vals); draw(); } })),
      h('td', {}, h('input', { type: 'number', min: 0, value: l.q, style: 'max-width:80px', onchange: e => { qty[l.k] = +e.target.value; S.set('qty', qty); draw(); } })),
      h('td', {}, num(l.total)), h('td', {}, l.it.u ? link({ t: 'منبع', u: l.it.u }) : '—'))));
    tbl.append(t);
    sum.innerHTML = ''; sum.append(h('div', { class: 'kpi' }, 'جمع کل', h('b', {}, num(tot, C.currency))), h('div', { class: 'kpi' }, 'معادل', h('b', {}, num(tot * rate, C.alt || ''))),
      h('div', { class: 'kpi' }, 'هزینه‌های رسمی', h('b', {}, num(L.filter(l => l.it.official).reduce((a, b) => a + b.total, 0), C.currency))), h('div', { class: 'kpi' }, 'بافر پیشنهادی ۱۵٪', h('b', {}, num(tot * 1.15, C.currency))));
    bars.innerHTML = ''; const gs = {}; L.forEach(l => gs[l.g] = (gs[l.g] || 0) + l.total); const mx = Math.max(1, ...Object.values(gs));
    Object.entries(gs).forEach(([g, v]) => bars.append(h('div', { class: 'barrow' }, h('span', {}, g), h('div', {}, h('div', { class: 'bar', style: `width:${v / mx * 100}%` })), h('span', {}, num(v, C.currency)))));
  }
  function exp() { const L = lines(); download(A.id + '-costs.csv', toCSV([['group', 'item', 'unit', 'qty', 'total', 'currency'], ...L.map(l => [l.g, l.it.t, l.v, l.q, l.total, C.currency])])); }
  draw();
};

/* ---------- 7. CV analyzer / job matcher ---------- */
R.cvmatch = (root) => {
  const M = A.cv; const cv = h('textarea', { class: 'ltr', placeholder: 'Paste your CV text here…' }), jd = h('textarea', { class: 'ltr', placeholder: 'Paste the job description here…' });
  cv.value = S.get('cv', ''); jd.value = S.get('jd', '');
  const up = (ta) => h('input', { type: 'file', accept: '.txt,.md', onchange: e => readFile(e.target.files[0], t => { ta.value = t; }) });
  const out = h('div');
  root.append(card('ورودی‌ها', h('div', { class: 'grid3' }, h('div', {}, field('متن رزومه (یا فایل .txt)', cv), up(cv)), h('div', {}, field('آگهی شغلی' + (M.jdOptional ? ' (اختیاری)' : ''), jd), up(jd))),
    h('div', { class: 'row' }, btn('تحلیل', run), M.boards ? M.boards.map(b => h('a', { class: 'btn ghost', href: b.u, target: '_blank', rel: 'noopener' }, b.t)) : null)), card('نتیجه تحلیل', out));
  function run() {
    S.set('cv', cv.value); S.set('jd', jd.value); out.innerHTML = '';
    const c = cv.value, j = jd.value; if (!c.trim()) { out.append(h('p', { class: 'muted' }, 'متن رزومه را وارد کنید.')); return; }
    const ct = new Set(tokens(c)); const cl = c.toLowerCase();
    const dict = A.skills || [];
    let score = null, matched = [], missing = [];
    if (j.trim()) {
      const jl = j.toLowerCase();
      const jdSkills = dict.filter(s => jl.includes(s.toLowerCase()));
      const freq = {}; tokens(j).forEach(w => freq[w] = (freq[w] || 0) + 1);
      const top = Object.entries(freq).filter(([w]) => w.length > 2).sort((a, b) => b[1] - a[1]).slice(0, 25).map(x => x[0]);
      const terms = [...new Set([...jdSkills.map(s => s.toLowerCase()), ...top])];
      terms.forEach(t => (cl.includes(t) || ct.has(t) ? matched : missing).push(t));
      const ws = jdSkills.length ? jdSkills.filter(s => cl.includes(s.toLowerCase())).length / jdSkills.length : 0;
      const wk = top.length ? top.filter(t => cl.includes(t)).length / top.length : 0;
      score = Math.round((jdSkills.length ? ws * 0.65 + wk * 0.35 : wk) * 100);
    }
    const checks = [
      ['ایمیل', /[\w.+-]+@[\w-]+\.[\w.]+/.test(c)], ['شماره تماس', /\+?\d[\d\s().-]{7,}/.test(c)], ['LinkedIn یا GitHub', /linkedin|github/i.test(c)],
      ['دستاورد عددی (٪، عدد، مبلغ)', (c.match(/\d+\s?%|\$\s?\d|€\s?\d|£\s?\d|\b\d{2,}\b/g) || []).length >= 3], ['افعال عملی (Built, Led, …)', /\b(built|led|designed|developed|implemented|improved|reduced|launched|managed|created|delivered|optimized)\b/i.test(c)],
      ['طول مناسب (۳۵۰ تا ۱۲۰۰ کلمه)', (() => { const n = c.split(/\s+/).length; return n >= 350 && n <= 1200; })()]];
    (M.checks || []).forEach(x => checks.push([x.l, new RegExp(x.re, 'i').test(c) !== !!x.invert]));
    const skillsInCv = dict.filter(s => cl.includes(s.toLowerCase()));
    out.append(h('div', { class: 'kpis' }, score != null ? h('div', { class: 'kpi' }, 'امتیاز تطابق با آگهی', h('b', {}, score + '%')) : null, h('div', { class: 'kpi' }, 'مهارت‌های شناسایی‌شده', h('b', {}, skillsInCv.length)),
      h('div', { class: 'kpi' }, 'کلمات رزومه', h('b', {}, c.split(/\s+/).length)), h('div', { class: 'kpi' }, 'بررسی‌های قالب', h('b', {}, checks.filter(x => x[1]).length + '/' + checks.length))));
    if (score != null) out.append(h('h4', {}, 'کلیدواژه‌های منطبق'), h('p', { class: 'ltr' }, matched.map(m => h('span', { class: 'tag ok' }, m))), h('h4', {}, 'کلیدواژه‌های غایب (در صورت داشتن مهارت، صادقانه اضافه کنید)'), h('p', { class: 'ltr' }, missing.map(m => h('span', { class: 'tag bad' }, m))));
    out.append(h('h4', {}, 'مهارت‌های موجود در رزومه'), h('p', { class: 'ltr' }, skillsInCv.map(m => h('span', { class: 'tag' }, m))),
      h('h4', {}, 'بررسی قالب و محتوا'), h('ul', {}, checks.map(([l, ok]) => h('li', {}, h('span', { class: 'tag ' + (ok ? 'ok' : 'warn') }, ok ? '✓' : '!'), ' ', l))),
      h('h4', {}, 'نکات بازار ' + (M.market || '')), h('ul', {}, (M.tips || []).map(t => h('li', {}, t))));
  }
  if (cv.value) run();
};

/* ---------- 8. job / listing finder + tracker ---------- */
R.jobs = (root) => {
  const J = A.jobs; const q = h('input', { placeholder: J.qHint || 'مثلاً: software engineer', class: 'ltr', value: S.get('q', '') }), loc = h('input', { placeholder: J.lHint || 'شهر/ایالت', class: 'ltr', value: S.get('l', '') });
  const links = h('div', { class: 'grid2' });
  root.append(card(J.searchTitle || 'جست‌وجو در منابع', h('div', { class: 'grid2' }, field('عبارت', q), field('مکان', loc)), (J.extra || []).length ? h('p', { class: 'muted' }, 'کلیدواژه‌های پیشنهادی: ' + J.extra.join(' · ')) : null,
    h('div', { class: 'row' }, btn('ساخت لینک‌های جست‌وجو', mk)), links));
  function mk() { S.set('q', q.value); S.set('l', loc.value); links.innerHTML = ''; J.boards.forEach(b => { const u = b.u.replace('{q}', encodeURIComponent(q.value + (b.add ? ' ' + b.add : ''))).replace('{l}', encodeURIComponent(loc.value)); links.append(h('a', { class: 'tile', href: u, target: '_blank', rel: 'noopener' }, h('b', {}, b.t), h('span', { class: 'muted' }, b.d || ''))); }); }
  mk();
  if (J.csv) {
    let rows = [], head = []; const sq = h('input', { placeholder: 'جست‌وجو در فایل (نام شرکت، شهر، …)' }), res = h('div', { class: 'tablewrap' }), info = h('p', { class: 'muted' });
    root.append(card(J.csv.title, h('p', {}, J.csv.hint, ' ', link(J.csv.src)), h('input', { type: 'file', accept: '.csv', onchange: e => { info.textContent = 'در حال خواندن…'; readFile(e.target.files[0], t => { const r = parseCSV(t); let hi = 0; while (hi < r.length - 1 && r[hi].length < 2) hi++; head = r[hi]; rows = r.slice(hi + 1); info.textContent = rows.length.toLocaleString() + ' ردیف بارگذاری شد.'; show(); }); } }), info, h('div', { class: 'row' }, sq, btn('جست‌وجو', show)), res));
    function show() { res.innerHTML = ''; if (!rows.length) return; const s = sq.value.toLowerCase().trim(); const f = s ? rows.filter(r => r.join(' ').toLowerCase().includes(s)) : rows; const t = h('table', { class: 'ltr' }, h('tr', {}, head.map(x => h('th', {}, x))), f.slice(0, 200).map(r => h('tr', {}, r.map(x => h('td', {}, x))))); res.append(h('p', { class: 'muted' }, f.length.toLocaleString() + ' نتیجه (نمایش حداکثر ۲۰۰)'), t, f.length ? btn('خروجی نتایج CSV', () => download(A.id + '-filtered.csv', toCSV([head, ...f])), 'ghost') : null); }
  }
  const F = J.fields || [{ id: 'title', l: 'عنوان' }, { id: 'org', l: 'شرکت' }, { id: 'url', l: 'لینک' }];
  const ST = J.statuses || ['ذخیره‌شده', 'درخواست داده شد', 'مصاحبه', 'پیشنهاد', 'رد شد'];
  let items = S.get('items', []); const inputs = {}; F.forEach(x => inputs[x.id] = h('input', { type: x.type || 'text', placeholder: x.l }));
  const tb = h('div', { class: 'tablewrap' }), kp = h('div', { class: 'kpis' });
  root.append(card(J.trackTitle || 'پیگیری موقعیت‌ها', h('div', { class: 'grid2' }, F.map(x => field(x.l, inputs[x.id]))), h('div', { class: 'row' }, btn('افزودن', () => { const it = { id: uid(), st: ST[0], d: today() }; F.forEach(x => it[x.id] = inputs[x.id].value); items.unshift(it); S.set('items', items); F.forEach(x => inputs[x.id].value = ''); draw(); }), btn('خروجی CSV', () => download(A.id + '-tracker.csv', toCSV([[...F.map(x => x.id), 'status', 'date'], ...items.map(i => [...F.map(x => i[x.id]), i.st, i.d])])), 'ghost')), kp, tb),
    J.tips ? card('نکات', h('ul', {}, J.tips.map(t => h('li', {}, t)))) : null);
  function draw() {
    kp.innerHTML = ''; ST.forEach(s => kp.append(h('div', { class: 'kpi' }, s, h('b', {}, items.filter(i => i.st === s).length))));
    tb.innerHTML = ''; tb.append(h('table', {}, h('tr', {}, F.map(x => h('th', {}, x.l)), h('th', {}, 'وضعیت'), h('th', {}, 'تاریخ'), h('th', {})),
      items.map(i => h('tr', {}, F.map(x => h('td', {}, x.id === 'url' && i.url ? link({ t: 'باز کردن', u: i.url }) : i[x.id])), h('td', {}, h('select', { onchange: e => { i.st = e.target.value; S.set('items', items); draw(); } }, ST.map(s => h('option', { selected: s === i.st }, s)))), h('td', {}, i.d), h('td', {}, btn('×', () => { items = items.filter(x => x !== i); S.set('items', items); draw(); }, 'danger'))))));
  }
  draw();
};

/* ---------- 9. encrypted document vault ---------- */
R.vault = (root) => {
  const V = A.vault; let key = null, db = null;
  const enc = new TextEncoder();
  const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf))), ub64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  async function derive(pass, salt) { const base = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']); return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); }
  const openDB = () => new Promise((res, rej) => { const r = indexedDB.open('astra-vault-' + A.id, 1); r.onupgradeneeded = () => r.result.createObjectStore('docs', { keyPath: 'id' }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const tx = (mode, fn) => new Promise((res, rej) => { const t = db.transaction('docs', mode); const s = t.objectStore('docs'); const r = fn(s); t.oncomplete = () => res(r && r.result); t.onerror = () => rej(t.error); });
  const lock = h('div'), main = h('div', { hidden: true });
  root.append(card('قفل گاوصندوق', lock), main);
  const meta = S.get('meta', null); const pass = h('input', { type: 'password', placeholder: 'رمز عبور گاوصندوق (حداقل ۸ کاراکتر)' }), m = h('p', { class: 'muted' });
  lock.append(h('p', { class: 'muted' }, 'فایل‌ها با AES-GCM 256 و کلید مشتق‌شده از رمز شما (PBKDF2، ۲۵۰ هزار تکرار) داخل همین مرورگر رمزگذاری و ذخیره می‌شوند. رمز را فراموش نکنید؛ قابل بازیابی نیست.'), pass, m,
    h('div', { class: 'row' }, btn(meta ? 'باز کردن' : 'ساخت گاوصندوق', unlock)));
  async function unlock() {
    try {
      if (pass.value.length < 8) { m.textContent = 'رمز کوتاه است.'; return; }
      db = await openDB();
      if (!meta) { const salt = crypto.getRandomValues(new Uint8Array(16)); key = await derive(pass.value, salt); const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode('astra-ok')); S.set('meta', { salt: b64(salt), iv: b64(iv), ct: b64(ct) }); }
      else { key = await derive(pass.value, ub64(meta.salt)); await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ub64(meta.iv) }, key, ub64(meta.ct)); }
      lock.innerHTML = ''; lock.append(h('p', {}, 'گاوصندوق باز است. ', btn('قفل کردن', () => location.reload(), 'ghost'))); main.hidden = false; build();
    } catch (e) { m.textContent = 'رمز اشتباه است یا مرورگر از Web Crypto پشتیبانی نمی‌کند.'; m.style.color = 'var(--bad)'; key = null; }
  }
  function build() {
    const file = h('input', { type: 'file' }), cat = h('select', {}, V.categories.map(c => h('option', {}, c))), exp = h('input', { type: 'date' }), note = h('input', { placeholder: 'یادداشت (مثلاً شماره سند)' });
    const list = h('div', { class: 'tablewrap' }), alerts = h('div'), sug = h('div');
    main.append(alerts, card('افزودن سند', h('div', { class: 'grid2' }, field('فایل (PDF/تصویر/…)', file), field('دسته', cat), field('تاریخ انقضا (اختیاری)', exp), field('یادداشت', note)),
      h('div', { class: 'row' }, btn('رمزگذاری و ذخیره', async () => {
        const f = file.files[0]; if (!f) return alert('فایلی انتخاب نشده');
        const iv = crypto.getRandomValues(new Uint8Array(12)); const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, await f.arrayBuffer());
        await tx('readwrite', s => s.put({ id: uid(), name: f.name, mime: f.type, size: f.size, cat: cat.value, exp: exp.value, note: note.value, added: today(), iv: b64(iv), data }));
        file.value = ''; note.value = ''; exp.value = ''; draw();
      }), btn('خروجی تقویم انقضاها', async () => { const all = await getAll(); download(A.id + '-expiry.ics', ics(all.filter(d => d.exp).flatMap(d => [{ date: addDays(d.exp, -(V.warnDays || 90)), title: 'تمدید زودهنگام: ' + d.name }, { date: d.exp, title: 'انقضا: ' + d.name }])), 'text/calendar'); }, 'ghost'))),
      card('اسناد من', list), card('مدارک پیشنهادی برای این مسیر', sug));
    async function getAll() { return (await tx('readonly', s => s.getAll())) || []; }
    async function draw() {
      const all = await getAll(); all.sort((a, b) => (a.exp || '9999').localeCompare(b.exp || '9999'));
      alerts.innerHTML = ''; all.filter(d => d.exp && daysBetween(today(), d.exp) <= (V.warnDays || 90)).forEach(d => { const n = daysBetween(today(), d.exp); alerts.append(h('div', { class: 'note' }, n < 0 ? `منقضی شده: ${d.name} (${-n} روز پیش)` : `${d.name}: ${n} روز تا انقضا`)); });
      list.innerHTML = ''; if (!all.length) list.append(h('p', { class: 'muted' }, 'سندی ذخیره نشده است.'));
      else list.append(h('table', {}, h('tr', {}, ['نام', 'دسته', 'انقضا', 'حجم', 'یادداشت', ''].map(x => h('th', {}, x))), all.map(d => {
        const n = d.exp ? daysBetween(today(), d.exp) : null;
        return h('tr', {}, h('td', {}, d.name), h('td', {}, d.cat), h('td', {}, d.exp ? [d.exp + ' ', h('span', { class: 'tag ' + (n < 0 ? 'bad' : n < 90 ? 'warn' : 'ok') }, n < 0 ? 'منقضی' : n + ' روز')] : '—'), h('td', {}, (d.size < 1024 ? d.size + ' B' : (d.size / 1024).toFixed(0) + ' KB')), h('td', {}, d.note),
          h('td', {}, btn('دانلود', async () => { try { const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ub64(d.iv) }, key, d.data); const a = h('a', { href: URL.createObjectURL(new Blob([pt], { type: d.mime })), download: d.name }); document.body.append(a); a.click(); a.remove(); } catch (e) { alert('رمزگشایی ناموفق'); } }, 'ghost'), ' ',
            btn('حذف', async () => { if (confirm('حذف شود؟')) { await tx('readwrite', s => s.delete(d.id)); draw(); } }, 'danger')));
      })));
      sug.innerHTML = ''; const cats = new Set(all.map(d => d.cat)); sug.append(h('ul', {}, V.suggested.map(s => { const sx = norm(s); const has = sx.cat && cats.has(sx.cat); return h('li', {}, h('span', { class: 'tag ' + (has ? 'ok' : '') }, has ? 'دارد' : '—'), ' ', sx.t); })));
    }
    draw();
  }
};

/* ---------- 10. official source tracker / news monitor ---------- */
R.sources = (root) => {
  let list = S.get('list', null) || A.list.map(s => ({ ...s, id: uid(), last: '', note: '', changed: false }));
  let log = S.get('log', []);
  const tb = h('div', { class: 'tablewrap' }), filt = h('select', { onchange: () => draw() }, h('option', { value: '' }, 'همه دسته‌ها'), [...new Set(A.list.map(s => s.cat))].map(c => h('option', {}, c)));
  const nt = h('input', { placeholder: 'عنوان منبع' }), nu = h('input', { placeholder: 'https://…', class: 'ltr' }), nc = h('input', { placeholder: 'دسته' }), nf = h('input', { type: 'number', value: 7, style: 'max-width:90px' });
  root.append(card('منابع رسمی تحت پایش', h('div', { class: 'row' }, filt, btn('همه را امروز بررسی‌شده علامت بزن', () => { list.forEach(s => { s.last = today(); s.changed = false; }); save(); }, 'ghost'),
    h('label', { class: 'btn ghost' }, 'ورود گزارش monitor.py', h('input', { type: 'file', accept: '.json', hidden: true, onchange: e => readFile(e.target.files[0], imp) })),
    btn('دانلود اسکریپت monitor.py', () => download('monitor.py', MONITOR()), 'ghost')), tb,
    h('div', { class: 'row' }, nt, nu, nc, nf, h('span', { class: 'muted' }, 'روز'), btn('افزودن منبع', () => { if (!nu.value) return; list.push({ id: uid(), t: nt.value || nu.value, u: nu.value, cat: nc.value || 'سفارشی', freq: +nf.value || 7, last: '', note: '' }); save(); }))),
    card('اسکریپت پایش خودکار', h('p', {}, 'فایل monitor.py (همراه پروژه) صفحات رسمی را دانلود، متن را نرمال و هش می‌کند و تغییرات را در changes.json ثبت می‌کند. با cron/Task Scheduler روزانه اجرا کنید و گزارش را اینجا وارد کنید:'), h('pre', { class: 'ltr kpi' }, 'python3 monitor.py            # check all sources\npython3 monitor.py --report   # print last report')));
  const ld = h('input', { type: 'date', value: today() }), lt = h('input', { placeholder: 'عنوان تغییر/خبر' }), lu = h('input', { placeholder: 'لینک رسمی', class: 'ltr' }), lc = h('select', {}, (A.tags || ['قانون', 'هزینه', 'فرم', 'زمان پردازش', 'سایر']).map(t => h('option', {}, t))), li = h('select', {}, ['کم', 'متوسط', 'زیاد'].map(t => h('option', {}, t)));
  const lq = h('input', { placeholder: 'جست‌وجو در لاگ…', oninput: () => drawLog() }), lb = h('div', { class: 'tablewrap' });
  root.append(card('لاگ تغییرات و اخبار رسمی', h('div', { class: 'grid2' }, field('تاریخ', ld), field('عنوان', lt), field('لینک', lu), field('دسته', lc), field('اثر', li)),
    h('div', { class: 'row' }, btn('ثبت', () => { if (!lt.value) return; log.unshift({ id: uid(), d: ld.value, t: lt.value, u: lu.value, c: lc.value, i: li.value }); S.set('log', log); lt.value = lu.value = ''; drawLog(); }), lq, btn('خروجی CSV', () => download(A.id + '-log.csv', toCSV([['date', 'title', 'url', 'tag', 'impact'], ...log.map(x => [x.d, x.t, x.u, x.c, x.i])])), 'ghost')), lb));
  function imp(t) { try { const r = JSON.parse(t); let n = 0; (r.results || []).forEach(x => { const s = list.find(s => s.u === x.url); if (s) { s.changed = !!x.changed; if (x.checked) s.last = x.checked.slice(0, 10); if (x.changed) { n++; log.unshift({ id: uid(), d: today(), t: 'تغییر شناسایی شد: ' + s.t, u: s.u, c: 'سایر', i: 'متوسط' }); } } }); S.set('log', log); save(); drawLog(); alert(n + ' تغییر شناسایی شد.'); } catch (e) { alert('فایل نامعتبر'); } }
  function save() { S.set('list', list); draw(); }
  function draw() {
    tb.innerHTML = ''; const f = filt.value;
    tb.append(h('table', {}, h('tr', {}, ['منبع', 'دسته', 'آخرین بررسی', 'وضعیت', 'یادداشت', ''].map(x => h('th', {}, x))), list.filter(s => !f || s.cat === f).map(s => {
      const due = !s.last || daysBetween(s.last, today()) >= (s.freq || 7);
      return h('tr', {}, h('td', {}, link(s)), h('td', {}, s.cat), h('td', {}, s.last || '—'), h('td', {}, s.changed ? h('span', { class: 'tag bad' }, 'تغییر کرده') : due ? h('span', { class: 'tag warn' }, 'نیاز به بررسی') : h('span', { class: 'tag ok' }, 'به‌روز')),
        h('td', {}, h('input', { value: s.note, onchange: e => { s.note = e.target.value; S.set('list', list); } })),
        h('td', {}, btn('بررسی شد', () => { s.last = today(); s.changed = false; save(); window.open(s.u, '_blank'); }, 'ghost'), ' ', btn('×', () => { list = list.filter(x => x !== s); save(); }, 'danger')));
    })));
  }
  function drawLog() { const q = lq.value.toLowerCase(); lb.innerHTML = ''; lb.append(h('table', {}, h('tr', {}, ['تاریخ', 'عنوان', 'دسته', 'اثر', ''].map(x => h('th', {}, x))), log.filter(x => !q || (x.t + x.c).toLowerCase().includes(q)).map(x => h('tr', {}, h('td', {}, x.d), h('td', {}, x.u ? link({ t: x.t, u: x.u }) : x.t), h('td', {}, x.c), h('td', {}, h('span', { class: 'tag ' + (x.i === 'زیاد' ? 'bad' : x.i === 'متوسط' ? 'warn' : '') }, x.i)), h('td', {}, btn('×', () => { log = log.filter(y => y !== x); S.set('log', log); drawLog(); }, 'danger')))))); }
  function MONITOR() { return window.MONITOR_PY || '# monitor.py is included in the project folder'; }
  draw(); drawLog();
};

/* ---------- 11. country comparison ---------- */
R.compare = (root) => {
  const Cm = A.compare; let selected = S.get('sel', Cm.rows.slice(0, 4).map(r => r.name)); const ratings = S.get('rat', {}); const weights = S.get('w', {});
  const picks = h('div', { class: 'row' }), facts = h('div', { class: 'tablewrap' }), grid = h('div', { class: 'tablewrap' }), rank = h('div');
  root.append(card('انتخاب کشورها', picks), card('مقایسه اطلاعات پایه', facts), card('امتیازدهی شخصی (۱ تا ۵) با وزن معیارها', h('p', { class: 'muted' }, 'امتیازها نظر شخصی شما بر اساس بررسی منابع رسمی است؛ ابزار فقط آن‌ها را وزن‌دهی و رتبه‌بندی می‌کند.'), grid), card('رتبه‌بندی نهایی', rank));
  Cm.rows.forEach(r => picks.append(h('label', { class: 'tag' }, h('input', { type: 'checkbox', checked: selected.includes(r.name), onchange: e => { selected = e.target.checked ? [...selected, r.name] : selected.filter(x => x !== r.name); S.set('sel', selected); draw(); } }), ' ', r.name)));
  function draw() {
    const rows = Cm.rows.filter(r => selected.includes(r.name));
    facts.innerHTML = ''; facts.append(h('table', {}, h('tr', {}, h('th', {}, 'مورد'), rows.map(r => h('th', {}, r.name))), Cm.fields.map(f => h('tr', {}, h('td', {}, h('b', {}, f.l)), rows.map(r => h('td', {}, /^https?:/.test(r.v[f.k] || '') ? link({ t: 'صفحه رسمی', u: r.v[f.k] }) : (r.v[f.k] || '—')))))));
    grid.innerHTML = ''; grid.append(h('table', {}, h('tr', {}, h('th', {}, 'معیار'), h('th', {}, 'وزن'), rows.map(r => h('th', {}, r.name))), Cm.criteria.map(c => h('tr', {}, h('td', {}, c),
      h('td', {}, h('input', { type: 'number', min: 0, max: 10, value: weights[c] ?? 5, style: 'max-width:70px', onchange: e => { weights[c] = +e.target.value; S.set('w', weights); draw(); } })),
      rows.map(r => h('td', {}, h('input', { type: 'number', min: 1, max: 5, value: ratings[r.name + c] ?? 3, style: 'max-width:70px', onchange: e => { ratings[r.name + c] = +e.target.value; S.set('rat', ratings); draw(); } })))))));
    const sc = rows.map(r => { let s = 0, w = 0; Cm.criteria.forEach(c => { const wt = weights[c] ?? 5; s += wt * (ratings[r.name + c] ?? 3); w += wt; }); return { n: r.name, s: w ? s / w : 0 }; }).sort((a, b) => b.s - a.s);
    rank.innerHTML = ''; sc.forEach(x => rank.append(h('div', { class: 'barrow' }, h('span', {}, x.n), h('div', {}, h('div', { class: 'bar', style: `width:${x.s / 5 * 100}%` })), h('span', {}, x.s.toFixed(2) + ' / 5'))));
  }
  draw();
};

/* ---------- 12. cost of living ---------- */
R.costliving = (root) => {
  const cats = A.colCats || [['rent', 'اجاره (آپارتمان یک‌خوابه)'], ['food', 'خوراک (هر نفر)'], ['transport', 'حمل‌ونقل (هر نفر)'], ['utilities', 'قبوض و اینترنت'], ['other', 'سایر (هر نفر)']];
  const per = new Set(['food', 'transport', 'other']); const ov = S.get('ov', {}); let sel = S.get('sel', A.cities.slice(0, 3).map(c => c.city));
  const ppl = h('input', { type: 'number', min: 1, value: S.get('p', 1), onchange: e => { S.set('p', +e.target.value); draw(); } }), sal = h('input', { type: 'number', value: S.get('s', 0), onchange: e => { S.set('s', +e.target.value); draw(); } });
  const picks = h('div', { class: 'row' }), tb = h('div', { class: 'tablewrap' }), bars = h('div');
  root.append(card('تنظیمات', h('div', { class: 'grid2' }, field('تعداد افراد خانوار', ppl), field('درآمد خالص ماهانه (' + A.currency + ')', sal)), h('p', { class: 'muted' }, 'اعداد پیش‌فرض تخمین‌های تقریبی ماهانه برای برنامه‌ریزی اولیه‌اند و با زمان تغییر می‌کنند؛ آن‌ها را با آگهی‌های واقعی و آمار رسمی جایگزین کنید (همه خانه‌ها قابل ویرایش‌اند).')),
    card('شهرها', picks), card('مقایسه ماهانه', bars, tb, h('div', { class: 'row' }, btn('خروجی CSV', () => download(A.id + '-col.csv', toCSV([['city', ...cats.map(c => c[0]), 'total'], ...A.cities.map(c => [c.city, ...cats.map(k => val(c, k[0])), tot(c)])])), 'ghost'), btn('بازنشانی', () => { S.set('ov', {}); location.reload(); }, 'danger'))));
  A.cities.forEach(c => picks.append(h('label', { class: 'tag' }, h('input', { type: 'checkbox', checked: sel.includes(c.city), onchange: e => { sel = e.target.checked ? [...sel, c.city] : sel.filter(x => x !== c.city); S.set('sel', sel); draw(); } }), ' ', c.city)));
  const val = (c, k) => ov[c.city + k] ?? c[k] ?? 0;
  const tot = c => { const p = +ppl.value || 1; return cats.reduce((a, [k]) => a + val(c, k) * (per.has(k) ? p : 1), 0); };
  function draw() {
    const cs = A.cities.filter(c => sel.includes(c.city)); const mx = Math.max(1, ...cs.map(tot)); const s = +sal.value || 0;
    bars.innerHTML = ''; cs.sort((a, b) => tot(a) - tot(b)).forEach(c => bars.append(h('div', { class: 'barrow' }, h('span', {}, c.city), h('div', {}, h('div', { class: 'bar', style: `width:${tot(c) / mx * 100}%` })), h('span', {}, num(tot(c), A.currency) + (s ? ' | مانده: ' + num(s - tot(c)) : '')))));
    tb.innerHTML = ''; tb.append(h('table', {}, h('tr', {}, h('th', {}, 'شهر'), cats.map(c => h('th', {}, c[1])), h('th', {}, 'جمع')), cs.map(c => h('tr', {}, h('td', {}, c.city), cats.map(([k]) => h('td', {}, h('input', { type: 'number', value: val(c, k), style: 'max-width:95px', onchange: e => { ov[c.city + k] = +e.target.value; S.set('ov', ov); draw(); } }))), h('td', {}, h('b', {}, num(tot(c))))))));
  }
  draw();
};

/* ---------- 13. scholarships ---------- */
R.scholarships = (root) => {
  const fav = S.get('fav', {}), dl = S.get('dl', {});
  const q = h('input', { placeholder: 'جست‌وجو…', oninput: () => draw() });
  const fc = h('select', { onchange: () => draw() }, h('option', { value: '' }, 'همه کشورها'), [...new Set(A.items.map(s => s.country))].map(c => h('option', {}, c)));
  const fl = h('select', { onchange: () => draw() }, h('option', { value: '' }, 'همه مقاطع'), ['Bachelor', 'Master', 'PhD', 'Research', 'Short'].map(c => h('option', {}, c)));
  const ff = h('select', { onchange: () => draw() }, h('option', { value: '' }, 'هر نوع حمایت'), h('option', { value: 'full' }, 'کامل'), h('option', { value: 'partial' }, 'جزئی'));
  const onlyF = h('input', { type: 'checkbox', onchange: () => draw() }); const out = h('div', { class: 'grid3' });
  root.append(card('فیلترها', h('div', { class: 'row' }, q, fc, fl, ff, h('label', {}, onlyF, ' فقط نشان‌شده‌ها'), btn('خروجی تقویم ددلاین‌ها', () => download(A.id + '-deadlines.ics', ics(Object.entries(dl).filter(x => x[1]).map(([n, d]) => ({ date: d, title: 'ددلاین بورسیه: ' + n }))), 'text/calendar'), 'ghost'))), card('نتایج', out),
    h('p', { class: 'muted' }, 'شرایط، مبالغ و ددلاین‌ها هر سال تغییر می‌کنند؛ ددلاین دوره جاری را از سایت رسمی هر برنامه بخوانید و در کارت ثبت کنید.'));
  function draw() {
    out.innerHTML = ''; const s = q.value.toLowerCase();
    A.items.filter(x => (!s || (x.n + x.who + x.country + (x.field || '')).toLowerCase().includes(s)) && (!fc.value || x.country === fc.value) && (!fl.value || x.level.includes(fl.value)) && (!ff.value || x.funding === ff.value) && (!onlyF.checked || fav[x.n]))
      .forEach(x => out.append(h('div', { class: 'route' }, h('header', {}, h('h3', {}, x.n), h('span', { class: 'tag ' + (x.funding === 'full' ? 'ok' : '') }, x.funding === 'full' ? 'حمایت کامل' : 'حمایت جزئی')),
        h('p', {}, h('b', {}, x.country), ' · ', x.level.join(', ')), h('p', { class: 'muted' }, x.who), x.months ? h('p', {}, 'بازه معمول درخواست: ', x.months) : null,
        h('div', { class: 'row' }, link({ t: 'سایت رسمی', u: x.url }), h('label', {}, h('input', { type: 'checkbox', checked: !!fav[x.n], onchange: e => { fav[x.n] = e.target.checked; S.set('fav', fav); } }), ' نشان'),
          h('input', { type: 'date', value: dl[x.n] || '', title: 'ددلاین من', onchange: e => { dl[x.n] = e.target.value; S.set('dl', dl); } })))));
    if (!out.children.length) out.append(h('p', { class: 'muted' }, 'نتیجه‌ای یافت نشد.'));
  }
  draw();
};

/* ---------- 14. deadlines / renewal reminders ---------- */
R.deadlines = (root) => {
  let items = S.get('items', []);
  const D = A.deadlines || {}; const alerts = h('div'), tb = h('div', { class: 'tablewrap' });
  if (D.presets) {
    const base = h('input', { type: 'date' }), lbl = h('input', { placeholder: D.baseHint || 'مثلاً: کارت اقامت' });
    root.append(card(D.presetTitle || 'ساخت خودکار یادآوری‌ها', h('div', { class: 'grid2' }, field(D.baseLabel || 'تاریخ مبنا', base), field('برچسب', lbl)),
      h('ul', { class: 'muted' }, D.presets.map(p => h('li', {}, p.t + ' — ' + (p.off < 0 ? (-p.off) + ' روز قبل' : p.off + ' روز بعد')))), D.note ? h('p', { class: 'muted' }, D.note) : null,
      h('div', { class: 'row' }, btn('ساخت یادآوری‌ها', () => { if (!base.value) return alert('تاریخ را وارد کنید'); D.presets.forEach(p => items.push({ id: uid(), t: (lbl.value ? lbl.value + ': ' : '') + p.t, d: addDays(base.value, p.off), c: p.c || 'اقامت', done: false })); save(); }))));
  }
  const t = h('input', { placeholder: 'عنوان ددلاین' }), d = h('input', { type: 'date' }), c = h('select', {}, (D.cats || ['ویزا/اقامت', 'تحصیل', 'کار', 'مدارک', 'مالی', 'سایر']).map(x => h('option', {}, x)));
  root.append(alerts, card('افزودن ددلاین', h('div', { class: 'grid2' }, field('عنوان', t), field('تاریخ', d), field('دسته', c)), h('div', { class: 'row' }, btn('افزودن', () => { if (!t.value || !d.value) return; items.push({ id: uid(), t: t.value, d: d.value, c: c.value, done: false }); t.value = ''; save(); }),
    btn('خروجی تقویم (ICS)', () => download(A.id + '-deadlines.ics', ics(items.filter(i => !i.done).map(i => ({ date: i.d, title: i.t, desc: i.c }))), 'text/calendar'), 'ghost'), btn('فعال‌سازی اعلان مرورگر', askNotify, 'ghost'))), card('ددلاین‌ها', tb));
  function save() { S.set('items', items); draw(); }
  function draw() {
    items.sort((a, b) => a.d.localeCompare(b.d)); alerts.innerHTML = '';
    const soon = items.filter(i => !i.done && daysBetween(today(), i.d) <= 14);
    soon.forEach(i => { const n = daysBetween(today(), i.d); alerts.append(h('div', { class: 'note' }, (n < 0 ? 'گذشته: ' : n === 0 ? 'امروز: ' : n + ' روز مانده: ') + i.t)); });
    if (soon.length) notify('ددلاین‌های نزدیک', soon.map(i => i.t).join('، '));
    tb.innerHTML = ''; if (!items.length) { tb.append(h('p', { class: 'muted' }, 'ددلاینی ثبت نشده.')); return; }
    tb.append(h('table', {}, h('tr', {}, ['', 'عنوان', 'تاریخ', 'باقی‌مانده', 'دسته', ''].map(x => h('th', {}, x))), items.map(i => { const n = daysBetween(today(), i.d); return h('tr', { style: i.done ? 'opacity:.5' : '' }, h('td', {}, h('input', { type: 'checkbox', checked: i.done, onchange: e => { i.done = e.target.checked; save(); } })), h('td', {}, i.t), h('td', {}, fmt(i.d)), h('td', {}, h('span', { class: 'tag ' + (n < 0 ? 'bad' : n <= 30 ? 'warn' : 'ok') }, n + ' روز')), h('td', {}, i.c), h('td', {}, btn('×', () => { items = items.filter(x => x !== i); save(); }, 'danger'))); })));
  }
  draw();
};

/* ---------- 15. planner (phased tasks relative to target date) ---------- */
R.planner = (root) => {
  const P = A.plan; let target = S.get('target', addDays(today(), 180)); const done = S.get('done', {}); let custom = S.get('custom', []);
  const variant = P.variants ? h('select', { onchange: e => { S.set('var', e.target.value); draw(); } }, Object.entries(P.variants).map(([k, v]) => h('option', { value: k, selected: S.get('var', Object.keys(P.variants)[0]) === k }, v.label))) : null;
  const td = h('input', { type: 'date', value: target, onchange: e => { target = e.target.value; S.set('target', target); draw(); } });
  const out = h('div'), kp = h('div', { class: 'kpis' }), ct = h('input', { placeholder: 'کار دلخواه' }), cd = h('input', { type: 'date' });
  root.append(card('تنظیم برنامه', h('div', { class: 'grid2' }, field(P.targetLabel || 'تاریخ هدف', td), variant ? field('سناریو', variant) : null), kp),
    card('برنامه زمان‌بندی‌شده', out, h('div', { class: 'row' }, ct, cd, btn('افزودن', () => { if (!ct.value) return; custom.push({ id: uid(), t: ct.value, d: cd.value || target }); S.set('custom', custom); ct.value = ''; draw(); }),
      btn('خروجی تقویم (ICS)', () => download(A.id + '-plan.ics', ics(tasks().filter(t => !done[t.k]).map(t => ({ date: t.d, title: t.t, desc: t.ph }))), 'text/calendar'), 'ghost'), btn('چاپ', () => print(), 'ghost'))));
  function phases() { if (!P.variants) return P.phases; const v = S.get('var', Object.keys(P.variants)[0]); return [...(P.phases || []), ...P.variants[v].phases].sort((a, b) => a.off - b.off); }
  function tasks() { const L = []; phases().forEach(p => p.tasks.forEach(t => { const tt = norm(t); L.push({ ...tt, ph: p.name, off: p.off, d: addDays(target, p.off), k: p.name + '|' + tt.t }); })); custom.forEach(c => L.push({ t: c.t, ph: 'دلخواه', d: c.d, k: 'c|' + c.id, cid: c.id })); return L.sort((a, b) => a.d.localeCompare(b.d)); }
  function draw() {
    const L = tasks(); const dn = L.filter(t => done[t.k]).length; const nx = L.find(t => !done[t.k]);
    kp.innerHTML = ''; kp.append(h('div', { class: 'kpi' }, 'روز تا هدف', h('b', {}, daysBetween(today(), target))), h('div', { class: 'kpi' }, 'پیشرفت', h('b', {}, (L.length ? Math.round(dn / L.length * 100) : 0) + '%')), h('div', { class: 'kpi' }, 'کار بعدی', h('b', { style: 'font-size:.95rem' }, nx ? nx.t : '—')), h('div', { class: 'kpi' }, 'کارهای عقب‌افتاده', h('b', {}, L.filter(t => !done[t.k] && t.d < today()).length)));
    out.innerHTML = ''; let ph0;
    L.forEach(t => { if (t.ph !== ph0) { ph0 = t.ph; out.append(h('h4', {}, t.ph)); }
      out.append(h('label', { class: 'check' + (done[t.k] ? ' done' : '') }, h('input', { type: 'checkbox', checked: !!done[t.k], onchange: e => { done[t.k] = e.target.checked; S.set('done', done); draw(); } }),
        h('span', {}, t.t, ' ', h('em', { class: 'tag ' + (!done[t.k] && t.d < today() ? 'bad' : '') }, t.d), t.note ? h('small', {}, t.note) : null, t.u ? h('small', {}, link({ t: 'منبع رسمی', u: t.u })) : null))); });
  }
  draw();
};

/* ---------- 16. scam detector ---------- */
R.scam = (root) => {
  const Z = A.scam; const u = h('input', { class: 'ltr', placeholder: 'https://…' }), tx = h('textarea', { placeholder: 'متن پیام/آگهی/ایمیل مشکوک را اینجا بچسبانید…' }), out = h('div'); let hist = S.get('hist', []);
  const hd = h('div');
  root.append(card('بررسی لینک و متن', field('آدرس سایت یا لینک', u), field('متن (اختیاری)', tx), h('div', { class: 'row' }, btn('بررسی', run))), card('نتیجه', out), card('دامنه‌های رسمی مرجع', h('ul', { class: 'ltr' }, Z.official.map(d => h('li', {}, d)))), card('سابقه بررسی‌ها', hd));
  const lev = (a, b) => { const m = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) m[0][j] = j; for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return m[a.length][b.length]; };
  function run() {
    const flags = []; let risk = 0; let host = '';
    if (u.value.trim()) {
      let url; try { url = new URL(/^[a-z]+:\/\//i.test(u.value.trim()) ? u.value.trim() : 'http://' + u.value.trim()); } catch (e) { flags.push(['آدرس نامعتبر است', 2]); }
      if (url) { host = url.hostname.toLowerCase().replace(/^www\./, '');
        const isOff = Z.official.some(d => host === d || host.endsWith('.' + d));
        if (isOff) flags.push(['دامنه در فهرست دامنه‌های رسمی است', -5]);
        else {
          flags.push(['دامنه جزو دامنه‌های رسمی شناخته‌شده نیست', 2]);
          Z.official.forEach(d => { const base = d.split('.')[0]; if (base.length > 3 && host.includes(base)) flags.push([`نام «${base}» در دامنه غیررسمی تقلید شده (${d})`, 4]); else { const dist = lev(host, d); if (dist > 0 && dist <= 3) flags.push([`دامنه شبیه ${d} است (احتمال typosquatting)`, 4]); } });
          if (/^xn--|\.xn--/.test(host)) flags.push(['دامنه punycode (حروف مشابه‌نما)', 3]);
          if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) flags.push(['استفاده از IP به‌جای دامنه', 3]);
          if (/\.(xyz|top|online|site|icu|click|live|shop|info|buzz|cfd|sbs)$/.test(host)) flags.push(['پسوند دامنه پرخطر/ارزان', 2]);
          if (/(bit\.ly|tinyurl|t\.co|cutt\.ly|rb\.gy|is\.gd|shorturl)/.test(host)) flags.push(['لینک کوتاه‌شده؛ مقصد واقعی پنهان است', 2]);
          if ((host.match(/-/g) || []).length >= 2) flags.push(['چند خط تیره در دامنه', 1]);
          if ((Z.keywords || []).some(k => host.includes(k))) flags.push(['کلمات مهاجرت/ویزا در دامنه غیررسمی', 2]);
        }
        if (url.protocol === 'http:' && /^[a-z]+:\/\//i.test(u.value.trim())) flags.push(['اتصال بدون HTTPS', 2]);
        if (url.username || url.password) flags.push(['وجود @ / اطلاعات کاربری در URL', 3]);
      }
    }
    const t = tx.value.toLowerCase(); if (t) Z.text.forEach(r => { if (new RegExp(r.re, 'i').test(t)) flags.push([r.m, r.w]); });
    risk = flags.reduce((a, b) => a + b[1], 0);
    const lvl = risk >= 6 ? ['bad', 'ریسک بالا — اطلاعات یا پول ارسال نکنید'] : risk >= 3 ? ['warn', 'مشکوک — قبل از هر اقدامی از دامنه رسمی تأیید کنید'] : ['ok', 'نشانه خطر جدی یافت نشد (این به معنی تأیید قطعی نیست)'];
    out.innerHTML = ''; out.append(h('div', { class: 'verdict ' + lvl[0] }, lvl[1] + ' — امتیاز ریسک: ' + risk), h('ul', {}, flags.map(f => h('li', {}, h('span', { class: 'tag ' + (f[1] < 0 ? 'ok' : f[1] >= 3 ? 'bad' : 'warn') }, (f[1] > 0 ? '+' : '') + f[1]), ' ', f[0]))), h('p', { class: 'muted' }, Z.advice));
    hist.unshift({ d: today(), host: host || '(متن)', risk }); hist = hist.slice(0, 30); S.set('hist', hist); drawH();
  }
  function drawH() { hd.innerHTML = ''; hd.append(h('table', {}, hist.map(x => h('tr', {}, h('td', {}, x.d), h('td', { class: 'ltr' }, x.host), h('td', {}, x.risk))))); }
  drawH();
};

/* ---------- 17. copilot (profile -> personal dashboard + RAG assistant) ---------- */
R.copilot = (root) => {
  const ans = S.get('ans', {}); const form = h('div', { class: 'grid2' });
  A.questions.forEach(q => form.append(field(q.q, h('select', { onchange: e => { ans[q.id] = e.target.value; S.set('ans', ans); } }, h('option', { value: '' }, '—'), q.options.map(o => h('option', { value: o.v, selected: ans[q.id] === o.v }, o.l))))));
  const dash = h('div');
  root.append(card('۱. پروفایل', form, h('div', { class: 'row' }, btn('ساخت داشبورد شخصی', build), btn('خروجی گزارش', () => download(A.id + '-dashboard.txt', dash.innerText), 'ghost'))), dash);
  function build() {
    dash.innerHTML = '';
    const sc = A.routes.map(r => { let met = 0, tot = 0, miss = []; Object.entries(r.when || {}).forEach(([k, v]) => { if (!ans[k]) return; tot++; if (v.includes(ans[k])) met++; else miss.push((A.questions.find(q => q.id === k) || {}).q); }); const ex = Object.entries(r.not || {}).some(([k, v]) => v.includes(ans[k])) || GATE.some(k => r.when && r.when[k] && ans[k] && !r.when[k].includes(ans[k])); return { r, s: ex ? 0 : tot ? met / tot : 0, miss }; }).sort((a, b) => b.s - a.s);
    const top = sc.filter(x => x.s >= 0.5).slice(0, 3); const pick = top.length ? top : sc.slice(0, 1);
    dash.append(card('۲. مسیرهای محتمل (مطابقت اولیه، نه تضمین)', sc.slice(0, 5).map(x => routeCard(x.r, x.s, x.miss))));
    const docs = [...new Set(pick.flatMap(x => x.r.docs || []))]; const st = S.get('docs', {});
    dash.append(card('۳. مدارک', h('div', {}, docs.map(d => h('label', { class: 'check' + (st[d] ? ' done' : '') }, h('input', { type: 'checkbox', checked: !!st[d], onchange: e => { st[d] = e.target.checked; S.set('docs', st); } }), h('span', {}, d))))));
    let d0 = today(); const ev = []; (pick[0].r.timeline || []).forEach(s => { d0 = addDays(d0, s.days); ev.push({ date: d0, title: s.t }); });
    dash.append(card('۴. ددلاین‌ها و زمان‌بندی تخمینی (' + pick[0].r.name + ')', h('div', { class: 'tl' }, ev.map(e => h('div', { class: 'ev' }, h('b', {}, e.title), ' — ', fmt(e.date)))), h('div', { class: 'row' }, btn('خروجی ICS', () => download(A.id + '-plan.ics', ics(ev), 'text/calendar'), 'ghost'))));
    const costs = pick[0].r.costs || []; dash.append(card('۵. هزینه‌های قابل انتظار', h('table', {}, costs.map(c => h('tr', {}, h('td', {}, c.t), h('td', {}, c.u ? link({ t: 'جدول رسمی هزینه', u: c.u }) : (c.v || '—'))))), h('p', { class: 'muted' }, 'مبالغ را از صفحه رسمی هزینه بخوانید؛ این داشبورد عدد قطعی ادعا نمی‌کند.')));
    dash.append(card('۶. شغل / دانشگاه', h('div', { class: 'grid2' }, (A.opportunities || []).map(o => h('a', { class: 'tile', href: o.u, target: '_blank', rel: 'noopener' }, h('b', {}, o.t), h('span', { class: 'muted' }, o.d || ''))))));
    dash.append(card('۷. منابع رسمی', h('ul', {}, [...new Map(pick.flatMap(x => x.r.sources || []).concat(A.sources || []).map(s => [s.u, s])).values()].map(s => h('li', {}, link(s))))));
  }
  // assistant
  const chat = h('div', { class: 'chat' }), qi = h('input', { placeholder: 'سؤال خود را بپرسید…', onkeydown: e => { if (e.key === 'Enter') ask(); } });
  const cfg = S.get('llm', { url: 'https://api.openai.com/v1/chat/completions', model: 'gpt-4o-mini', key: '' });
  const ku = h('input', { class: 'ltr', value: cfg.url }), km = h('input', { class: 'ltr', value: cfg.model }), kk = h('input', { class: 'ltr', type: 'password', value: cfg.key, placeholder: 'API key (اختیاری)' }), rem = h('input', { type: 'checkbox', checked: !!cfg.key });
  root.append(card('۸. دستیار هوشمند (RAG روی پایگاه دانش منابع رسمی)', h('p', { class: 'muted' }, 'بدون API key: مرتبط‌ترین بخش‌های پایگاه دانش با لینک منبع نمایش داده می‌شود. با API key سازگار با OpenAI: پاسخ فقط بر اساس همان بخش‌ها تولید می‌شود. کلید فقط در مرورگر شما می‌ماند.'),
    h('details', {}, h('summary', {}, 'تنظیمات مدل زبانی'), h('div', { class: 'grid2' }, field('Endpoint', ku), field('Model', km), field('API key', kk)), h('label', {}, rem, ' ذخیره کلید در این مرورگر')), chat, h('div', { class: 'row' }, qi, btn('ارسال', ask))));
  function retrieve(q) { const qt = new Set([...tokens(q), ...(q.match(/[\u0600-\u06FF]{2,}/g) || [])]); return A.kb.map(d => { const txt = (d.t + ' ' + d.text + ' ' + (d.k || '')).toLowerCase(); let s = 0; qt.forEach(w => { if (txt.includes(w.toLowerCase())) s += w.length > 4 ? 2 : 1; }); return { d, s }; }).filter(x => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 3).map(x => x.d); }
  async function ask() {
    const q = qi.value.trim(); if (!q) return; qi.value = ''; chat.append(h('div', { class: 'msg u' }, q));
    const ctx = retrieve(q); S.set('llm', { url: ku.value, model: km.value, key: rem.checked ? kk.value : '' });
    if (!kk.value) { chat.append(h('div', { class: 'msg a' }, ctx.length ? ['مرتبط‌ترین اطلاعات:\n', ...ctx.map(d => h('div', {}, h('b', {}, d.t), ': ', d.text, ' ', link({ t: 'منبع', u: d.u })))] : 'مطلبی در پایگاه دانش پیدا نشد؛ سؤال را با کلیدواژه‌های دیگر (مثلاً نام ویزا یا فرم) بپرسید.')); chat.scrollTop = 1e9; return; }
    const wait = h('div', { class: 'msg a' }, '…'); chat.append(wait);
    try {
      const sys = 'You are an immigration information assistant. Answer in Persian. Use ONLY the context; if the answer is not in it, say so and point to the official source. Never guarantee outcomes; this is not legal advice. Cite source URLs.\n\nCONTEXT:\n' + ctx.map(d => `[${d.t}] ${d.text} (${d.u})`).join('\n') + '\nPROFILE: ' + JSON.stringify(ans);
      const r = await fetch(ku.value, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + kk.value }, body: JSON.stringify({ model: km.value, messages: [{ role: 'system', content: sys }, { role: 'user', content: q }], temperature: 0.2 }) });
      const j = await r.json(); wait.textContent = j.choices ? j.choices[0].message.content : ('خطا: ' + JSON.stringify(j.error || j));
    } catch (e) { wait.textContent = 'خطای اتصال: ' + e.message; }
    chat.scrollTop = 1e9;
  }
  if (Object.keys(ans).length) build();
};

/* ---------- 18. wizard (step-by-step guide) ---------- */
R.wizard = (root) => {
  let i = S.get('i', 0); const done = S.get('done', {}), notes = S.get('notes', {});
  const bar = h('div', { class: 'steps' }), body = h('div'), fq = h('input', { placeholder: 'جست‌وجو در پرسش‌های متداول…', oninput: () => drawF() }), fl = h('div');
  root.append(card('راهنمای مرحله‌به‌مرحله', bar, body), A.faq ? card('پرسش‌های متداول', fq, fl) : null);
  function draw() {
    bar.innerHTML = ''; A.steps.forEach((s, k) => bar.append(h('button', { class: (k === i ? 'on ' : '') + (done[k] ? 'ok' : ''), onclick: () => { i = k; S.set('i', i); draw(); } }, (k + 1) + (done[k] ? ' ✓' : ''))));
    const s = A.steps[i]; const n = h('textarea', { style: 'min-height:70px', placeholder: 'یادداشت شما برای این مرحله…', onchange: e => { notes[i] = e.target.value; S.set('notes', notes); } }); n.value = notes[i] || '';
    body.innerHTML = ''; body.append(h('h3', {}, `مرحله ${i + 1} از ${A.steps.length}: ${s.t}`), h('p', {}, s.body), s.tips ? h('ul', {}, s.tips.map(t => h('li', {}, t))) : null, s.link ? h('p', {}, link(s.link)) : null, n,
      h('div', { class: 'row' }, btn('قبلی', () => { if (i > 0) { i--; S.set('i', i); draw(); } }, 'ghost'), h('label', {}, h('input', { type: 'checkbox', checked: !!done[i], onchange: e => { done[i] = e.target.checked; S.set('done', done); draw(); } }), ' این مرحله انجام شد'),
        btn('بعدی', () => { if (i < A.steps.length - 1) { i++; S.set('i', i); draw(); } }), btn('خروجی یادداشت‌ها', () => download(A.id + '-notes.txt', A.steps.map((s, k) => `${k + 1}. ${s.t} [${done[k] ? 'done' : '—'}]\n${notes[k] || ''}`).join('\n\n')), 'ghost')));
  }
  function drawF() { if (!A.faq) return; const q = fq.value.toLowerCase(); fl.innerHTML = ''; A.faq.filter(f => !q || (f.q + f.a).toLowerCase().includes(q)).forEach(f => fl.append(h('details', {}, h('summary', {}, f.q), h('p', {}, f.a)))); }
  draw(); drawF();
};

/* ---------- 19. CV builder / converter ---------- */
R.cvbuilder = (root) => {
  const F = ['name', 'title', 'email', 'phone', 'city', 'links', 'dob', 'nationality', 'summary', 'experience', 'education', 'skills', 'languages', 'extra'];
  const L = { name: 'Full name', title: 'Headline', email: 'Email', phone: 'Phone', city: 'City, Country', links: 'LinkedIn / GitHub', dob: 'Date of birth', nationality: 'Nationality', summary: 'Profile summary', experience: 'Experience — one per line: Role | Company | 2022–2025 | achievement; achievement', education: 'Education — one per line: Degree | University | Year', skills: 'Skills (comma separated)', languages: 'Languages — e.g. English C1, German B1', extra: 'Certificates / Projects (one per line)' };
  const d = S.get('cv', {}); const inp = {};
  F.forEach(k => inp[k] = (['summary', 'experience', 'education', 'extra'].includes(k) ? h('textarea', { class: 'ltr', style: 'min-height:90px' }) : h('input', { class: 'ltr' })));
  F.forEach(k => { inp[k].value = d[k] || ''; inp[k].addEventListener('input', () => { d[k] = inp[k].value; S.set('cv', d); draw(); }); });
  const tsel = h('select', { onchange: () => { S.set('tpl', tsel.value); draw(); } }, A.templates.map(t => h('option', { value: t.id, selected: S.get('tpl', A.templates[0].id) === t.id }, t.name)));
  const prev = h('div'), rules = h('div');
  root.append(card('اطلاعات رزومه (انگلیسی)', h('div', { class: 'grid2' }, F.map(k => field(L[k], inp[k]))), h('div', { class: 'row' }, btn('پر کردن نمونه', () => { Object.assign(d, SAMPLE); F.forEach(k => inp[k].value = d[k] || ''); S.set('cv', d); draw(); }, 'ghost'))),
    card('قالب کشور مقصد', tsel, rules, h('div', { class: 'row' }, btn('چاپ / ذخیره PDF', () => { const w = window.open(''); w.document.write('<html><head><title>CV</title><style>body{font-family:Georgia,serif;max-width:800px;margin:30px auto;color:#111}h2{margin:0}h3{border-bottom:1px solid #999;text-transform:uppercase;font-size:13px;letter-spacing:1px}.ph{float:right;width:90px;height:110px;border:1px dashed #999}</style></head><body>' + prev.firstChild.innerHTML + '</body></html>'); w.document.close(); w.print(); }),
      btn('دانلود HTML', () => download('cv-' + tsel.value + '.html', '<!doctype html><meta charset="utf-8"><body style="font-family:Georgia,serif;max-width:800px;margin:30px auto">' + prev.firstChild.innerHTML, 'text/html'), 'ghost'), btn('دانلود Markdown', () => download('cv-' + tsel.value + '.md', md()), 'ghost'))), card('پیش‌نمایش', prev));
  const SAMPLE = { name: 'Arya Example', title: 'Full-Stack Developer (Python/React)', email: 'arya@example.com', phone: '+1 555 010 0000', city: 'Secaucus, NJ, USA', links: 'linkedin.com/in/example · github.com/example', dob: '1990-01-01', nationality: 'Iranian', summary: 'Full-stack developer with 6+ years building Django/FastAPI back ends and React front ends. Shipped immigration-data dashboards used by 10,000+ users.', experience: 'Senior Developer | Example Tech | 2022–2025 | Built RAG assistant reducing support tickets by 35%; Led migration to PostgreSQL 16\nDeveloper | Web Studio | 2019–2022 | Delivered 20+ client projects; Cut page load time by 40%', education: 'B.Sc. Computer Engineering | University of Tehran | 2013', skills: 'Python, Django, FastAPI, React, Next.js, PostgreSQL, Redis, Docker, Celery, LLM/RAG', languages: 'Persian (native), English C1, German A2', extra: 'AWS Certified Developer – Associate\nAstra Global Migration — open-source portfolio' };
  const esc = s => String(s || '').replace(/[<&>]/g, c => ({ '<': '&lt;', '&': '&amp;', '>': '&gt;' }[c]));
  const sec = { profile: () => d.summary ? `<h3>${tpl().labels?.profile || 'Profile'}</h3><p>${esc(d.summary)}</p>` : '',
    experience: () => d.experience ? `<h3>${tpl().labels?.experience || 'Experience'}</h3>` + d.experience.split('\n').filter(Boolean).map(l => { const [r, c, y, a] = l.split('|').map(x => (x || '').trim()); return `<p><b>${esc(r)}</b> — ${esc(c)} <span style="float:right">${esc(y)}</span></p>${a ? '<ul>' + a.split(';').map(x => `<li>${esc(x.trim())}</li>`).join('') + '</ul>' : ''}`; }).join('') : '',
    education: () => d.education ? `<h3>${tpl().labels?.education || 'Education'}</h3>` + d.education.split('\n').filter(Boolean).map(l => { const [g, u, y] = l.split('|').map(x => (x || '').trim()); return `<p><b>${esc(g)}</b> — ${esc(u)} <span style="float:right">${esc(y)}</span></p>`; }).join('') : '',
    skills: () => d.skills ? `<h3>${tpl().labels?.skills || 'Skills'}</h3><p>${esc(d.skills)}</p>` : '', languages: () => d.languages ? `<h3>${tpl().labels?.languages || 'Languages'}</h3><p>${esc(d.languages)}</p>` : '',
    extra: () => d.extra ? `<h3>${tpl().labels?.extra || 'Certifications & Projects'}</h3><ul>${d.extra.split('\n').filter(Boolean).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '' };
  const tpl = () => A.templates.find(t => t.id === tsel.value) || A.templates[0];
  function draw() {
    const t = tpl(); rules.innerHTML = ''; rules.append(h('ul', {}, t.notes.map(n => h('li', {}, n))));
    const personal = [d.email, d.phone, d.city, d.links, t.dob && d.dob ? 'Born ' + d.dob : '', t.dob && d.nationality ? d.nationality : ''].filter(Boolean).map(esc).join(' · ');
    const html = `${t.photo ? '<div class="ph">Photo</div>' : ''}<h2>${esc(d.name || 'Your Name')}</h2><p><i>${esc(d.title)}</i><br>${personal}</p>` + t.order.map(k => sec[k] ? sec[k]() : '').join('') + (t.footer ? `<p style="margin-top:24px">${t.footer.replace('{city}', esc((d.city || '').split(',')[0])).replace('{date}', today())}</p>` : '');
    prev.innerHTML = ''; const p = h('div', { class: 'cvprev', html }); prev.append(p);
    const words = p.textContent.split(/\s+/).length; prev.append(h('p', { class: 'muted' }, `حدود ${words} کلمه — هدف این قالب: ${t.pages}`));
  }
  function md() { const t = tpl(); return `# ${d.name}\n${d.title}\n\n${[d.email, d.phone, d.city, d.links].filter(Boolean).join(' · ')}\n\n` + t.order.map(k => { const v = { profile: d.summary, experience: d.experience, education: d.education, skills: d.skills, languages: d.languages, extra: d.extra }[k]; return v ? `## ${(t.labels && t.labels[k]) || k}\n${v}\n` : ''; }).join('\n'); }
  draw();
};

/* ---------- 20. visa wait time dashboard ---------- */
R.waittimes = (root) => {
  const W = A.wait; let rows = S.get('rows', W.sample);
  const post = h('input', { placeholder: 'مثلاً: Yerevan', class: 'ltr' }), vt = h('select', {}, W.types.map(t => h('option', {}, t))), days = h('input', { type: 'number', min: 0, placeholder: 'روز' }), dt = h('input', { type: 'date', value: today() });
  const fv = h('select', { onchange: () => draw() }, W.types.map(t => h('option', {}, t))), chart = h('div'), tb = h('div', { class: 'tablewrap' }), trend = h('div'), tp = h('select', { onchange: () => drawT() });
  root.append(card('ثبت داده (از صفحه رسمی)', h('p', {}, 'زمان انتظار را از ', link(W.src), ' بخوانید و ثبت کنید یا CSV وارد کنید (ستون‌ها: post,type,days,date). اسکریپت fetch_wait_times.py همراه پروژه نیز جدول‌های صفحه رسمی را به CSV تبدیل می‌کند.'),
    h('div', { class: 'grid2' }, field('کنسولگری/سفارت', post), field('نوع ویزا', vt), field('زمان انتظار (روز)', days), field('تاریخ مشاهده', dt)),
    h('div', { class: 'row' }, btn('ثبت', () => { if (!post.value || days.value === '') return; rows.push({ post: post.value.trim(), type: vt.value, days: +days.value, date: dt.value }); save(); }),
      h('label', { class: 'btn ghost' }, 'ورود CSV', h('input', { type: 'file', accept: '.csv', hidden: true, onchange: e => readFile(e.target.files[0], t => { const r = parseCSV(t); const hd = r[0].map(x => x.toLowerCase().trim()); const ix = k => hd.indexOf(k); r.slice(1).forEach(x => { if (x[ix('post')]) rows.push({ post: x[ix('post')], type: x[ix('type')] || W.types[0], days: +x[ix('days')] || 0, date: x[ix('date')] || today() }); }); save(); }) })),
      btn('خروجی CSV', () => download(A.id + '-waits.csv', toCSV([['post', 'type', 'days', 'date'], ...rows.map(r => [r.post, r.type, r.days, r.date])])), 'ghost'), btn('پاک کردن همه', () => { if (confirm('همه داده‌ها پاک شود؟')) { rows = []; save(); } }, 'danger'))),
    card('مقایسه آخرین زمان انتظار', field('نوع ویزا', fv), chart), card('روند یک کنسولگری', tp, trend), card('همه رکوردها', tb));
  function save() { S.set('rows', rows); draw(); }
  function latest(type) { const m = {}; rows.filter(r => r.type === type).forEach(r => { if (!m[r.post] || m[r.post].date <= r.date) m[r.post] = r; }); return Object.values(m).sort((a, b) => a.days - b.days); }
  function draw() {
    const ts = [...new Set([...W.types, ...rows.map(r => r.type)])]; const cur = fv.value || ts[0]; fv.innerHTML = ''; ts.forEach(t => fv.append(h('option', { selected: t === cur }, t)));
    const L = latest(fv.value); const mx = Math.max(1, ...L.map(r => r.days)); chart.innerHTML = '';
    if (!L.length) chart.append(h('p', { class: 'muted' }, 'داده‌ای برای این نوع ویزا نیست.'));
    L.forEach(r => chart.append(h('div', { class: 'barrow' }, h('span', { class: 'ltr' }, r.post), h('div', {}, h('div', { class: 'bar', style: `width:${r.days / mx * 100}%;background:${r.days > 180 ? '#b42318' : r.days > 60 ? '#c88a00' : '#1f7a4d'}` })), h('span', {}, r.days + ' روز · ' + r.date))));
    tb.innerHTML = ''; tb.append(h('table', {}, h('tr', {}, ['Post', 'Type', 'Days', 'Date', ''].map(x => h('th', {}, x))), rows.slice().sort((a, b) => b.date.localeCompare(a.date)).map(r => h('tr', {}, h('td', {}, r.post), h('td', {}, r.type), h('td', {}, r.days), h('td', {}, r.date), h('td', {}, btn('×', () => { rows = rows.filter(x => x !== r); save(); }, 'danger'))))));
    const posts = [...new Set(rows.map(r => r.post))]; const cv = tp.value; tp.innerHTML = ''; posts.forEach(p => tp.append(h('option', { selected: p === cv }, p))); drawT();
  }
  function drawT() {
    trend.innerHTML = ''; const p = tp.value; if (!p) return; const pts = rows.filter(r => r.post === p && r.type === fv.value).sort((a, b) => a.date.localeCompare(b.date)); if (pts.length < 1) { trend.append(h('p', { class: 'muted' }, 'برای این نوع ویزا رکوردی نیست.')); return; }
    const Wd = 900, Ht = 220, mx = Math.max(1, ...pts.map(x => x.days)); const X = i => 40 + (pts.length === 1 ? 0 : i / (pts.length - 1)) * (Wd - 80), Y = v => Ht - 30 - v / mx * (Ht - 60);
    let s = `<svg viewBox="0 0 ${Wd} ${Ht}" width="100%" style="direction:ltr"><polyline fill="none" stroke="#0f5c8c" stroke-width="2.5" points="${pts.map((x, i) => X(i) + ',' + Y(x.days)).join(' ')}"/>`;
    pts.forEach((x, i) => s += `<circle cx="${X(i)}" cy="${Y(x.days)}" r="4" fill="#0f5c8c"/><text x="${X(i)}" y="${Y(x.days) - 8}" font-size="11" text-anchor="middle">${x.days}</text><text x="${X(i)}" y="${Ht - 8}" font-size="10" text-anchor="middle">${x.date}</text>`);
    trend.innerHTML = s + '</svg>';
  }
  draw();
};

/* ---------- 21. hub (links to sibling standalone tools) ---------- */
R.hub = (root) => {
  if (A.intro) root.append(card('معرفی', h('p', {}, A.intro)));
  root.append(card('ابزارهای این مجموعه (هر کدام پروژه‌ای مستقل)', h('div', { class: 'grid2' }, A.links.map(l => h('a', { class: 'tile', href: '../' + l.slug + '/index.html' }, h('b', {}, l.title), h('span', { class: 'muted' }, l.desc))))));
  if (A.facts) root.append(card('نکات کلیدی', h('ul', {}, A.facts.map(f => h('li', {}, f)))));
};

/* ---------- 22. explorer (cards + compare + optional calc) ---------- */
R.explorer = (root) => {
  const q = h('input', { placeholder: 'جست‌وجو…', oninput: () => draw() }); const tags = [...new Set(A.items.flatMap(i => i.tags || []))]; let tag = '';
  const tg = h('div', { class: 'row' }), out = h('div', { class: 'grid3' }), cmp = h('div', { class: 'tablewrap' }); let sel = S.get('sel', []);
  root.append(card('فیلتر', q, tg), card(A.listTitle || 'گزینه‌ها', out), card('مقایسه (حداکثر ۳ مورد)', cmp));
  tg.append(btn('همه', () => { tag = ''; draw(); }, 'ghost'), ...tags.map(t => btn(t, () => { tag = t; draw(); }, 'ghost')));
  if (A.calc) {
    const C = A.calc; const ins = {}; const res = h('div', { class: 'verdict ok' });
    C.fields.forEach(f => ins[f.id] = h('input', { type: 'number', step: 'any', value: S.get('c_' + f.id, f.v), oninput: () => { S.set('c_' + f.id, ins[f.id].value); calc(); } }));
    root.append(card(C.title, h('div', { class: 'grid2' }, C.fields.map(f => field(f.l, ins[f.id]))), res, C.note ? h('p', { class: 'muted' }, C.note, ' ', C.u ? link({ t: 'منبع رسمی', u: C.u }) : '') : null));
    function calc() { const v = {}; C.fields.forEach(f => v[f.id] = +ins[f.id].value || 0); try { const r = new Function(...Object.keys(v), 'return (' + C.formula + ')')(...Object.values(v)); res.className = 'verdict ' + (r.ok ? 'ok' : 'warn'); res.textContent = r.msg; } catch (e) { res.textContent = 'خطا در محاسبه'; } }
    calc();
  }
  const keys = [...new Set(A.items.flatMap(i => Object.keys(i.facts || {})))];
  function draw() {
    const s = q.value.toLowerCase(); out.innerHTML = '';
    A.items.filter(i => (!tag || (i.tags || []).includes(tag)) && (!s || JSON.stringify(i).toLowerCase().includes(s))).forEach(i => out.append(h('div', { class: 'route' }, h('header', {}, h('h3', {}, i.name), h('label', {}, h('input', { type: 'checkbox', checked: sel.includes(i.name), onchange: e => { sel = e.target.checked ? [...sel, i.name].slice(-3) : sel.filter(x => x !== i.name); S.set('sel', sel); draw(); } }), ' مقایسه')),
      h('p', {}, (i.tags || []).map(t => h('span', { class: 'tag' }, t))), h('p', {}, i.summary), i.facts ? h('ul', {}, Object.entries(i.facts).map(([k, v]) => h('li', {}, h('b', {}, k + ': '), v))) : null,
      i.docs ? h('details', {}, h('summary', {}, 'مدارک معمول'), h('ul', {}, i.docs.map(d => h('li', {}, d)))) : null, i.url ? link({ t: 'صفحه رسمی', u: i.url }) : null)));
    cmp.innerHTML = ''; const cs = A.items.filter(i => sel.includes(i.name)); if (!cs.length) { cmp.append(h('p', { class: 'muted' }, 'برای مقایسه، تیک «مقایسه» را روی کارت‌ها بزنید.')); return; }
    cmp.append(h('table', {}, h('tr', {}, h('th', {}), cs.map(c => h('th', {}, c.name))), keys.map(k => h('tr', {}, h('td', {}, h('b', {}, k)), cs.map(c => h('td', {}, (c.facts || {})[k] || '—'))))));
  }
  draw();
};

/* ---------- 23. points calculator ---------- */
R.points = (root) => {
  const P = A.points; const st = S.get('st', {}); const out = h('div'); const pre = h('div'), crit = h('div', { class: 'grid2' });
  root.append(card('شرایط پایه (همه الزامی)', pre), P.bypass ? card('مسیر جایگزین', h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!st.bypass, onchange: e => { st.bypass = e.target.checked; S.set('st', st); run(); } }), h('span', {}, P.bypass))) : null, card('معیارهای امتیازی', crit), card('نتیجه (مطابقت اولیه)', out));
  P.prereq.forEach((p, i) => pre.append(h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!st['p' + i], onchange: e => { st['p' + i] = e.target.checked; S.set('st', st); run(); } }), h('span', {}, p))));
  P.criteria.forEach(c => crit.append(field(c.l, h('select', { onchange: e => { st[c.id] = +e.target.value; S.set('st', st); run(); } }, c.options.map((o, k) => h('option', { value: k, selected: (st[c.id] || 0) === k }, o.l + ' (' + o.p + ' امتیاز)'))))));
  function run() {
    const pts = P.criteria.reduce((a, c) => a + c.options[st[c.id] || 0].p, 0); const preOk = P.prereq.every((p, i) => st['p' + i]);
    out.innerHTML = '';
    if (P.bypass && st.bypass) { out.append(h('div', { class: 'verdict ok' }, P.bypassMsg)); }
    else out.append(h('div', { class: 'verdict ' + (preOk && pts >= P.threshold ? 'ok' : 'warn') }, `امتیاز: ${pts} از حداقل ${P.threshold} — ` + (!preOk ? 'برخی شرایط پایه برقرار نیست.' : pts >= P.threshold ? 'بر اساس معیارهای منتشرشده، مطابقت اولیه دارد.' : `${P.threshold - pts} امتیاز کم دارد.`)));
    out.append(h('div', { class: 'kpis' }, P.criteria.map(c => h('div', { class: 'kpi' }, c.l, h('b', {}, c.options[st[c.id] || 0].p)))), h('p', { class: 'muted' }, P.note, ' ', link(P.source)));
  }
  run();
};

/* ---------- 24. mobility matcher ---------- */
R.mobility = (root) => {
  const M = A.mobility; const st = S.get('st', { sec: [], langs: [], eng: '1' });
  const secs = h('div', { class: 'row' }), langs = h('div', { class: 'row' }), eng = h('select', { onchange: e => { st.eng = e.target.value; S.set('st', st); run(); } }, [['0', 'کمتر از B1'], ['1', 'B1–B2'], ['2', 'C1 یا بالاتر']].map(([v, l]) => h('option', { value: v, selected: st.eng === v }, l))); const out = h('div');
  M.sectors.forEach(s => secs.append(h('label', { class: 'tag' }, h('input', { type: 'checkbox', checked: st.sec.includes(s), onchange: e => { st.sec = e.target.checked ? [...st.sec, s] : st.sec.filter(x => x !== s); S.set('st', st); run(); } }), ' ', s)));
  M.languages.forEach(s => langs.append(h('label', { class: 'tag' }, h('input', { type: 'checkbox', checked: st.langs.includes(s), onchange: e => { st.langs = e.target.checked ? [...st.langs, s] : st.langs.filter(x => x !== s); S.set('st', st); run(); } }), ' ', s)));
  root.append(card('حوزه‌های تخصصی شما', secs), card('زبان‌های محلی که حداقل B1 دارید', langs, field('سطح انگلیسی', eng)), card('کشورهای پیشنهادی (شاخص تقریبی)', out));
  function run() {
    out.innerHTML = '';
    const sc = M.countries.map(c => { const sm = st.sec.filter(s => c.sectors.includes(s)); const lm = c.langs.some(l => st.langs.includes(l)); const s = (st.sec.length ? sm.length / st.sec.length : 0) * 60 + (lm ? 30 : 0) + (+st.eng * c.english * 5); return { c, s: Math.min(100, Math.round(s)), sm, lm }; }).sort((a, b) => b.s - a.s);
    sc.forEach(x => out.append(h('div', { class: 'route' + (x.s < 20 ? ' faded' : '') }, h('header', {}, h('h3', {}, x.c.c), h('span', { class: 'badge' }, x.s + '/100')),
      h('p', {}, 'حوزه‌های منطبق: ', x.sm.length ? x.sm.join('، ') : '—', ' · زبان محلی: ', x.lm ? 'دارید' : 'ندارید', ' · کاربرد انگلیسی در بازار کار: ', ['محدود', 'متوسط', 'زیاد'][x.c.english]),
      x.c.note ? h('p', { class: 'muted' }, x.c.note) : null, h('p', {}, x.c.links.map((l, i) => [i ? ' · ' : '', link(l)])))));
  }
  run();
};

/* ---------- 25. lobby (portfolio index) ---------- */
R.lobby = (root) => {
  const q = h('input', { placeholder: 'جست‌وجو در ' + A.projects.length + ' پروژه…', oninput: () => draw() }); let c = '';
  const cs = [...new Set(A.projects.map(p => p.country))]; const tg = h('div', { class: 'row' }), out = h('div');
  root.append(card(null, h('div', { class: 'kpis' }, h('div', { class: 'kpi' }, 'پروژه‌ها', h('b', {}, A.projects.length)), h('div', { class: 'kpi' }, 'کشور/منطقه', h('b', {}, cs.length)), h('div', { class: 'kpi' }, 'نوع ابزار', h('b', {}, new Set(A.projects.map(p => p.type)).size))), h('div', { class: 'row' }, q), tg), out);
  tg.append(btn('همه', () => { c = ''; draw(); }, 'ghost'), ...cs.map(x => btn(x, () => { c = x; draw(); }, 'ghost')));
  function draw() { const s = q.value.toLowerCase(); out.innerHTML = ''; cs.filter(x => !c || x === c).forEach(x => { const ps = A.projects.filter(p => p.country === x && (!s || (p.title + p.desc + p.type).toLowerCase().includes(s))); if (!ps.length) return; out.append(card(x + ' (' + ps.length + ')', h('div', { class: 'grid2' }, ps.map(p => h('a', { class: 'tile', href: p.slug + '/index.html' }, h('b', {}, p.title), h('span', { class: 'muted' }, p.desc), h('div', {}, h('span', { class: 'tag' }, p.type))))))); }); }
  draw();
};

/* ---------- boot ---------- */
document.title = A.title + ' — Astra Global Migration';
const app = document.getElementById('app');
app.append(h('header', { class: 'top' }, h('div', { class: 'wrap' }, h('div', { class: 'logo' }, A.code || 'AGM'), h('h1', {}, A.title, h('small', {}, A.subtitle || '')), A.type !== 'lobby' ? h('a', { class: 'back', href: '../index.html' }, '← لابی پروژه‌ها') : null)));
const main = h('main', { class: 'wrap' }); app.append(main);
if (A.desc) main.append(h('p', {}, A.desc));
if (A.type !== 'lobby' && A.type !== 'hub') main.append(h('div', { class: 'note' }, 'این ابزار اطلاعات عمومی و «مطابقت اولیه با معیارهای منتشرشده» ارائه می‌دهد و مشاوره حقوقی یا تضمین نتیجه نیست. همیشه با منبع رسمی تطبیق دهید. داده‌های شما فقط در همین مرورگر ذخیره می‌شود.'));
try { (R[A.type] || (() => main.append('نوع ناشناخته: ' + A.type)))(main); } catch (e) { console.error(e); main.append(h('div', { class: 'note' }, 'خطا: ' + e.message)); }
const src = A.sources || [];
app.append(h('footer', { class: 'foot wrap' }, src.length ? [h('b', {}, 'منابع رسمی'), h('ul', {}, src.map(s => h('li', {}, link(s))))] : null,
  h('p', {}, 'آخرین بازبینی منابع: ', A.verified || '—', ' · ', 'پروژه‌ای از مجموعه Astra Global Migration · اجرا کاملاً سمت کاربر (HTML/CSS/JS بدون وابستگی).')));
})();
