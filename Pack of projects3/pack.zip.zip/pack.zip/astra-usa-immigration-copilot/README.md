# Astra USA Immigration Copilot

پروفایل ← مسیرها ← مدارک ← ددلاین ← هزینه ← شغل/دانشگاه ← منابع رسمی

پروفایل خود را وارد کنید تا یک داشبورد شخصی ساخته شود؛ دستیار هوشمند با بازیابی از پایگاه دانش منابع رسمی پاسخ می‌دهد و (با API key اختیاری) پاسخ تولیدی مبتنی بر همان منابع می‌سازد.

**نوع ابزار:** کوپایلت + RAG · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پروفایل ← مسیرها ← مدارک ← ددلاین ← هزینه ← شغل/دانشگاه ← منابع
- دستیار RAG (بازیابی محلی)
- اتصال اختیاری به LLM سازگار با OpenAI

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS — U.S. Citizenship and Immigration Services](https://www.uscis.gov/)
- [U.S. Department of State — U.S. Visas](https://travel.state.gov/content/travel/en/us-visas.html)
- [USCIS Check Case Processing Times](https://egov.uscis.gov/processing-times/)
- [USCIS Fee Schedule (G-1055)](https://www.uscis.gov/g-1055)
- [Visa Bulletin — travel.state.gov](https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
