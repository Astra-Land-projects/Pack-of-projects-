# EU Qualification Navigator

راهنمای شناسایی و معادل‌سازی مدارک

کشور مقصد، هدف و نوع حرفه را انتخاب کنید تا مرجع ارزیابی مدرک و مسیر حرفه‌های قانون‌مند نمایش داده شود.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [ENIC-NARIC Network](https://www.enic-naric.net/)
- [EU Single Market Regulated Professions Database](https://single-market-economy.ec.europa.eu/single-market/services/free-movement-professionals/regulated-professions-database_en)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
