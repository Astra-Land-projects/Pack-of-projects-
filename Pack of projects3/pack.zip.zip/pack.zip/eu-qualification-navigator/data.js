window.APP = {
 "slug": "eu-qualification-navigator",
 "title": "EU Qualification Navigator",
 "subtitle": "راهنمای شناسایی و معادل‌سازی مدارک",
 "type": "navigator",
 "desc": "کشور مقصد، هدف و نوع حرفه را انتخاب کنید تا مرجع ارزیابی مدرک و مسیر حرفه‌های قانون‌مند نمایش داده شود.",
 "sources": [
  {
   "t": "ENIC-NARIC Network",
   "u": "https://www.enic-naric.net/"
  },
  {
   "t": "EU Single Market Regulated Professions Database",
   "u": "https://single-market-economy.ec.europa.eu/single-market/services/free-movement-professionals/regulated-professions-database_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "questions": [
  {
   "id": "dest",
   "q": "کشور مقصد",
   "options": [
    {
     "v": "de",
     "l": "Germany"
    },
    {
     "v": "fr",
     "l": "France"
    },
    {
     "v": "it",
     "l": "Italy"
    },
    {
     "v": "es",
     "l": "Spain"
    },
    {
     "v": "nl",
     "l": "Netherlands"
    },
    {
     "v": "se",
     "l": "Sweden"
    },
    {
     "v": "fi",
     "l": "Finland"
    },
    {
     "v": "at",
     "l": "Austria"
    },
    {
     "v": "pt",
     "l": "Portugal"
    }
   ]
  },
  {
   "id": "reg",
   "q": "حرفه شما",
   "options": [
    {
     "v": "reg",
     "l": "قانون‌مند (پزشک، پرستار، وکیل، معلم، برخی مهندسی‌ها)"
    },
    {
     "v": "free",
     "l": "غیرقانون‌مند (IT، بیشتر مشاغل)"
    },
    {
     "v": "unk",
     "l": "نمی‌دانم"
    }
   ]
  },
  {
   "id": "purpose",
   "q": "هدف ارزیابی",
   "options": [
    {
     "v": "work",
     "l": "کار/ویزا"
    },
    {
     "v": "study",
     "l": "ادامه تحصیل"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Germany — anabin / ZAB / Anerkennung",
   "desc": "بررسی دانشگاه و مدرک در anabin، در صورت نیاز Statement of Comparability از ZAB؛ برای حرفه‌های قانون‌مند Anerkennung در مرجع صلاحیت‌دار.",
   "when": {
    "dest": [
     "de"
    ]
   },
   "steps": [
    "جست‌وجوی دانشگاه در anabin (H+)",
    "ZAB Statement در صورت نبود",
    "حرفه قانون‌مند: Anerkennungs-Finder"
   ],
   "sources": [
    {
     "t": "anabin — KMK database for foreign qualifications",
     "u": "https://anabin.kmk.org/"
    },
    {
     "t": "Anerkennung in Deutschland (recognition portal)",
     "u": "https://www.anerkennung-in-deutschland.de/en/"
    }
   ]
  },
  {
   "name": "France — ENIC-NARIC France",
   "desc": "attestation de comparabilité برای مدارک خارجی.",
   "when": {
    "dest": [
     "fr"
    ]
   },
   "sources": [
    {
     "t": "France Éducation international — ENIC-NARIC France",
     "u": "https://www.france-education-international.fr/en/enic-naric-france"
    }
   ]
  },
  {
   "name": "Italy — CIMEA",
   "desc": "Statement of comparability و ارزیابی CIMEA؛ برای حرفه قانون‌مند وزارت مربوط.",
   "when": {
    "dest": [
     "it"
    ]
   },
   "sources": [
    {
     "t": "CIMEA — ENIC-NARIC Italy",
     "u": "https://www.cimea.it/EN/"
    }
   ]
  },
  {
   "name": "Spain — Homologación / Equivalencia",
   "desc": "وزارت دانشگاه‌ها برای homologación (حرفه قانون‌مند) یا equivalencia.",
   "when": {
    "dest": [
     "es"
    ]
   },
   "sources": [
    {
     "t": "Ministerio de Universidades — Homologación de títulos",
     "u": "https://www.universidades.gob.es/homologacion-equivalencia-titulos-extranjeros-de-educacion-superior/"
    }
   ]
  },
  {
   "name": "Netherlands — Nuffic / IDW",
   "desc": "ارزیابی مدرک برای کار توسط IDW و اطلاعات Nuffic.",
   "when": {
    "dest": [
     "nl"
    ]
   },
   "sources": [
    {
     "t": "Nuffic — Diploma evaluation",
     "u": "https://www.nuffic.nl/en/study-and-work-in-the-netherlands/working-in-the-netherlands-with-a-foreign-diploma"
    },
    {
     "t": "IDW — International Credential Evaluation",
     "u": "https://www.idw.nl/en/"
    }
   ]
  },
  {
   "name": "Sweden — UHR",
   "desc": "Swedish Council for Higher Education ارزیابی مدارک خارجی را انجام می‌دهد.",
   "when": {
    "dest": [
     "se"
    ]
   },
   "sources": [
    {
     "t": "UHR — Recognition of foreign qualifications",
     "u": "https://www.uhr.se/en/start/recognition-of-foreign-qualifications/"
    }
   ]
  },
  {
   "name": "Finland — EDUFI (OPH)",
   "desc": "Finnish National Agency for Education برای شناسایی مدارک.",
   "when": {
    "dest": [
     "fi"
    ]
   },
   "sources": [
    {
     "t": "OPH — Recognition of qualifications",
     "u": "https://www.oph.fi/en/services/recognition-and-international-comparability-qualifications"
    }
   ]
  },
  {
   "name": "Austria — ENIC NARIC Austria",
   "desc": "ارزیابی و نوستریفیکاسیون برای حرفه‌های قانون‌مند.",
   "when": {
    "dest": [
     "at"
    ]
   },
   "sources": [
    {
     "t": "ENIC NARIC Austria",
     "u": "https://www.aais.at/en/"
    }
   ]
  },
  {
   "name": "Portugal — DGES",
   "desc": "شناسایی مدارک آموزش عالی (reconhecimento).",
   "when": {
    "dest": [
     "pt"
    ]
   },
   "sources": [
    {
     "t": "DGES — Reconhecimento",
     "u": "https://www.dges.gov.pt/pt/pagina/reconhecimento"
    }
   ]
  },
  {
   "name": "حرفه قانون‌مند — مجوز اشتغال",
   "desc": "برای حرفه‌های قانون‌مند علاوه بر ارزیابی مدرک، مجوز مرجع حرفه‌ای (مثلاً نظام پزشکی/پرستاری) لازم است؛ پایگاه EU Regulated Professions را ببینید.",
   "when": {
    "reg": [
     "reg",
     "unk"
    ],
    "purpose": [
     "work"
    ]
   },
   "sources": [
    {
     "t": "EU Single Market Regulated Professions Database",
     "u": "https://single-market-economy.ec.europa.eu/single-market/services/free-movement-professionals/regulated-professions-database_en"
    }
   ]
  },
  {
   "name": "ادامه تحصیل — پذیرش دانشگاه",
   "desc": "برای تحصیل، دانشگاه مقصد خودش مدارک را ارزیابی می‌کند (گاهی از طریق uni-assist در آلمان).",
   "when": {
    "purpose": [
     "study"
    ]
   },
   "sources": [
    {
     "t": "uni-assist",
     "u": "https://www.uni-assist.de/en/"
    },
    {
     "t": "ENIC-NARIC Network",
     "u": "https://www.enic-naric.net/"
    }
   ]
  }
 ],
 "id": "astra-eu-qualification-navigator",
 "verified": "2026-10-01"
};
