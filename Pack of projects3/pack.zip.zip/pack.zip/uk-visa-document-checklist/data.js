window.APP = {
 "slug": "uk-visa-document-checklist",
 "title": "UK Visa Document Checklist",
 "subtitle": "چک‌لیست مدارک ویزای بریتانیا",
 "type": "checklist",
 "desc": "مدارک معمول ویزاهای Visitor، Student، Skilled Worker، Graduate و Partner.",
 "sources": [
  {
   "t": "GOV.UK — Visas and immigration",
   "u": "https://www.gov.uk/browse/visas-immigration"
  },
  {
   "t": "GOV.UK — Tuberculosis tests for visa applicants",
   "u": "https://www.gov.uk/tb-test-visa"
  }
 ],
 "code": "UK",
 "country": "UK",
 "common": [
  "گذرنامه معتبر",
  "رسید پرداخت هزینه و IHS (در صورت شمول)",
  {
   "t": "نتیجه تست TB برای اتباع کشورهای مشمول",
   "opt": true
  },
  "ترجمه انگلیسی/ولزی کامل برای اسناد دیگر زبان‌ها"
 ],
 "cases": {
  "visitor": {
   "label": "Standard Visitor",
   "items": [
    "صورتحساب بانکی",
    "نامه کارفرما/مرخصی",
    "برنامه سفر و اقامت",
    "دعوت‌نامه (در صورت وجود)"
   ],
   "source": {
    "t": "GOV.UK — Standard Visitor visa",
    "u": "https://www.gov.uk/standard-visitor"
   }
  },
  "student": {
   "label": "Student",
   "items": [
    "CAS",
    "اثبات مالی ۲۸ روزه",
    "مدرک زبان (طبق CAS)",
    {
     "t": "ATAS",
     "opt": true
    },
    {
     "t": "رضایت والدین (زیر ۱۸)",
     "opt": true
    }
   ],
   "source": {
    "t": "GOV.UK — Student visa",
    "u": "https://www.gov.uk/student-visa"
   }
  },
  "sw": {
   "label": "Skilled Worker",
   "items": [
    "CoS",
    "مدرک زبان انگلیسی",
    {
     "t": "گواهی سوءپیشینه (مشاغل آموزش/سلامت/مراقبت)",
     "opt": true
    },
    {
     "t": "اثبات مالی (در صورت عدم certify کارفرما)",
     "opt": true
    }
   ],
   "source": {
    "t": "GOV.UK — Skilled Worker visa",
    "u": "https://www.gov.uk/skilled-worker-visa"
   }
  },
  "grad": {
   "label": "Graduate",
   "items": [
    "تأیید تکمیل دوره توسط دانشگاه به Home Office",
    "eVisa/وضعیت فعلی Student"
   ],
   "source": {
    "t": "GOV.UK — Graduate visa",
    "u": "https://www.gov.uk/graduate-visa"
   }
  },
  "partner": {
   "label": "Partner",
   "items": [
    "اثبات رابطه",
    "اثبات الزامات مالی",
    "مدرک زبان",
    "اثبات مسکن"
   ],
   "source": {
    "t": "GOV.UK — Family visas",
    "u": "https://www.gov.uk/uk-family-visa"
   }
  }
 },
 "id": "astra-uk-visa-document-checklist",
 "verified": "2026-10-01"
};
