window.APP = {
 "slug": "netherlands-migration-hub",
 "title": "Netherlands Migration Hub",
 "subtitle": "مرکز ابزارهای هلند",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "IND — Immigration and Naturalisation Service",
   "u": "https://ind.nl/en"
  },
  {
   "t": "Government.nl — Immigration",
   "u": "https://www.government.nl/topics/immigration-to-the-netherlands"
  },
  {
   "t": "Study in NL (Nuffic)",
   "u": "https://www.studyinnl.org/"
  }
 ],
 "code": "NL",
 "country": "Netherlands",
 "intro": "ابزارهای هلند به IND، Netherlands Worldwide، Study in NL و Nuffic متصل‌اند.",
 "links": [
  {
   "slug": "netherlands-study-planner",
   "title": "Netherlands Study Planner",
   "desc": "برنامه تحصیل در هلند"
  },
  {
   "slug": "netherlands-job-matcher",
   "title": "Netherlands Job Matcher",
   "desc": "تطبیق رزومه با آگهی‌های هلند + بررسی sponsor"
  },
  {
   "slug": "netherlands-residence-planner",
   "title": "Netherlands Residence Planner",
   "desc": "تایم‌لاین اقامت هلند"
  },
  {
   "slug": "netherlands-housing-search-dashboard",
   "title": "Netherlands Housing Search Dashboard",
   "desc": "داشبورد جست‌وجوی مسکن هلند"
  },
  {
   "slug": "netherlands-relocation-cost-calculator",
   "title": "Netherlands Relocation Cost Calculator",
   "desc": "برآورد هزینه انتقال به هلند"
  }
 ],
 "id": "astra-netherlands-migration-hub",
 "verified": "2026-10-01"
};
