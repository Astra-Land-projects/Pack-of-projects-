window.APP = {
 "slug": "europe-cv-converter",
 "title": "Europe CV Converter",
 "subtitle": "تبدیل رزومه به قالب‌های کشورهای مختلف",
 "type": "cvbuilder",
 "desc": "یک بار اطلاعات را وارد کنید و رزومه را در قالب Europass، آلمان، بریتانیا، فرانسه، هلند، اسپانیا و ایتالیا با رعایت عرف هر کشور (عکس، تاریخ تولد، ترتیب بخش‌ها) پیش‌نمایش، چاپ PDF یا دانلود کنید.",
 "sources": [
  {
   "t": "Europass",
   "u": "https://europass.europa.eu/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "templates": [
  {
   "id": "europass",
   "name": "Europass (EU standard)",
   "photo": false,
   "dob": false,
   "order": [
    "profile",
    "experience",
    "education",
    "languages",
    "skills",
    "extra"
   ],
   "pages": "۲ تا ۳ صفحه",
   "labels": {
    "languages": "Language skills (CEFR)"
   },
   "notes": [
    "ساختار رسمی EU؛ زبان‌ها با سطح CEFR",
    "عکس اختیاری است",
    "می‌توانید در europass.europa.eu نسخه رسمی بسازید"
   ]
  },
  {
   "id": "de",
   "name": "Germany — Lebenslauf (tabellarisch)",
   "photo": true,
   "dob": true,
   "order": [
    "experience",
    "education",
    "skills",
    "languages",
    "extra"
   ],
   "pages": "۱ تا ۲ صفحه",
   "labels": {
    "experience": "Berufserfahrung",
    "education": "Ausbildung",
    "skills": "Kenntnisse",
    "languages": "Sprachkenntnisse",
    "extra": "Weiterbildung"
   },
   "footer": "{city}, {date} — Unterschrift",
   "notes": [
    "ترتیب معکوس زمانی، جدولی و دقیق با ماه/سال",
    "عکس و تاریخ تولد رایج اما قانوناً الزامی نیست (AGG)",
    "در پایان محل، تاریخ و امضا",
    "همراه با Anschreiben یک صفحه‌ای"
   ]
  },
  {
   "id": "uk",
   "name": "United Kingdom — CV",
   "photo": false,
   "dob": false,
   "order": [
    "profile",
    "experience",
    "skills",
    "education",
    "extra"
   ],
   "pages": "حداکثر ۲ صفحه",
   "notes": [
    "بدون عکس، سن، تأهل",
    "Personal statement کوتاه در ابتدا",
    "دستاوردهای عددی و مرتبط با آگهی"
   ]
  },
  {
   "id": "fr",
   "name": "France — CV",
   "photo": true,
   "dob": false,
   "order": [
    "profile",
    "experience",
    "education",
    "languages",
    "skills",
    "extra"
   ],
   "pages": "۱ صفحه (جوان) تا ۲ صفحه",
   "labels": {
    "profile": "Profil",
    "experience": "Expérience professionnelle",
    "education": "Formation",
    "languages": "Langues",
    "skills": "Compétences",
    "extra": "Certifications"
   },
   "notes": [
    "CV یک صفحه‌ای رایج است",
    "عکس اختیاری اما رایج",
    "Lettre de motivation رسمی همراه شود"
   ]
  },
  {
   "id": "nl",
   "name": "Netherlands — CV",
   "photo": false,
   "dob": false,
   "order": [
    "profile",
    "experience",
    "education",
    "skills",
    "languages",
    "extra"
   ],
   "pages": "۲ صفحه",
   "notes": [
    "مستقیم و مختصر",
    "Hobbies کوتاه رایج است",
    "انگلیسی برای شرکت‌های بین‌المللی پذیرفته است"
   ]
  },
  {
   "id": "es",
   "name": "Spain — Currículum",
   "photo": true,
   "dob": false,
   "order": [
    "profile",
    "experience",
    "education",
    "languages",
    "skills",
    "extra"
   ],
   "pages": "۱ تا ۲ صفحه",
   "labels": {
    "profile": "Perfil",
    "experience": "Experiencia",
    "education": "Formación",
    "languages": "Idiomas",
    "skills": "Competencias"
   },
   "notes": [
    "عکس رایج است",
    "سطح زبان‌ها را دقیق ذکر کنید"
   ]
  },
  {
   "id": "it",
   "name": "Italy — Curriculum Vitae",
   "photo": true,
   "dob": true,
   "order": [
    "experience",
    "education",
    "languages",
    "skills",
    "extra"
   ],
   "pages": "۲ صفحه",
   "labels": {
    "experience": "Esperienza lavorativa",
    "education": "Istruzione",
    "languages": "Lingue",
    "skills": "Competenze"
   },
   "footer": "Autorizzo il trattamento dei miei dati personali ai sensi del Regolamento UE 2016/679 (GDPR).",
   "notes": [
    "قالب Europass بسیار رایج است",
    "جمله رضایت پردازش داده (GDPR) در پایان رایج است"
   ]
  }
 ],
 "id": "astra-europe-cv-converter",
 "verified": "2026-10-01"
};
