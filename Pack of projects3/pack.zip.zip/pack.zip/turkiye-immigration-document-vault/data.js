window.APP = {
 "slug": "turkiye-immigration-document-vault",
 "title": "Türkiye Immigration Document Vault",
 "subtitle": "مدیریت امن اسناد مهاجرتی ترکیه",
 "type": "vault",
 "desc": "کارت اقامت، بیمه، اجاره‌نامه و اسناد آپوستیل‌شده را رمزگذاری‌شده ذخیره و انقضاها را پیگیری کنید.",
 "sources": [
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "vault": {
  "warnDays": 90,
  "categories": [
   "Pasaport",
   "İkamet Kartı",
   "Sağlık Sigortası",
   "Kira Sözleşmesi",
   "Apostil/Tercüme",
   "Öğrenci Belgesi",
   "Çalışma İzni",
   "Vergi/Banka",
   "Other"
  ],
  "suggested": [
   {
    "t": "گذرنامه",
    "cat": "Pasaport"
   },
   {
    "t": "کارت اقامت",
    "cat": "İkamet Kartı"
   },
   {
    "t": "بیمه درمانی",
    "cat": "Sağlık Sigortası"
   },
   {
    "t": "قرارداد اجاره محضری",
    "cat": "Kira Sözleşmesi"
   },
   {
    "t": "اسناد آپوستیل و ترجمه",
    "cat": "Apostil/Tercüme"
   },
   {
    "t": "مجوز کار",
    "cat": "Çalışma İzni"
   }
  ]
 },
 "id": "astra-turkiye-immigration-document-vault",
 "verified": "2026-10-01"
};
