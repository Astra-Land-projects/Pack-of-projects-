window.APP = {
 "slug": "eu-migration-navigator",
 "title": "EU Migration Navigator",
 "subtitle": "مسیرها، مدارک، هزینه و منابع رسمی کشورهای اروپایی",
 "type": "copilot",
 "desc": "پروفایل خود را وارد کنید تا مسیرهای مرتبط در آلمان، فرانسه، هلند، اسپانیا، پرتغال، سوئد، فنلاند و اتریش رتبه‌بندی شود؛ داشبورد شخصی و دستیار RAG بر اساس منابع رسمی.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  },
  {
   "t": "Your Europe",
   "u": "https://europa.eu/youreurope/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "questions": [
  {
   "id": "goal",
   "q": "هدف",
   "options": [
    {
     "v": "work",
     "l": "کار"
    },
    {
     "v": "study",
     "l": "تحصیل"
    },
    {
     "v": "seek",
     "l": "جست‌وجوی کار"
    },
    {
     "v": "remote",
     "l": "کار از راه دور / دیجیتال نومد"
    },
    {
     "v": "family",
     "l": "پیوستن به خانواده"
    }
   ]
  },
  {
   "id": "edu",
   "q": "تحصیلات",
   "options": [
    {
     "v": "voc",
     "l": "فنی‌وحرفه‌ای"
    },
    {
     "v": "ba",
     "l": "کارشناسی"
    },
    {
     "v": "ma",
     "l": "ارشد/دکتری"
    }
   ]
  },
  {
   "id": "offer",
   "q": "پیشنهاد کار",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "lang",
   "q": "زبان",
   "options": [
    {
     "v": "en",
     "l": "فقط انگلیسی"
    },
    {
     "v": "de",
     "l": "آلمانی"
    },
    {
     "v": "fr",
     "l": "فرانسوی"
    },
    {
     "v": "es",
     "l": "اسپانیایی/پرتغالی"
    },
    {
     "v": "it",
     "l": "ایتالیایی"
    }
   ]
  },
  {
   "id": "income",
   "q": "درآمد از راه دور ثابت",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Germany — EU Blue Card",
   "desc": "پیشنهاد کار با مدرک دانشگاهی شناخته‌شده و حقوق بالاتر از آستانه سالانه.",
   "when": {
    "goal": [
     "work"
    ],
    "edu": [
     "ba",
     "ma"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "بررسی مدرک در anabin",
    "قرارداد کار",
    "درخواست ویزا در Consular Services Portal",
    "ثبت آدرس و دریافت کارت"
   ],
   "docs": [
    "گذرنامه",
    "قرارداد کار",
    "مدرک و ارزیابی anabin/ZAB",
    "بیمه درمانی"
   ],
   "sources": [
    {
     "t": "Make it in Germany — EU Blue Card",
     "u": "https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card"
    },
    {
     "t": "anabin — KMK database for foreign qualifications",
     "u": "https://anabin.kmk.org/"
    },
    {
     "t": "Consular Services Portal (digital visa application)",
     "u": "https://digital.diplo.de/visa"
    }
   ],
   "timeline": [
    {
     "t": "قرارداد کار",
     "days": 30
    },
    {
     "t": "نوبت و درخواست ویزا",
     "days": 60
    },
    {
     "t": "صدور ویزا",
     "days": 45
    },
    {
     "t": "ورود و Anmeldung",
     "days": 14
    },
    {
     "t": "صدور کارت اقامت",
     "days": 60
    }
   ],
   "costs": [
    {
     "t": "هزینه ویزای ملی",
     "u": "https://www.auswaertiges-amt.de/en/visa-service"
    }
   ]
  },
  {
   "name": "Germany — Opportunity Card",
   "desc": "کارت فرصت برای جست‌وجوی کار تا یک سال با سیستم امتیازی (حداقل ۶ امتیاز) یا مدرک کاملاً شناخته‌شده.",
   "when": {
    "goal": [
     "seek",
     "work"
    ],
    "offer": [
     "no"
    ],
    "edu": [
     "voc",
     "ba",
     "ma"
    ]
   },
   "steps": [
    "محاسبه امتیاز",
    "اثبات مالی (حساب مسدود)",
    "درخواست ویزا"
   ],
   "docs": [
    "مدرک تحصیلی + anabin",
    "مدرک زبان A1 آلمانی یا B2 انگلیسی",
    "حساب مسدود/تعهدنامه",
    "بیمه"
   ],
   "sources": [
    {
     "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
     "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
    }
   ],
   "timeline": [
    {
     "t": "ارزیابی مدرک",
     "days": 60
    },
    {
     "t": "حساب مسدود",
     "days": 14
    },
    {
     "t": "ویزا",
     "days": 60
    },
    {
     "t": "جست‌وجوی کار در آلمان",
     "days": 365
    }
   ],
   "costs": [
    {
     "t": "حساب مسدود (۲۰۲۶: ۱٬۰۹۱ یورو در ماه)",
     "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
    }
   ]
  },
  {
   "name": "France — Passeport talent",
   "desc": "کارت چندساله برای متخصصان، Blue Card، پژوهشگران، بنیان‌گذاران و سرمایه‌گذاران.",
   "when": {
    "goal": [
     "work"
    ],
    "edu": [
     "ma",
     "ba"
    ],
    "lang": [
     "fr",
     "en"
    ]
   },
   "steps": [
    "تعیین زیرشاخه talent",
    "درخواست در France-Visas",
    "اعتبارسنجی پس از ورود در ANEF"
   ],
   "docs": [
    "قرارداد/پروژه",
    "مدارک تحصیلی",
    "گذرنامه"
   ],
   "sources": [
    {
     "t": "Welcome to France — Talent passport",
     "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
    },
    {
     "t": "France-Visas (official visa website)",
     "u": "https://france-visas.gouv.fr/"
    },
    {
     "t": "ANEF — Administration numérique pour les étrangers en France",
     "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
    }
   ]
  },
  {
   "name": "Netherlands — Highly Skilled Migrant",
   "desc": "کارفرمای sponsor شناخته‌شده IND و حقوق بالاتر از آستانه سنی.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ],
    "lang": [
     "en"
    ]
   },
   "steps": [
    "بررسی sponsor بودن کارفرما",
    "درخواست توسط کارفرما",
    "MVV و ورود",
    "ثبت در شهرداری (BSN)"
   ],
   "docs": [
    "قرارداد",
    "گذرنامه",
    "اسناد مدنی آپوستیل"
   ],
   "sources": [
    {
     "t": "IND — Highly skilled migrant",
     "u": "https://ind.nl/en/residence-permits/work/highly-skilled-migrant"
    },
    {
     "t": "IND — Public register of recognised sponsors",
     "u": "https://ind.nl/en/public-register-recognised-sponsors"
    },
    {
     "t": "IND — Required amounts income requirements",
     "u": "https://ind.nl/en/required-amounts-income-requirements"
    }
   ],
   "timeline": [
    {
     "t": "درخواست IND",
     "days": 14
    },
    {
     "t": "تصمیم IND",
     "days": 30
    },
    {
     "t": "MVV",
     "days": 14
    },
    {
     "t": "ورود و BSN",
     "days": 14
    }
   ]
  },
  {
   "name": "Netherlands — Orientation year",
   "desc": "پس از فارغ‌التحصیلی از دانشگاه هلند یا دانشگاه‌های برتر جهان، یک سال جست‌وجوی کار.",
   "when": {
    "goal": [
     "seek"
    ],
    "edu": [
     "ba",
     "ma"
    ]
   },
   "steps": [
    "بررسی شرایط مدرک",
    "درخواست IND"
   ],
   "docs": [
    "مدرک تحصیلی"
   ],
   "sources": [
    {
     "t": "IND — Orientation year (zoekjaar)",
     "u": "https://ind.nl/en/residence-permits/work/residence-permit-for-orientation-year"
    }
   ]
  },
  {
   "name": "Spain — International teleworking (Digital Nomad)",
   "desc": "کار از راه دور برای شرکت‌های خارج از اسپانیا با درآمد حداقلی وابسته به SMI.",
   "when": {
    "goal": [
     "remote"
    ],
    "income": [
     "yes"
    ]
   },
   "steps": [
    "اثبات رابطه کاری ≥۳ ماه",
    "اثبات درآمد",
    "درخواست از کنسولگری یا UGE"
   ],
   "docs": [
    "قرارداد/فاکتورها",
    "مدرک تحصیلی یا ۳ سال سابقه",
    "سوءپیشینه",
    "بیمه"
   ],
   "sources": [
    {
     "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
     "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
    }
   ]
  },
  {
   "name": "Spain — Highly Qualified Professional",
   "desc": "کارفرمایان مشمول Ley 14/2013 برای متخصصان بسیار ماهر از طریق UGE-CE.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ],
    "edu": [
     "ba",
     "ma"
    ]
   },
   "steps": [
    "درخواست توسط کارفرما در UGE-CE",
    "ویزا"
   ],
   "docs": [
    "قرارداد",
    "مدرک"
   ],
   "sources": [
    {
     "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
     "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
    }
   ]
  },
  {
   "name": "Portugal — Digital nomad (D8)/Highly qualified (D3)",
   "desc": "ویزاهای ملی پرتغال برای کار از راه دور و نیروی متخصص.",
   "when": {
    "goal": [
     "remote",
     "work"
    ],
    "lang": [
     "es",
     "en"
    ]
   },
   "steps": [
    "انتخاب نوع ویزا",
    "درخواست از کنسولگری",
    "اقامت در AIMA"
   ],
   "docs": [
    "اثبات درآمد/قرارداد",
    "سوءپیشینه",
    "بیمه"
   ],
   "sources": [
    {
     "t": "Vistos — Ministério dos Negócios Estrangeiros (Portugal)",
     "u": "https://vistos.mne.gov.pt/"
    },
    {
     "t": "AIMA — Agência para a Integração, Migrações e Asilo (Portugal)",
     "u": "https://aima.gov.pt/en"
    }
   ]
  },
  {
   "name": "Sweden — Work permit",
   "desc": "مجوز کار با پیشنهاد کار و حقوق/بیمه طبق شرایط سوئد.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "آگهی و پیشنهاد کار",
    "درخواست آنلاین Migrationsverket"
   ],
   "docs": [
    "قرارداد",
    "گذرنامه"
   ],
   "sources": [
    {
     "t": "Migrationsverket (Sweden)",
     "u": "https://www.migrationsverket.se/English/Startpage.html"
    }
   ]
  },
  {
   "name": "Finland — Specialist / Blue Card",
   "desc": "متخصصان با رسیدگی سریع طبق Migri.",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ],
    "edu": [
     "ba",
     "ma"
    ]
   },
   "steps": [
    "درخواست آنلاین Enter Finland",
    "شناسایی در سفارت"
   ],
   "docs": [
    "قرارداد",
    "مدرک"
   ],
   "sources": [
    {
     "t": "Migri — Finnish Immigration Service",
     "u": "https://migri.fi/en/home"
    },
    {
     "t": "Work in Finland",
     "u": "https://www.workinfinland.com/en"
    }
   ]
  },
  {
   "name": "Austria — Red-White-Red Card",
   "desc": "کارت امتیازی برای نیروی بسیار ماهر، مشاغل کمبود و سایر کارگران کلیدی.",
   "when": {
    "goal": [
     "work",
     "seek"
    ],
    "lang": [
     "de",
     "en"
    ]
   },
   "steps": [
    "محاسبه امتیاز",
    "درخواست"
   ],
   "docs": [
    "مدارک امتیاز",
    "پیشنهاد کار (اکثر زیرشاخه‌ها)"
   ],
   "sources": [
    {
     "t": "Migration.gv.at — Red-White-Red Card",
     "u": "https://www.migration.gv.at/en/types-of-immigration/permanent-immigration/"
    }
   ]
  },
  {
   "name": "Study — Germany/France/Italy/NL…",
   "desc": "ویزای دانشجویی ملی با پذیرش دانشگاه، اثبات مالی و بیمه.",
   "when": {
    "goal": [
     "study"
    ]
   },
   "steps": [
    "پذیرش",
    "اثبات مالی (مثلاً حساب مسدود آلمان)",
    "ویزا",
    "اقامت دانشجویی"
   ],
   "docs": [
    "پذیرش‌نامه",
    "مدرک مالی",
    "بیمه",
    "مدرک زبان"
   ],
   "sources": [
    {
     "t": "Study in Europe (European Commission)",
     "u": "https://education.ec.europa.eu/study-in-europe"
    },
    {
     "t": "DAAD — Study in Germany",
     "u": "https://www.daad.de/en/"
    },
    {
     "t": "Campus France",
     "u": "https://www.campusfrance.org/en"
    },
    {
     "t": "Universitaly",
     "u": "https://www.universitaly.it/"
    },
    {
     "t": "Study in NL (Nuffic)",
     "u": "https://www.studyinnl.org/"
    }
   ],
   "timeline": [
    {
     "t": "اپلای",
     "days": 120
    },
    {
     "t": "پذیرش",
     "days": 60
    },
    {
     "t": "ویزا",
     "days": 60
    },
    {
     "t": "ورود و ثبت اقامت",
     "days": 30
    }
   ]
  },
  {
   "name": "Family reunification",
   "desc": "پیوستن به همسر/والد دارای اقامت در کشور عضو طبق قواعد ملی.",
   "when": {
    "goal": [
     "family"
    ]
   },
   "steps": [
    "بررسی شرایط کشور",
    "مدارک مدنی آپوستیل",
    "درخواست"
   ],
   "docs": [
    "سند ازدواج/تولد",
    "مدارک درآمد و مسکن حامی"
   ],
   "sources": [
    {
     "t": "EU Immigration Portal (European Commission)",
     "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
    }
   ]
  }
 ],
 "kb": [
  {
   "t": "EU Blue Card",
   "text": "Blue Card در همه کشورهای عضو به‌جز دانمارک و ایرلند اجرا می‌شود؛ طبق دستورالعمل ۲۰۲۱/۱۸۸۳ قرارداد حداقل ۶ ماه و آستانه حقوق بین ۱ تا ۱٫۶ برابر میانگین حقوق ناخالص سالانه کشور تعیین می‌شود.",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en",
   "k": "blue card salary threshold"
  },
  {
   "t": "تحرک Blue Card",
   "text": "پس از ۱۲ ماه اقامت با Blue Card در یک کشور، دارنده می‌تواند با رویه ساده‌تر به کشور عضو دیگر منتقل شود.",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en",
   "k": "mobility move another country blue card"
  },
  {
   "t": "Opportunity Card آلمان",
   "text": "دو مسیر: مدرک کاملاً شناخته‌شده در آلمان (بدون امتیاز) یا سیستم امتیازی با حداقل ۶ امتیاز به‌علاوه مدرک معتبر و A1 آلمانی یا B2 انگلیسی. اثبات مالی ۲۰۲۶: ۱٬۰۹۱ یورو خالص در ماه.",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card",
   "k": "chancenkarte opportunity card points"
  },
  {
   "t": "EURES",
   "text": "EURES پورتال کاریابی اروپایی است که آگهی‌های خدمات اشتغال عمومی کشورهای عضو را جمع می‌کند و اطلاعات زندگی و کار ارائه می‌دهد.",
   "u": "https://eures.europa.eu/",
   "k": "jobs job search eures"
  },
  {
   "t": "شناسایی مدارک",
   "text": "برای ارزیابی مدارک تحصیلی به مرکز ENIC-NARIC کشور مقصد مراجعه کنید؛ برای حرفه‌های قانون‌مند (پزشکی، پرستاری، مهندسی در برخی کشورها) مجوز مرجع صلاحیت‌دار لازم است.",
   "u": "https://www.enic-naric.net/",
   "k": "recognition degree diploma qualification"
  },
  {
   "t": "Europass",
   "text": "Europass ابزار رسمی اتحادیه اروپا برای ساخت CV و نامه انگیزشی با قالب استاندارد است.",
   "u": "https://europass.europa.eu/",
   "k": "cv resume europass"
  },
  {
   "t": "ویزای شنگن",
   "text": "ویزای کوتاه‌مدت شنگن برای اقامت تا ۹۰ روز در هر ۱۸۰ روز است و برای کار یا تحصیل طولانی ویزای ملی (D) لازم است.",
   "u": "https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en",
   "k": "schengen short stay 90 days"
  },
  {
   "t": "Erasmus Mundus",
   "text": "برنامه‌های Erasmus Mundus Joint Masters بورسیه کامل برای دانشجویان سراسر جهان ارائه می‌دهند؛ درخواست مستقیم به کنسرسیوم هر برنامه است.",
   "u": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en",
   "k": "scholarship erasmus master"
  },
  {
   "t": "دیجیتال نومد اسپانیا",
   "text": "ویزای teletrabajo de carácter internacional برای کار از راه دور برای شرکت خارج از اسپانیا است؛ درآمد حداقل معادل ۲۰۰٪ حداقل دستمزد ماهانه (SMI) است.",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/",
   "k": "digital nomad spain remote"
  },
  {
   "t": "HSM هلند",
   "text": "در مسیر Highly Skilled Migrant کارفرما باید sponsor شناخته‌شده IND باشد و حقوق از آستانه سالانه اعلام‌شده (وابسته به سن) بیشتر باشد.",
   "u": "https://ind.nl/en/residence-permits/work/highly-skilled-migrant",
   "k": "netherlands kennismigrant highly skilled"
  }
 ],
 "opportunities": [
  {
   "t": "EURES",
   "u": "https://eures.europa.eu/",
   "d": "شغل در اروپا"
  },
  {
   "t": "Study in Europe",
   "u": "https://education.ec.europa.eu/study-in-europe",
   "d": "تحصیل"
  },
  {
   "t": "Erasmus Mundus",
   "u": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en",
   "d": "بورسیه"
  },
  {
   "t": "Make it in Germany",
   "u": "https://www.make-it-in-germany.com/en/",
   "d": "آلمان"
  }
 ],
 "id": "astra-eu-migration-navigator",
 "verified": "2026-10-01"
};
