# UK Skilled Work Explorer

بررسی اطلاعات مسیر Skilled Worker

اجزای مسیر Skilled Worker را مرور کنید و حقوق پیشنهادی را با آستانه عمومی و نرخ شغل بسنجید.

**نوع ابزار:** اکسپلورر + محاسبه‌گر · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- کارت‌ها با فیلتر و جست‌وجو
- مقایسه تا ۳ گزینه
- محاسبه‌گر مطابقت اولیه

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Skilled Worker visa](https://www.gov.uk/skilled-worker-visa)
- [GOV.UK — Skilled Worker eligible occupations](https://www.gov.uk/government/publications/skilled-worker-visa-eligible-occupations)
- [GOV.UK — Register of licensed sponsors: workers](https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers)
- [GOV.UK — Skilled Worker: your job](https://www.gov.uk/skilled-worker-visa/your-job)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
