window.APP = {
 "slug": "uk-skilled-work-explorer",
 "title": "UK Skilled Work Explorer",
 "subtitle": "بررسی اطلاعات مسیر Skilled Worker",
 "type": "explorer",
 "desc": "اجزای مسیر Skilled Worker را مرور کنید و حقوق پیشنهادی را با آستانه عمومی و نرخ شغل بسنجید.",
 "sources": [
  {
   "t": "GOV.UK — Skilled Worker visa",
   "u": "https://www.gov.uk/skilled-worker-visa"
  },
  {
   "t": "GOV.UK — Skilled Worker eligible occupations",
   "u": "https://www.gov.uk/government/publications/skilled-worker-visa-eligible-occupations"
  },
  {
   "t": "GOV.UK — Register of licensed sponsors: workers",
   "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
  },
  {
   "t": "GOV.UK — Skilled Worker: your job",
   "u": "https://www.gov.uk/skilled-worker-visa/your-job"
  }
 ],
 "code": "UK",
 "country": "UK",
 "listTitle": "اجزای مسیر",
 "items": [
  {
   "name": "Sponsor دارای مجوز",
   "tags": [
    "الزامی"
   ],
   "summary": "کارفرما باید در Register of licensed sponsors باشد و CoS صادر کند.",
   "facts": {
    "منبع": "Register of licensed sponsors (CSV رسمی)"
   },
   "url": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
  },
  {
   "name": "شغل واجد شرایط",
   "tags": [
    "الزامی"
   ],
   "summary": "کد شغلی (SOC 2020) باید در فهرست مشاغل واجد شرایط و در سطح مهارت لازم باشد.",
   "facts": {
    "منبع": "Skilled Worker eligible occupations"
   },
   "url": "https://www.gov.uk/government/publications/skilled-worker-visa-eligible-occupations"
  },
  {
   "name": "حقوق",
   "tags": [
    "الزامی"
   ],
   "summary": "بیشترِ آستانه عمومی (۴۱٬۷۰۰ پوند برای CoS از ۲۲ ژوئیه ۲۰۲۵) و نرخ جاری شغل؛ استثنائات کاهش‌یافته برای Immigration Salary List، افراد جدیدالورود، PhD و…",
   "facts": {
    "عمومی": "£41,700",
    "Immigration Salary List": "£33,400 (حداقل)"
   },
   "url": "https://www.gov.uk/skilled-worker-visa/your-job"
  },
  {
   "name": "زبان انگلیسی",
   "tags": [
    "الزامی"
   ],
   "summary": "اثبات سطح لازم از طریق SELT، مدرک تحصیلی انگلیسی‌زبان یا تابعیت کشورهای مشخص.",
   "url": "https://www.gov.uk/guidance/prove-your-english-language-abilities-with-a-secure-english-language-test-selt"
  },
  {
   "name": "IHS و هزینه درخواست",
   "tags": [
    "هزینه"
   ],
   "summary": "هزینه ویزا بر اساس مدت و Immigration Health Surcharge سالانه.",
   "url": "https://www.gov.uk/government/publications/visa-regulations-revised-table"
  }
 ],
 "calc": {
  "title": "بررسی حقوق در برابر آستانه",
  "fields": [
   {
    "id": "sal",
    "l": "حقوق سالانه پیشنهادی (GBP)",
    "v": 45000
   },
   {
    "id": "gen",
    "l": "آستانه عمومی (GBP)",
    "v": 41700
   },
   {
    "id": "occ",
    "l": "نرخ جاری شغل (GBP) — از جدول رسمی",
    "v": 0
   }
  ],
  "formula": "(()=>{const t=Math.max(gen,occ); const d=sal-t; return {ok:d>=0,msg:'آستانه موثر: £'+t.toLocaleString()+' — '+(d>=0?'حقوق £'+d.toLocaleString()+' بالاتر است (مطابقت اولیه).':'حقوق £'+(-d).toLocaleString()+' کمتر است؛ استثنائات را بررسی کنید.')}})()",
  "note": "آستانه‌ها و استثنائات را از صفحه رسمی بخوانید.",
  "u": "https://www.gov.uk/skilled-worker-visa/your-job"
 },
 "id": "astra-uk-skilled-work-explorer",
 "verified": "2026-10-01"
};
