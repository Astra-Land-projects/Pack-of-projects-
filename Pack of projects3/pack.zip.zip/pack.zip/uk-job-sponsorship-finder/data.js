window.APP = {
 "slug": "uk-job-sponsorship-finder",
 "title": "UK Job Sponsorship Finder",
 "subtitle": "جست‌وجوی مشاغل مرتبط با sponsorship",
 "type": "jobs",
 "desc": "فایل CSV رسمی Register of licensed sponsors را بارگذاری و بر اساس شهر، نام شرکت یا route جست‌وجو کنید؛ لینک آگهی بسازید و درخواست‌ها را پیگیری کنید.",
 "sources": [
  {
   "t": "GOV.UK — Register of licensed sponsors: workers",
   "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
  },
  {
   "t": "GOV.UK — Find a job",
   "u": "https://www.gov.uk/find-a-job"
  }
 ],
 "code": "UK",
 "country": "UK",
 "jobs": {
  "qHint": "software engineer",
  "lHint": "London",
  "boards": [
   {
    "t": "GOV.UK Find a job",
    "u": "https://findajob.dwp.gov.uk/search?q={q}&w={l}"
   },
   {
    "t": "LinkedIn UK",
    "u": "https://www.linkedin.com/jobs/search/?keywords={q}&location={l}",
    "add": "visa sponsorship"
   },
   {
    "t": "Indeed UK",
    "u": "https://uk.indeed.com/jobs?q={q}&l={l}",
    "add": "visa sponsorship"
   },
   {
    "t": "NHS Jobs",
    "u": "https://www.jobs.nhs.uk/candidate/search/results?keyword={q}"
   },
   {
    "t": "Register of licensed sponsors",
    "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers",
    "d": "CSV رسمی"
   }
  ],
  "csv": {
   "title": "جست‌وجو در Register of licensed sponsors",
   "hint": "CSV را از صفحه رسمی دانلود و بارگذاری کنید (ستون‌ها: Organisation Name، Town/City، County، Type & Rating، Route).",
   "src": {
    "t": "GOV.UK — Register of licensed sponsors: workers",
    "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
   }
  },
  "fields": [
   {
    "id": "title",
    "l": "عنوان"
   },
   {
    "id": "org",
    "l": "کارفرما"
   },
   {
    "id": "city",
    "l": "شهر"
   },
   {
    "id": "url",
    "l": "لینک"
   },
   {
    "id": "soc",
    "l": "کد SOC"
   }
  ],
  "tips": [
   "حضور در Register الزاماً به معنی sponsor کردن هر شغل نیست.",
   "کد SOC و حقوق را با جدول‌های رسمی بسنجید."
  ]
 },
 "id": "astra-uk-job-sponsorship-finder",
 "verified": "2026-10-01"
};
