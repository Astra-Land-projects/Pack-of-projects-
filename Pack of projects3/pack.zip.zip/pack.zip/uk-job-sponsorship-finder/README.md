# UK Job Sponsorship Finder

جست‌وجوی مشاغل مرتبط با sponsorship

فایل CSV رسمی Register of licensed sponsors را بارگذاری و بر اساس شهر، نام شرکت یا route جست‌وجو کنید؛ لینک آگهی بسازید و درخواست‌ها را پیگیری کنید.

**نوع ابزار:** جست‌وجو + ردیاب · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- سازنده لینک جست‌وجو در چند پورتال
- جست‌وجوی CSV رسمی داخل مرورگر (در صورت وجود)
- ردیاب وضعیت با KPI
- خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Register of licensed sponsors: workers](https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers)
- [GOV.UK — Find a job](https://www.gov.uk/find-a-job)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
