window.APP = {
 "slug": "spain-digital-nomad-information-hub",
 "title": "Spain Digital Nomad Information Hub",
 "subtitle": "اطلاعات ویزای دیجیتال نومد اسپانیا",
 "type": "explorer",
 "desc": "اطلاعات teletrabajo de carácter internacional و محاسبه درآمد حداقلی بر اساس SMI (۲۰۲۶: ۱٬۲۲۱ یورو × ۱۴).",
 "sources": [
  {
   "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  },
  {
   "t": "Portal de Inmigración — Teletrabajo de carácter internacional",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/ley-de-startups"
  },
  {
   "t": "BOE — Real Decreto SMI 2026",
   "u": "https://www.boe.es/buscar/act.php?id=BOE-A-2026-3815"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "listTitle": "گزینه‌ها و الزامات",
 "items": [
  {
   "name": "Visado (از کنسولگری)",
   "tags": [
    "خارج از اسپانیا"
   ],
   "summary": "درخواست ویزای teletrabajo از کنسولگری اسپانیا در کشور محل اقامت.",
   "facts": {
    "مدت": "تا ۱ سال (ویزا) و سپس اقامت",
    "درآمد": "≥۲۰۰٪ SMI ماهانه",
    "رابطه کاری": "حداقل ۳ ماه پیش از درخواست با شرکت خارجی",
    "سابقه": "مدرک دانشگاهی/حرفه‌ای یا ۳ سال تجربه"
   },
   "docs": [
    "قرارداد/گواهی کارفرما",
    "اثبات فعالیت شرکت (≥۱ سال)",
    "سوءپیشینه",
    "بیمه"
   ],
   "url": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  },
  {
   "name": "Autorización de residencia (در اسپانیا)",
   "tags": [
    "داخل اسپانیا"
   ],
   "summary": "اگر به‌صورت قانونی در اسپانیا هستید، درخواست اقامت مستقیم از UGE-CE.",
   "facts": {
    "مدت": "تا ۳ سال، قابل تمدید",
    "درآمد": "≥۲۰۰٪ SMI ماهانه",
    "رابطه کاری": "حداقل ۳ ماه",
    "سابقه": "مدرک یا ۳ سال تجربه"
   },
   "url": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  },
  {
   "name": "اعضای خانواده",
   "tags": [
    "خانواده"
   ],
   "summary": "همسر و فرزندان همراه با افزایش آستانه درآمد.",
   "facts": {
    "درآمد": "+۷۵٪ SMI برای نفر اول، +۲۵٪ برای هر نفر بعدی"
   },
   "url": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  }
 ],
 "calc": {
  "title": "محاسبه درآمد حداقلی ماهانه",
  "fields": [
   {
    "id": "smi",
    "l": "SMI ماهانه (۲۰۲۶: ۱۲۲۱)",
    "v": 1221
   },
   {
    "id": "pays",
    "l": "تعداد پرداخت در سال (۱۴)",
    "v": 14
   },
   {
    "id": "fam1",
    "l": "همسر/نفر اول همراه (۰ یا ۱)",
    "v": 0
   },
   {
    "id": "famn",
    "l": "تعداد افراد همراه دیگر",
    "v": 0
   },
   {
    "id": "income",
    "l": "درآمد خالص/ناخالص ماهانه شما (EUR)",
    "v": 3000
   }
  ],
  "formula": "(()=>{const m=smi*pays/12; const req=m*2+(fam1?m*0.75:0)+famn*m*0.25; return {ok:income>=req,msg:'آستانه تقریبی ماهانه: '+Math.round(req).toLocaleString()+' یورو — '+(income>=req?'درآمد شما بالاتر است (مطابقت اولیه).':'درآمد شما '+Math.round(req-income).toLocaleString()+' یورو کمتر است.')}})()",
  "note": "روش محاسبه (ماهانه‌سازی ۱۴ پرداخت) را با اعلام UGE-CE تطبیق دهید.",
  "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
 },
 "id": "astra-spain-digital-nomad-information-hub",
 "verified": "2026-10-01"
};
