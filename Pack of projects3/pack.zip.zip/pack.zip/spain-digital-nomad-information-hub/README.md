# Spain Digital Nomad Information Hub

اطلاعات ویزای دیجیتال نومد اسپانیا

اطلاعات teletrabajo de carácter internacional و محاسبه درآمد حداقلی بر اساس SMI (۲۰۲۶: ۱٬۲۲۱ یورو × ۱۴).

**نوع ابزار:** اکسپلورر + محاسبه‌گر · **کشور/منطقه:** Spain · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- کارت‌ها با فیلتر و جست‌وجو
- مقایسه تا ۳ گزینه
- محاسبه‌گر مطابقت اولیه

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups](https://www.inclusion.gob.es/web/unidadgrandesempresas/)
- [Portal de Inmigración — Teletrabajo de carácter internacional](https://www.inclusion.gob.es/web/unidadgrandesempresas/ley-de-startups)
- [BOE — Real Decreto SMI 2026](https://www.boe.es/buscar/act.php?id=BOE-A-2026-3815)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
