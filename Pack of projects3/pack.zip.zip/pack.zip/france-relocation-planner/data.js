window.APP = {
 "slug": "france-relocation-planner",
 "title": "France Relocation Planner",
 "subtitle": "برنامه انتقال به فرانسه",
 "type": "planner",
 "desc": "کارهای پیش و پس از ورود: OFII/ANEF، Sécurité sociale، CAF، بانک، مسکن.",
 "sources": [
  {
   "t": "Welcome to France",
   "u": "https://www.welcometofrance.com/en"
  },
  {
   "t": "ANEF — Administration numérique pour les étrangers en France",
   "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
  },
  {
   "t": "CAF — Housing benefit",
   "u": "https://www.caf.fr/"
  }
 ],
 "code": "FR",
 "country": "France",
 "plan": {
  "targetLabel": "تاریخ ورود",
  "phases": [
   {
    "name": "۳ ماه قبل",
    "off": -90,
    "tasks": [
     {
      "t": "ویزا در France-Visas",
      "u": "https://france-visas.gouv.fr/"
     },
     "ترجمه رسمی acte de naissance (traducteur assermenté)"
    ]
   },
   {
    "name": "۱ ماه قبل",
    "off": -30,
    "tasks": [
     "مسکن موقت و attestation d'hébergement",
     "بیمه ورود"
    ]
   },
   {
    "name": "ماه اول",
    "off": 14,
    "tasks": [
     {
      "t": "اعتبارسنجی ویزای VLS-TS در ANEF",
      "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
     },
     "حساب بانکی (RIB)",
     "ثبت‌نام Sécurité sociale (Ameli)"
    ]
   },
   {
    "name": "ماه دوم",
    "off": 45,
    "tasks": [
     {
      "t": "CAF (کمک مسکن)",
      "u": "https://www.caf.fr/"
     },
     "Médecin traitant",
     "Contrat d'intégration républicaine (در صورت شمول)"
    ]
   }
  ]
 },
 "id": "astra-france-relocation-planner",
 "verified": "2026-10-01"
};
