# Netherlands Study Planner

برنامه تحصیل در هلند

از Studielink تا درخواست اقامت دانشجویی توسط دانشگاه، MVV، BSN و بیمه.

**نوع ابزار:** برنامه‌ریز زمان‌بندی‌شده · **کشور/منطقه:** Netherlands · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- برنامه فازبندی‌شده نسبت به تاریخ هدف
- سناریوهای مختلف
- کارهای دلخواه، پیشرفت و ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Study in NL (Nuffic)](https://www.studyinnl.org/)
- [IND — Study](https://ind.nl/en/residence-permits/study)
- [Studielink](https://www.studielink.nl/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
