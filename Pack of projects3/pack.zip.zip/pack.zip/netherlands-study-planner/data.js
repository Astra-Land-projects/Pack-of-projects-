window.APP = {
 "slug": "netherlands-study-planner",
 "title": "Netherlands Study Planner",
 "subtitle": "برنامه تحصیل در هلند",
 "type": "planner",
 "desc": "از Studielink تا درخواست اقامت دانشجویی توسط دانشگاه، MVV، BSN و بیمه.",
 "sources": [
  {
   "t": "Study in NL (Nuffic)",
   "u": "https://www.studyinnl.org/"
  },
  {
   "t": "IND — Study",
   "u": "https://ind.nl/en/residence-permits/study"
  },
  {
   "t": "Studielink",
   "u": "https://www.studielink.nl/"
  }
 ],
 "code": "NL",
 "country": "Netherlands",
 "plan": {
  "targetLabel": "شروع سال تحصیلی (سپتامبر)",
  "phases": [
   {
    "name": "تحقیق",
    "off": -360,
    "tasks": [
     {
      "t": "جست‌وجو در Study in NL",
      "u": "https://www.studyinnl.org/"
     },
     "IELTS/TOEFL"
    ]
   },
   {
    "name": "اپلای",
    "off": -270,
    "tasks": [
     {
      "t": "ثبت در Studielink",
      "u": "https://www.studielink.nl/"
     },
     "اپلای دانشگاه (ددلاین غیر EEA اغلب ۱ فوریه تا ۱ آوریل)",
     {
      "t": "NL Scholarship",
      "u": "https://www.studyinnl.org/finances/nl-scholarship"
     }
    ]
   },
   {
    "name": "پذیرش",
    "off": -150,
    "tasks": [
     "پرداخت شهریه و ودیعه هزینه زندگی به دانشگاه",
     "دانشگاه درخواست MVV/اقامت را در IND ثبت می‌کند"
    ]
   },
   {
    "name": "مسکن",
    "off": -120,
    "tasks": [
     "جست‌وجوی مسکن (ابزار Housing Dashboard)"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     "دریافت MVV / کارت اقامت",
     "ثبت در شهرداری و BSN",
     "بیمه درمانی (در صورت کار: الزامی)"
    ]
   }
  ]
 },
 "id": "astra-netherlands-study-planner",
 "verified": "2026-10-01"
};
