# Opportunity Card Explorer

محاسبه امتیاز Chancenkarte (کارت فرصت)

بر اساس جدول امتیاز رسمی Make it in Germany، شرایط پایه و امتیازتان را محاسبه کنید.

**نوع ابزار:** محاسبه امتیاز · **کشور/منطقه:** Germany · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- شرایط پایه
- جدول امتیاز رسمی
- مسیر جایگزین

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Make it in Germany — Opportunity Card (Chancenkarte)](https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card)
- [anabin — KMK database for foreign qualifications](https://anabin.kmk.org/)
- [Anerkennung in Deutschland (recognition portal)](https://www.anerkennung-in-deutschland.de/en/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
