window.APP = {
 "slug": "germany-opportunity-card-explorer",
 "title": "Opportunity Card Explorer",
 "subtitle": "محاسبه امتیاز Chancenkarte (کارت فرصت)",
 "type": "points",
 "desc": "بر اساس جدول امتیاز رسمی Make it in Germany، شرایط پایه و امتیازتان را محاسبه کنید.",
 "sources": [
  {
   "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
  },
  {
   "t": "anabin — KMK database for foreign qualifications",
   "u": "https://anabin.kmk.org/"
  },
  {
   "t": "Anerkennung in Deutschland (recognition portal)",
   "u": "https://www.anerkennung-in-deutschland.de/en/"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "points": {
  "prereq": [
   "تبعه کشوری خارج از EU/EEA/سوئیس هستم",
   "مدرک دانشگاهی یا فنی‌وحرفه‌ای حداقل ۲ ساله دارم که در کشور صدور رسمی است",
   "نتیجه مثبت anabin / Statement of Comparability (دانشگاهی) یا Digital Statement (فنی) دارم",
   "حداقل A1 آلمانی یا B2 انگلیسی (CEFR) دارم",
   "اثبات مالی: حساب مسدود ۱٬۰۹۱ یورو خالص در ماه (۲۰۲۶) یا تعهدنامه"
  ],
  "bypass": "مدرک من در آلمان کاملاً به رسمیت شناخته شده یا مدرکم را در آلمان گرفته‌ام (Skilled worker)",
  "bypassMsg": "به‌عنوان نیروی ماهر نیازی به سیستم امتیازی و مدرک زبان ندارید؛ فقط اثبات مالی لازم است (مطابقت اولیه).",
  "criteria": [
   {
    "id": "rec",
    "l": "معادل‌سازی مدرک",
    "options": [
     {
      "l": "ندارد",
      "p": 0
     },
     {
      "l": "معادل جزئی (partial)",
      "p": 4
     }
    ]
   },
   {
    "id": "short",
    "l": "مدرک در شغل کمبود",
    "options": [
     {
      "l": "خیر",
      "p": 0
     },
     {
      "l": "بله",
      "p": 1
     }
    ]
   },
   {
    "id": "exp",
    "l": "سابقه کار مرتبط",
    "options": [
     {
      "l": "کمتر از ۲ سال در ۵ سال اخیر",
      "p": 0
     },
     {
      "l": "حداقل ۲ سال در ۵ سال اخیر",
      "p": 2
     },
     {
      "l": "حداقل ۵ سال در ۷ سال اخیر",
      "p": 3
     }
    ]
   },
   {
    "id": "de",
    "l": "زبان آلمانی",
    "options": [
     {
      "l": "زیر A2",
      "p": 0
     },
     {
      "l": "A2",
      "p": 1
     },
     {
      "l": "B1",
      "p": 2
     },
     {
      "l": "B2 یا بالاتر",
      "p": 3
     }
    ]
   },
   {
    "id": "en",
    "l": "انگلیسی C1+ یا زبان مادری",
    "options": [
     {
      "l": "خیر",
      "p": 0
     },
     {
      "l": "بله",
      "p": 1
     }
    ]
   },
   {
    "id": "age",
    "l": "سن",
    "options": [
     {
      "l": "بیش از ۴۰",
      "p": 0
     },
     {
      "l": "۳۵ تا ۴۰",
      "p": 1
     },
     {
      "l": "تا ۳۵",
      "p": 2
     }
    ]
   },
   {
    "id": "stay",
    "l": "اقامت قانونی ≥۶ ماه در آلمان در ۵ سال اخیر (غیرتوریستی)",
    "options": [
     {
      "l": "خیر",
      "p": 0
     },
     {
      "l": "بله",
      "p": 1
     }
    ]
   },
   {
    "id": "sp",
    "l": "همسر/شریک واجد شرایط Opportunity Card",
    "options": [
     {
      "l": "خیر",
      "p": 0
     },
     {
      "l": "بله",
      "p": 1
     }
    ]
   }
  ],
  "threshold": 6,
  "note": "جدول بر اساس صفحه رسمی Make it in Germany (۲۰۲۶).",
  "source": {
   "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
  }
 },
 "id": "astra-germany-opportunity-card-explorer",
 "verified": "2026-10-01"
};
