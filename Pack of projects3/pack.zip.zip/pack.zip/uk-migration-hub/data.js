window.APP = {
 "slug": "uk-migration-hub",
 "title": "UK Migration Hub",
 "subtitle": "مرکز ابزارهای بریتانیا",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "GOV.UK — Visas and immigration",
   "u": "https://www.gov.uk/browse/visas-immigration"
  },
  {
   "t": "GOV.UK — Check if you need a UK visa",
   "u": "https://www.gov.uk/check-uk-visa"
  },
  {
   "t": "GOV.UK — Visa processing times",
   "u": "https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk"
  }
 ],
 "code": "UK",
 "country": "UK",
 "intro": "ابزارهای بریتانیا به GOV.UK (ویزا، زمان پردازش، eVisa، اثبات وضعیت) متصل‌اند.",
 "links": [
  {
   "slug": "uk-visa-navigator",
   "title": "UK Visa Navigator",
   "desc": "پیدا کردن مسیر ویزای بریتانیا"
  },
  {
   "slug": "uk-student-route-planner",
   "title": "UK Student Route Planner",
   "desc": "برنامه تحصیل در بریتانیا"
  },
  {
   "slug": "uk-skilled-work-explorer",
   "title": "UK Skilled Work Explorer",
   "desc": "بررسی اطلاعات مسیر Skilled Worker"
  },
  {
   "slug": "uk-visa-document-checklist",
   "title": "UK Visa Document Checklist",
   "desc": "چک‌لیست مدارک ویزای بریتانیا"
  },
  {
   "slug": "uk-evisa-dashboard",
   "title": "UK eVisa Dashboard",
   "desc": "مدیریت وضعیت eVisa و share code"
  },
  {
   "slug": "uk-visa-timeline-tracker",
   "title": "UK Visa Timeline Tracker",
   "desc": "تایم‌لاین پرونده ویزای UK"
  },
  {
   "slug": "uk-cost-of-relocation",
   "title": "UK Cost of Relocation",
   "desc": "برآورد هزینه انتقال به بریتانیا"
  },
  {
   "slug": "uk-job-sponsorship-finder",
   "title": "UK Job Sponsorship Finder",
   "desc": "جست‌وجوی مشاغل مرتبط با sponsorship"
  },
  {
   "slug": "uk-cv-analyzer-ai",
   "title": "UK CV Analyzer AI",
   "desc": "تحلیل رزومه برای بازار بریتانیا"
  },
  {
   "slug": "uk-university-migration-planner",
   "title": "UK University Migration Planner",
   "desc": "تحصیل + برنامه‌ریزی شغلی در UK"
  },
  {
   "slug": "uk-immigration-source-monitor",
   "title": "UK Immigration Source Monitor",
   "desc": "پایش تغییرات منابع رسمی بریتانیا"
  },
  {
   "slug": "uk-settlement-journey-planner",
   "title": "UK Settlement Journey Planner",
   "desc": "مراحل و ددلاین‌های مسیر اقامت دائم (ILR) و شهروندی"
  }
 ],
 "facts": [
  "آستانه عمومی حقوق Skilled Worker برای CoS از ۲۲ ژوئیه ۲۰۲۵: ۴۱٬۷۰۰ پوند (با استثنائات)",
  "BRPها با eVisa جایگزین شده‌اند؛ وضعیت را با share code اثبات کنید",
  "اتباع غیرنیازمند ویزا برای سفر کوتاه به ETA نیاز دارند"
 ],
 "id": "astra-uk-migration-hub",
 "verified": "2026-10-01"
};
