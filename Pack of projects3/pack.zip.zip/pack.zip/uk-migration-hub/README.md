# UK Migration Hub

مرکز ابزارهای بریتانیا



**نوع ابزار:** هاب کشوری · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- لینک به ابزارهای مستقل کشور

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Visas and immigration](https://www.gov.uk/browse/visas-immigration)
- [GOV.UK — Check if you need a UK visa](https://www.gov.uk/check-uk-visa)
- [GOV.UK — Visa processing times](https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
