window.APP = {
 "slug": "france-work-route-explorer",
 "title": "France Work Route Explorer",
 "subtitle": "بررسی مسیرهای کاری فرانسه",
 "type": "navigator",
 "desc": "وضعیت خود را انتخاب کنید تا مسیرهای Passeport talent، کارمند، فارغ‌التحصیل جست‌وجوی کار و ICT رتبه‌بندی شود.",
 "sources": [
  {
   "t": "Welcome to France — Talent passport",
   "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
  },
  {
   "t": "Welcome to France",
   "u": "https://www.welcometofrance.com/en"
  },
  {
   "t": "France-Visas (official visa website)",
   "u": "https://france-visas.gouv.fr/"
  }
 ],
 "code": "FR",
 "country": "France",
 "questions": [
  {
   "id": "offer",
   "q": "پیشنهاد کار",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "edu",
   "q": "تحصیلات",
   "options": [
    {
     "v": "ma",
     "l": "ارشد یا بالاتر"
    },
    {
     "v": "ba",
     "l": "کارشناسی"
    },
    {
     "v": "other",
     "l": "سایر"
    }
   ]
  },
  {
   "id": "sit",
   "q": "وضعیت",
   "options": [
    {
     "v": "abroad",
     "l": "خارج از فرانسه"
    },
    {
     "v": "grad",
     "l": "فارغ‌التحصیل دانشگاه فرانسه"
    },
    {
     "v": "ict",
     "l": "انتقال درون‌شرکتی"
    },
    {
     "v": "founder",
     "l": "بنیان‌گذار/سرمایه‌گذار"
    },
    {
     "v": "research",
     "l": "پژوهشگر"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Passeport talent — Carte bleue européenne",
   "desc": "شغل بسیار ماهر با حقوق بالاتر از آستانه و مدرک حداقل ۳ ساله آموزش عالی یا سابقه معادل.",
   "when": {
    "offer": [
     "yes"
    ],
    "edu": [
     "ma",
     "ba"
    ],
    "sit": [
     "abroad",
     "grad"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France — Talent passport",
     "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
    }
   ]
  },
  {
   "name": "Passeport talent — Salarié qualifié / entreprise innovante",
   "desc": "فارغ‌التحصیل ارشد با حقوق حداقلی یا استخدام در شرکت نوآور شناخته‌شده.",
   "when": {
    "offer": [
     "yes"
    ],
    "edu": [
     "ma"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France — Talent passport",
     "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
    }
   ]
  },
  {
   "name": "Passeport talent — Chercheur",
   "desc": "پژوهشگر با قرارداد میزبانی (convention d'accueil).",
   "when": {
    "sit": [
     "research"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France — Talent passport",
     "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
    }
   ]
  },
  {
   "name": "Passeport talent — Création d'entreprise / Investisseur",
   "desc": "بنیان‌گذار پروژه نوآورانه یا سرمایه‌گذار.",
   "when": {
    "sit": [
     "founder"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France — Talent passport",
     "u": "https://www.welcometofrance.com/en/fiche/talent-passport"
    }
   ]
  },
  {
   "name": "Salarié / Travailleur temporaire",
   "desc": "کارفرما درخواست مجوز کار را از پلتفرم ANEF ثبت می‌کند (در صورت الزام بررسی بازار کار).",
   "when": {
    "offer": [
     "yes"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France",
     "u": "https://www.welcometofrance.com/en"
    },
    {
     "t": "ANEF — Administration numérique pour les étrangers en France",
     "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
    }
   ]
  },
  {
   "name": "Carte de séjour « recherche d'emploi ou création d'entreprise »",
   "desc": "برای فارغ‌التحصیلان ارشد فرانسه جهت جست‌وجوی کار.",
   "when": {
    "sit": [
     "grad"
    ],
    "offer": [
     "no"
    ]
   },
   "sources": [
    {
     "t": "Service-Public.fr — Foreigners in France",
     "u": "https://www.service-public.fr/particuliers/vosdroits/N110"
    }
   ]
  },
  {
   "name": "Salarié détaché ICT",
   "desc": "انتقال درون‌شرکتی مدیر/متخصص.",
   "when": {
    "sit": [
     "ict"
    ]
   },
   "sources": [
    {
     "t": "Welcome to France",
     "u": "https://www.welcometofrance.com/en"
    }
   ]
  }
 ],
 "id": "astra-france-work-route-explorer",
 "verified": "2026-10-01"
};
