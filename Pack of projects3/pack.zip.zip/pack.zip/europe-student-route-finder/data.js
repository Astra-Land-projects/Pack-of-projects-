window.APP = {
 "slug": "europe-student-route-finder",
 "title": "Europe Student Route Finder",
 "subtitle": "جست‌وجوی مسیرهای تحصیلی اروپا",
 "type": "navigator",
 "desc": "مقطع، بودجه شهریه و زبان را انتخاب کنید تا کشورهای مناسب با منابع رسمی پیشنهاد شوند.",
 "sources": [
  {
   "t": "Study in Europe (European Commission)",
   "u": "https://education.ec.europa.eu/study-in-europe"
  },
  {
   "t": "Erasmus Mundus Joint Masters catalogue",
   "u": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "questions": [
  {
   "id": "budget",
   "q": "بودجه شهریه",
   "options": [
    {
     "v": "low",
     "l": "کم/نزدیک به صفر"
    },
    {
     "v": "mid",
     "l": "متوسط"
    },
    {
     "v": "high",
     "l": "بالا"
    }
   ]
  },
  {
   "id": "lang",
   "q": "زبان تحصیل",
   "options": [
    {
     "v": "en",
     "l": "انگلیسی"
    },
    {
     "v": "de",
     "l": "آلمانی"
    },
    {
     "v": "fr",
     "l": "فرانسوی"
    },
    {
     "v": "it",
     "l": "ایتالیایی"
    },
    {
     "v": "es",
     "l": "اسپانیایی"
    }
   ]
  },
  {
   "id": "level",
   "q": "مقطع",
   "options": [
    {
     "v": "ba",
     "l": "کارشناسی"
    },
    {
     "v": "ma",
     "l": "ارشد"
    },
    {
     "v": "phd",
     "l": "دکتری"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Germany",
   "desc": "اکثر دانشگاه‌های دولتی شهریه ندارند (به‌جز هزینه ترم؛ برخی ایالات مثل بادن-وورتمبرگ برای غیر EU شهریه دارند). حساب مسدود لازم است.",
   "when": {
    "budget": [
     "low",
     "mid"
    ],
    "lang": [
     "de",
     "en"
    ]
   },
   "steps": [
    "جست‌وجو در DAAD International Programmes",
    "uni-assist/اپلای مستقیم",
    "حساب مسدود و ویزا"
   ],
   "sources": [
    {
     "t": "DAAD — Study in Germany",
     "u": "https://www.daad.de/en/"
    },
    {
     "t": "uni-assist",
     "u": "https://www.uni-assist.de/en/"
    }
   ]
  },
  {
   "name": "Italy",
   "desc": "شهریه دولتی بر اساس درآمد (ISEE) و بورسیه‌های منطقه‌ای DSU؛ پیش‌ثبت‌نام Universitaly.",
   "when": {
    "budget": [
     "low",
     "mid"
    ],
    "lang": [
     "en",
     "it"
    ]
   },
   "steps": [
    "انتخاب برنامه",
    "پیش‌ثبت‌نام Universitaly",
    "ویزا و permesso"
   ],
   "sources": [
    {
     "t": "Universitaly",
     "u": "https://www.universitaly.it/"
    },
    {
     "t": "Study in Italy (MAECI)",
     "u": "https://studyinitaly.esteri.it/"
    }
   ]
  },
  {
   "name": "France",
   "desc": "شهریه متمایز برای غیر EU در دانشگاه‌های دولتی (با معافیت‌های دانشگاهی)؛ رویه Études en France.",
   "when": {
    "budget": [
     "mid"
    ],
    "lang": [
     "fr",
     "en"
    ]
   },
   "sources": [
    {
     "t": "Campus France",
     "u": "https://www.campusfrance.org/en"
    }
   ]
  },
  {
   "name": "Austria",
   "desc": "شهریه دولتی متوسط برای غیر EU در هر ترم.",
   "when": {
    "budget": [
     "mid"
    ],
    "lang": [
     "de",
     "en"
    ]
   },
   "sources": [
    {
     "t": "OeAD — Study in Austria / scholarships",
     "u": "https://oead.at/en/"
    }
   ]
  },
  {
   "name": "Spain",
   "desc": "شهریه دولتی نسبتاً پایین و متغیر بر اساس منطقه.",
   "when": {
    "budget": [
     "low",
     "mid"
    ],
    "lang": [
     "es",
     "en"
    ]
   },
   "sources": [
    {
     "t": "Study in Spain (SEPIE)",
     "u": "https://www.studyinspain.info/"
    }
   ]
  },
  {
   "name": "Netherlands",
   "desc": "شهریه institutional برای غیر EEA بالا؛ برنامه‌های انگلیسی گسترده.",
   "when": {
    "budget": [
     "high"
    ],
    "lang": [
     "en"
    ]
   },
   "sources": [
    {
     "t": "Study in NL (Nuffic)",
     "u": "https://www.studyinnl.org/"
    }
   ]
  },
  {
   "name": "Sweden / Finland",
   "desc": "شهریه برای غیر EU/EEA با بورسیه‌های دانشگاهی و SI.",
   "when": {
    "budget": [
     "high",
     "mid"
    ],
    "lang": [
     "en"
    ]
   },
   "sources": [
    {
     "t": "Study in Sweden",
     "u": "https://studyinsweden.se/"
    },
    {
     "t": "Study in Finland",
     "u": "https://www.studyinfinland.fi/"
    }
   ]
  },
  {
   "name": "Erasmus Mundus",
   "desc": "ارشد مشترک چندکشوری با بورسیه کامل.",
   "when": {
    "level": [
     "ma"
    ],
    "lang": [
     "en"
    ]
   },
   "sources": [
    {
     "t": "Erasmus Mundus Joint Masters catalogue",
     "u": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en"
    }
   ]
  },
  {
   "name": "PhD — موقعیت‌های حقوق‌بگیر",
   "desc": "در بسیاری از کشورها (هلند، سوئد، فنلاند، آلمان) دکتری قرارداد کاری با حقوق است؛ EURAXESS را ببینید.",
   "when": {
    "level": [
     "phd"
    ]
   },
   "sources": [
    {
     "t": "EURAXESS",
     "u": "https://euraxess.ec.europa.eu/"
    }
   ]
  }
 ],
 "id": "astra-europe-student-route-finder",
 "verified": "2026-10-01"
};
