# Europe Student Route Finder

جست‌وجوی مسیرهای تحصیلی اروپا

مقطع، بودجه شهریه و زبان را انتخاب کنید تا کشورهای مناسب با منابع رسمی پیشنهاد شوند.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Study in Europe (European Commission)](https://education.ec.europa.eu/study-in-europe)
- [Erasmus Mundus Joint Masters catalogue](https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
