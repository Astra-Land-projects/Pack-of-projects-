window.APP = {
 "slug": "turkiye-residence-renewal-reminder",
 "title": "Residence Renewal Reminder",
 "subtitle": "یادآوری زمان تمدید اقامت",
 "type": "deadlines",
 "desc": "تاریخ انقضای کارت اقامت را وارد کنید تا یادآوری‌های آماده‌سازی، باز شدن بازه تمدید و آخرین مهلت ساخته و به تقویم/اعلان مرورگر اضافه شود.",
 "sources": [
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  },
  {
   "t": "Göç İdaresi Başkanlığı (Presidency of Migration Management)",
   "u": "https://www.goc.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "deadlines": {
  "presetTitle": "ساخت یادآوری از تاریخ انقضای کارت",
  "baseLabel": "تاریخ انقضای اقامت",
  "baseHint": "مثلاً: اقامت کوتاه‌مدت من",
  "presets": [
   {
    "t": "شروع جمع‌آوری مدارک تمدید (بیمه، اجاره‌نامه، صورتحساب)",
    "off": -90
   },
   {
    "t": "تمدید بیمه درمانی برای کل مدت جدید",
    "off": -75
   },
   {
    "t": "بازه تمدید: ثبت درخواست Extension در e-İkamet",
    "off": -60
   },
   {
    "t": "هشدار: هنوز ثبت نشده؟ فوری اقدام کنید",
    "off": -30
   },
   {
    "t": "آخرین هفته پیش از انقضا",
    "off": -7
   },
   {
    "t": "تاریخ انقضای کارت",
    "off": 0
   }
  ],
  "note": "بازه دقیق تمدید را از اداره مهاجرت تأیید کنید؛ درخواست باید پیش از پایان اعتبار ثبت شود.",
  "cats": [
   "اقامت",
   "بیمه",
   "مسکن",
   "گذرنامه",
   "سایر"
  ]
 },
 "id": "astra-turkiye-residence-renewal-reminder",
 "verified": "2026-10-01"
};
