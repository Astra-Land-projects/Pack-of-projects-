window.APP = {
 "slug": "turkiye-student-migration-planner",
 "title": "Türkiye Student Migration Planner",
 "subtitle": "تحصیل و برنامه‌ریزی زندگی دانشجویی در ترکیه",
 "type": "planner",
 "desc": "برنامه زمان‌بندی‌شده از انتخاب دانشگاه و بورسیه Türkiye Bursları تا ویزای تحصیلی و اقامت دانشجویی.",
 "sources": [
  {
   "t": "Study in Türkiye",
   "u": "https://www.studyinturkiye.gov.tr/"
  },
  {
   "t": "Türkiye Bursları (Türkiye Scholarships)",
   "u": "https://www.turkiyeburslari.gov.tr/"
  },
  {
   "t": "YÖK — Council of Higher Education",
   "u": "https://www.yok.gov.tr/en"
  },
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "plan": {
  "targetLabel": "تاریخ شروع ترم",
  "phases": [
   {
    "name": "تحقیق",
    "off": -300,
    "tasks": [
     {
      "t": "جست‌وجوی برنامه‌ها در Study in Türkiye",
      "u": "https://www.studyinturkiye.gov.tr/"
     },
     {
      "t": "بررسی شناسایی دانشگاه توسط YÖK",
      "u": "https://www.yok.gov.tr/en"
     }
    ]
   },
   {
    "name": "بورسیه",
    "off": -240,
    "tasks": [
     {
      "t": "درخواست Türkiye Bursları (بازه معمول: اوایل سال میلادی)",
      "u": "https://www.turkiyeburslari.gov.tr/"
     },
     "آماده‌سازی انگیزه‌نامه و توصیه‌نامه"
    ]
   },
   {
    "name": "اپلای مستقیم دانشگاه",
    "off": -180,
    "tasks": [
     "آزمون‌های ورودی دانشگاه (مثلاً YÖS) در صورت الزام",
     "ارسال مدارک و دریافت پذیرش"
    ]
   },
   {
    "name": "ویزا",
    "off": -60,
    "tasks": [
     {
      "t": "نوبت ویزای تحصیلی در konsolosluk.gov.tr",
      "u": "https://www.konsolosluk.gov.tr/"
     },
     "ترجمه رسمی و تأیید مدارک تحصیلی"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     "ثبت‌نام نهایی و دریافت Öğrenci Belgesi",
     {
      "t": "ثبت اقامت دانشجویی در e-İkamet در مهلت مقرر",
      "u": "https://e-ikamet.goc.gov.tr/"
     },
     "خوابگاه (KYK یا خصوصی)"
    ]
   },
   {
    "name": "ترم اول",
    "off": 60,
    "tasks": [
     "دوره زبان ترکی (TÖMER)",
     "بیمه سلامت عمومی (GSS) یا خصوصی",
     "بررسی قواعد کار دانشجویی و مجوز کار"
    ]
   }
  ]
 },
 "id": "astra-turkiye-student-migration-planner",
 "verified": "2026-10-01"
};
