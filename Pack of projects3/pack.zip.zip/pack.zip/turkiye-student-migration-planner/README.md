# Türkiye Student Migration Planner

تحصیل و برنامه‌ریزی زندگی دانشجویی در ترکیه

برنامه زمان‌بندی‌شده از انتخاب دانشگاه و بورسیه Türkiye Bursları تا ویزای تحصیلی و اقامت دانشجویی.

**نوع ابزار:** برنامه‌ریز زمان‌بندی‌شده · **کشور/منطقه:** Türkiye · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- برنامه فازبندی‌شده نسبت به تاریخ هدف
- سناریوهای مختلف
- کارهای دلخواه، پیشرفت و ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Study in Türkiye](https://www.studyinturkiye.gov.tr/)
- [Türkiye Bursları (Türkiye Scholarships)](https://www.turkiyeburslari.gov.tr/)
- [YÖK — Council of Higher Education](https://www.yok.gov.tr/en)
- [e-İkamet — Residence Permit Online Application](https://e-ikamet.goc.gov.tr/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
