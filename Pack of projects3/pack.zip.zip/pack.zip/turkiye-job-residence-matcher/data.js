window.APP = {
 "slug": "turkiye-job-residence-matcher",
 "title": "Türkiye Job & Residence Matcher",
 "subtitle": "اتصال مسیر شغلی به نوع اقامت/مجوز",
 "type": "navigator",
 "desc": "وضعیت شغلی خود را انتخاب کنید تا نوع مجوز کار/اقامت مرتبط و مراحل آن نمایش داده شود.",
 "sources": [
  {
   "t": "Ministry of Labour — Work Permit for Foreigners (e-Izin)",
   "u": "https://www.csgb.gov.tr/uigm/"
  },
  {
   "t": "İŞKUR — Turkish Employment Agency",
   "u": "https://www.iskur.gov.tr/"
  },
  {
   "t": "Invest in Türkiye — Work Permit / Turquoise Card",
   "u": "https://www.invest.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "questions": [
  {
   "id": "job",
   "q": "وضعیت شغلی",
   "options": [
    {
     "v": "local",
     "l": "پیشنهاد کار از شرکت ترکیه‌ای"
    },
    {
     "v": "remote",
     "l": "کار از راه دور برای کارفرمای خارجی"
    },
    {
     "v": "own",
     "l": "راه‌اندازی شرکت/کسب‌وکار"
    },
    {
     "v": "student",
     "l": "دانشجو در ترکیه"
    },
    {
     "v": "none",
     "l": "در جست‌وجوی کار"
    }
   ]
  },
  {
   "id": "skill",
   "q": "سطح تخصص",
   "options": [
    {
     "v": "high",
     "l": "بسیار متخصص/پژوهشگر/سرمایه‌گذار"
    },
    {
     "v": "mid",
     "l": "متخصص"
    },
    {
     "v": "low",
     "l": "عمومی"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "مجوز کار وابسته به کارفرما",
   "desc": "کارفرما درخواست را در سامانه e-İzin وزارت کار ثبت می‌کند؛ مجوز کار معتبر جایگزین اقامت است.",
   "when": {
    "job": [
     "local"
    ]
   },
   "steps": [
    "قرارداد کار",
    "ثبت درخواست توسط کارفرما (داخل یا خارج از ترکیه با ویزای کاری)",
    "پیگیری تا صدور"
   ],
   "sources": [
    {
     "t": "Ministry of Labour — Work Permit for Foreigners (e-Izin)",
     "u": "https://www.csgb.gov.tr/uigm/"
    }
   ]
  },
  {
   "name": "Turquoise Card",
   "desc": "برای نیروی بسیار ماهر، سرمایه‌گذار و پژوهشگر با معیارهای امتیازی.",
   "when": {
    "skill": [
     "high"
    ],
    "job": [
     "local",
     "own"
    ]
   },
   "steps": [
    "بررسی معیارها",
    "درخواست از وزارت کار"
   ],
   "sources": [
    {
     "t": "Invest in Türkiye — Work Permit / Turquoise Card",
     "u": "https://www.invest.gov.tr/"
    }
   ]
  },
  {
   "name": "اقامت کوتاه‌مدت (بدون مجوز کار محلی)",
   "desc": "کار از راه دور برای کارفرمای خارجی؛ وضعیت مالیاتی و قانونی را بررسی کنید—اقامت کوتاه‌مدت مجوز کار در بازار ترکیه نمی‌دهد.",
   "when": {
    "job": [
     "remote"
    ]
   },
   "steps": [
    "اقامت کوتاه‌مدت در e-İkamet",
    "اثبات درآمد کافی",
    "مشاوره مالیاتی"
   ],
   "sources": [
    {
     "t": "e-İkamet — Residence Permit Online Application",
     "u": "https://e-ikamet.goc.gov.tr/"
    }
   ]
  },
  {
   "name": "مجوز کار مستقل / شرکت",
   "desc": "ثبت شرکت و درخواست مجوز کار برای مدیر/شریک خارجی طبق ضوابط وزارت کار.",
   "when": {
    "job": [
     "own"
    ]
   },
   "steps": [
    "ثبت شرکت",
    "تأمین شرایط سرمایه و اشتغال",
    "درخواست مجوز"
   ],
   "sources": [
    {
     "t": "Ministry of Labour — Work Permit for Foreigners (e-Izin)",
     "u": "https://www.csgb.gov.tr/uigm/"
    },
    {
     "t": "Invest in Türkiye — Work Permit / Turquoise Card",
     "u": "https://www.invest.gov.tr/"
    }
   ]
  },
  {
   "name": "کار دانشجویی",
   "desc": "دانشجویان برای کار پاره‌وقت نیز مجوز کار لازم دارند و قواعد خاص مقطع تحصیلی اعمال می‌شود.",
   "when": {
    "job": [
     "student"
    ]
   },
   "steps": [
    "بررسی قواعد مقطع",
    "درخواست مجوز کار توسط کارفرما"
   ],
   "sources": [
    {
     "t": "Ministry of Labour — Work Permit for Foreigners (e-Izin)",
     "u": "https://www.csgb.gov.tr/uigm/"
    }
   ]
  },
  {
   "name": "جست‌وجوی کار",
   "desc": "آگهی‌ها در İŞKUR و بازار خصوصی؛ جست‌وجوی کار به‌تنهایی نوع اقامت مستقلی نیست.",
   "when": {
    "job": [
     "none"
    ]
   },
   "steps": [
    "پروفایل İŞKUR",
    "بررسی آگهی‌ها",
    "دریافت پیشنهاد و سپس مجوز کار"
   ],
   "sources": [
    {
     "t": "İŞKUR — Turkish Employment Agency",
     "u": "https://www.iskur.gov.tr/"
    }
   ]
  }
 ],
 "id": "astra-turkiye-job-residence-matcher",
 "verified": "2026-10-01"
};
