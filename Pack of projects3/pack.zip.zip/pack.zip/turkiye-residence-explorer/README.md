# Türkiye Residence Explorer

معرفی و مقایسه انواع اقامت ترکیه

انواع اجازه اقامت طبق قانون خارجیان و حمایت بین‌المللی (شماره ۶۴۵۸) را مرور و تا سه نوع را کنار هم مقایسه کنید.

**نوع ابزار:** اکسپلورر + محاسبه‌گر · **کشور/منطقه:** Türkiye · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- کارت‌ها با فیلتر و جست‌وجو
- مقایسه تا ۳ گزینه
- محاسبه‌گر مطابقت اولیه

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Residence Permit Types — goc.gov.tr](https://en.goc.gov.tr/residence-permits)
- [e-İkamet — Residence Permit Online Application](https://e-ikamet.goc.gov.tr/)
- [Law No. 6458 on Foreigners and International Protection (goc.gov.tr)](https://en.goc.gov.tr/law-on-foreigners-and-international-protection-yukk)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
