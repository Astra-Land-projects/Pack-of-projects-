window.APP = {
 "slug": "netherlands-residence-planner",
 "title": "Netherlands Residence Planner",
 "subtitle": "تایم‌لاین اقامت هلند",
 "type": "timeline",
 "desc": "مسیرهای HSM، تحصیل → orientation year → HSM، و DAFT (کارآفرین آمریکایی) را تا اقامت دائم/تابعیت زمان‌بندی کنید.",
 "sources": [
  {
   "t": "IND — Highly skilled migrant",
   "u": "https://ind.nl/en/residence-permits/work/highly-skilled-migrant"
  },
  {
   "t": "IND — Orientation year (zoekjaar)",
   "u": "https://ind.nl/en/residence-permits/work/residence-permit-for-orientation-year"
  },
  {
   "t": "IND — Permanent residence",
   "u": "https://ind.nl/en/temporary-and-non-temporary-purposes-of-residence"
  }
 ],
 "code": "NL",
 "country": "Netherlands",
 "routes": {
  "hsm": {
   "label": "Highly Skilled Migrant → اقامت دائم",
   "steps": [
    {
     "t": "درخواست کارفرما در IND",
     "days": 1,
     "u": "https://ind.nl/en/residence-permits/work/highly-skilled-migrant"
    },
    {
     "t": "تصمیم IND (رسیدگی سریع sponsor)",
     "days": 21
    },
    {
     "t": "MVV در سفارت",
     "days": 14
    },
    {
     "t": "ورود، BSN و کارت",
     "days": 21
    },
    {
     "t": "۵ سال اقامت",
     "days": 1825
    },
    {
     "t": "اقامت دائم/EU long-term (+ آزمون ادغام)",
     "days": 120
    }
   ]
  },
  "st": {
   "label": "تحصیل → Orientation year → HSM",
   "steps": [
    {
     "t": "اقامت دانشجویی",
     "days": 60
    },
    {
     "t": "تحصیل ارشد",
     "days": 365
    },
    {
     "t": "Orientation year",
     "days": 365,
     "u": "https://ind.nl/en/residence-permits/work/residence-permit-for-orientation-year"
    },
    {
     "t": "HSM با آستانه کاهش‌یافته",
     "days": 30
    }
   ]
  },
  "daft": {
   "label": "DAFT (شهروندان آمریکا)",
   "steps": [
    {
     "t": "ثبت در KVK",
     "days": 14
    },
    {
     "t": "درخواست IND",
     "days": 90
    },
    {
     "t": "۲ سال اقامت (تمدید ۵ ساله)",
     "days": 730
    }
   ]
  }
 },
 "id": "astra-netherlands-residence-planner",
 "verified": "2026-10-01"
};
