window.APP = {
 "slug": "italy-work-opportunity-finder",
 "title": "Italy Work Opportunity Finder",
 "subtitle": "جست‌وجوی فرصت‌های کاری ایتالیا",
 "type": "jobs",
 "desc": "لینک جست‌وجو در پورتال‌های رسمی و خصوصی ایتالیا و پیگیری درخواست‌ها (با فیلد مسیر مجوز: Carta Blu، Decreto Flussi…).",
 "sources": [
  {
   "t": "Integrazione Migranti (Ministry of Labour)",
   "u": "https://integrazionemigranti.gov.it/"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "jobs": {
  "qHint": "ingegnere software",
  "lHint": "Milano",
  "boards": [
   {
    "t": "EURES (Italy)",
    "u": "https://europa.eu/eures/portal/jv-se/home"
   },
   {
    "t": "Cliclavoro / SIISL",
    "u": "https://www.cliclavoro.gov.it/"
   },
   {
    "t": "LinkedIn Italy",
    "u": "https://www.linkedin.com/jobs/search/?keywords={q}&location={l}"
   },
   {
    "t": "Indeed Italia",
    "u": "https://it.indeed.com/jobs?q={q}&l={l}"
   },
   {
    "t": "InfoJobs Italia",
    "u": "https://www.infojobs.it/offerte-lavoro?keyword={q}"
   }
  ],
  "fields": [
   {
    "id": "title",
    "l": "عنوان"
   },
   {
    "id": "org",
    "l": "شرکت"
   },
   {
    "id": "city",
    "l": "شهر"
   },
   {
    "id": "url",
    "l": "لینک"
   },
   {
    "id": "route",
    "l": "مسیر مجوز (Carta Blu/Flussi)"
   }
  ],
  "tips": [
   "Decreto Flussi سهمیه سالانه کار غیرفصلی و فصلی را با بازه‌های click day تعیین می‌کند.",
   "Carta Blu UE برای مشاغل بسیار ماهر خارج از سهمیه است."
  ]
 },
 "id": "astra-italy-work-opportunity-finder",
 "verified": "2026-10-01"
};
