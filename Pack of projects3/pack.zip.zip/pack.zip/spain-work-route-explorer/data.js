window.APP = {
 "slug": "spain-work-route-explorer",
 "title": "Spain Work Route Explorer",
 "subtitle": "بررسی مسیرهای کاری اسپانیا",
 "type": "navigator",
 "desc": "مسیرهای HQP، Blue Card، cuenta ajena، دیجیتال نومد، کارآفرین و arraigo را بر اساس شرایط شما رتبه‌بندی کنید.",
 "sources": [
  {
   "t": "Portal de Inmigración — Ministerio de Inclusión",
   "u": "https://www.inclusion.gob.es/web/migraciones/"
  },
  {
   "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "questions": [
  {
   "id": "offer",
   "q": "پیشنهاد کار از شرکت اسپانیایی",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "remote",
   "q": "کار از راه دور برای شرکت خارجی",
   "options": [
    {
     "v": "yes",
     "l": "بله"
    },
    {
     "v": "no",
     "l": "خیر"
    }
   ]
  },
  {
   "id": "edu",
   "q": "تحصیلات",
   "options": [
    {
     "v": "uni",
     "l": "دانشگاهی"
    },
    {
     "v": "other",
     "l": "غیردانشگاهی"
    }
   ]
  },
  {
   "id": "inspain",
   "q": "هم‌اکنون در اسپانیا هستم",
   "options": [
    {
     "v": "yes",
     "l": "بله"
    },
    {
     "v": "no",
     "l": "خیر"
    }
   ]
  },
  {
   "id": "startup",
   "q": "پروژه کارآفرینی نوآورانه",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Profesional altamente cualificado (Ley 14/2013)",
   "desc": "کارفرمای مشمول، درخواست در UGE-CE؛ رسیدگی سریع.",
   "when": {
    "offer": [
     "yes"
    ],
    "edu": [
     "uni"
    ]
   },
   "sources": [
    {
     "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
     "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
    }
   ]
  },
  {
   "name": "Tarjeta Azul-UE",
   "desc": "شغل بسیار ماهر با حقوق حداقلی طبق قانون.",
   "when": {
    "offer": [
     "yes"
    ],
    "edu": [
     "uni"
    ]
   },
   "sources": [
    {
     "t": "Portal de Inmigración — Ministerio de Inclusión",
     "u": "https://www.inclusion.gob.es/web/migraciones/"
    }
   ]
  },
  {
   "name": "Teletrabajo de carácter internacional",
   "desc": "کار از راه دور برای شرکت خارج از اسپانیا؛ درآمد ≥۲۰۰٪ SMI.",
   "when": {
    "remote": [
     "yes"
    ]
   },
   "sources": [
    {
     "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
     "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
    }
   ]
  },
  {
   "name": "Cuenta ajena (régimen general)",
   "desc": "کار کارمندی با کارفرما؛ بررسی Catálogo de ocupaciones de difícil cobertura.",
   "when": {
    "offer": [
     "yes"
    ]
   },
   "sources": [
    {
     "t": "Portal de Inmigración — Ministerio de Inclusión",
     "u": "https://www.inclusion.gob.es/web/migraciones/"
    }
   ]
  },
  {
   "name": "Emprendedor (Ley 14/2013)",
   "desc": "پروژه کارآفرینی نوآورانه با گزارش مثبت ENISA.",
   "when": {
    "startup": [
     "yes"
    ]
   },
   "sources": [
    {
     "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
     "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
    }
   ]
  },
  {
   "name": "Arraigo (social/sociolaboral/formación…)",
   "desc": "برای افرادی که مدتی در اسپانیا زندگی کرده‌اند؛ انواع arraigo در مقررات ۲۰۲۵ بازتعریف شده‌اند.",
   "when": {
    "inspain": [
     "yes"
    ]
   },
   "sources": [
    {
     "t": "Portal de Inmigración — Ministerio de Inclusión",
     "u": "https://www.inclusion.gob.es/web/migraciones/"
    }
   ]
  }
 ],
 "id": "astra-spain-work-route-explorer",
 "verified": "2026-10-01"
};
