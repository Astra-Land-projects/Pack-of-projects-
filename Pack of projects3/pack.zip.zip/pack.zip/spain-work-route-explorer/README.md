# Spain Work Route Explorer

بررسی مسیرهای کاری اسپانیا

مسیرهای HQP، Blue Card، cuenta ajena، دیجیتال نومد، کارآفرین و arraigo را بر اساس شرایط شما رتبه‌بندی کنید.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** Spain · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Portal de Inmigración — Ministerio de Inclusión](https://www.inclusion.gob.es/web/migraciones/)
- [Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups](https://www.inclusion.gob.es/web/unidadgrandesempresas/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
