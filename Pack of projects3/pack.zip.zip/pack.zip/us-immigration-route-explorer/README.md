# US Immigration Route Explorer

مسیر احتمالی از ورود تا اقامت دائم

مسیرهای چندمرحله‌ای رایج (مثلاً F-1 ← OPT ← H-1B ← گرین‌کارت) را با تاریخ شروع خودتان زمان‌بندی کنید. مدت‌ها تخمینی و قابل ویرایش‌اند.

**نوع ابزار:** تایم‌لاین مسیر · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند مسیر آماده
- مدت هر مرحله قابل ویرایش
- نمودار گانت SVG
- تیک انجام و خروجی ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS Check Case Processing Times](https://egov.uscis.gov/processing-times/)
- [Visa Bulletin — travel.state.gov](https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html)
- [USCIS OPT for F-1 Students](https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
