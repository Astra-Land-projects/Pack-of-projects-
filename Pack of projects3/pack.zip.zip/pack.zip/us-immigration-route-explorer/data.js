window.APP = {
 "slug": "us-immigration-route-explorer",
 "title": "US Immigration Route Explorer",
 "subtitle": "مسیر احتمالی از ورود تا اقامت دائم",
 "type": "timeline",
 "desc": "مسیرهای چندمرحله‌ای رایج (مثلاً F-1 ← OPT ← H-1B ← گرین‌کارت) را با تاریخ شروع خودتان زمان‌بندی کنید. مدت‌ها تخمینی و قابل ویرایش‌اند.",
 "sources": [
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/"
  },
  {
   "t": "Visa Bulletin — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
  },
  {
   "t": "USCIS OPT for F-1 Students",
   "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
  }
 ],
 "code": "US",
 "country": "USA",
 "routes": {
  "f1_h1b": {
   "label": "F-1 → OPT → H-1B → EB-2 (PERM)",
   "steps": [
    {
     "t": "اپلای و پذیرش + I-20",
     "days": 180,
     "u": "https://studyinthestates.dhs.gov/"
    },
    {
     "t": "ویزای F-1 و ورود",
     "days": 90
    },
    {
     "t": "تحصیل ارشد",
     "days": 640
    },
    {
     "t": "OPT (درخواست تا تأیید)",
     "days": 90,
     "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
    },
    {
     "t": "کار با OPT / STEM OPT",
     "days": 365
    },
    {
     "t": "ثبت‌نام و انتخاب H-1B",
     "days": 60
    },
    {
     "t": "شروع H-1B (۱ اکتبر)",
     "days": 180
    },
    {
     "t": "PERM و I-140",
     "days": 600,
     "u": "https://www.dol.gov/agencies/eta/foreign-labor/performance"
    },
    {
     "t": "انتظار Visa Bulletin و I-485",
     "days": 540,
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    }
   ]
  },
  "niw": {
   "label": "EB-2 NIW (خوداسپانسر)",
   "steps": [
    {
     "t": "آماده‌سازی شواهد و نامه‌ها",
     "days": 90
    },
    {
     "t": "ثبت I-140",
     "days": 1
    },
    {
     "t": "رسیدگی I-140 (یا premium)",
     "days": 240,
     "u": "https://egov.uscis.gov/processing-times/"
    },
    {
     "t": "انتظار تاریخ اولویت",
     "days": 365,
     "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
    },
    {
     "t": "I-485 یا مصاحبه کنسولی",
     "days": 300
    }
   ]
  },
  "spouse": {
   "label": "همسر شهروند آمریکا (کنسولی)",
   "steps": [
    {
     "t": "ثبت I-130",
     "days": 1
    },
    {
     "t": "رسیدگی I-130",
     "days": 365,
     "u": "https://egov.uscis.gov/processing-times/"
    },
    {
     "t": "NVC: هزینه‌ها، I-864، DS-260",
     "days": 90
    },
    {
     "t": "وقت مصاحبه و معاینه پزشکی",
     "days": 120
    },
    {
     "t": "ورود و دریافت کارت",
     "days": 60
    }
   ]
  },
  "dv": {
   "label": "لاتاری DV",
   "steps": [
    {
     "t": "ثبت‌نام در بازه رسمی",
     "days": 30,
     "u": "https://travel.state.gov/content/travel/en/us-visas/immigrate/diversity-visa-program-entry.html"
    },
    {
     "t": "اعلام نتایج",
     "days": 210
    },
    {
     "t": "DS-260 و مدارک",
     "days": 60
    },
    {
     "t": "انتظار نوبت مصاحبه",
     "days": 150
    },
    {
     "t": "مصاحبه و ورود",
     "days": 90
    }
   ]
  },
  "eb1": {
   "label": "EB-1A توانایی خارق‌العاده",
   "steps": [
    {
     "t": "جمع‌آوری شواهد",
     "days": 120
    },
    {
     "t": "I-140 (premium ممکن)",
     "days": 45
    },
    {
     "t": "I-485 / کنسولی",
     "days": 300
    }
   ]
  }
 },
 "id": "astra-us-immigration-route-explorer",
 "verified": "2026-10-01"
};
