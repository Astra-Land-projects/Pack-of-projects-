window.APP = {
 "slug": "netherlands-relocation-cost-calculator",
 "title": "Netherlands Relocation Cost Calculator",
 "subtitle": "برآورد هزینه انتقال به هلند",
 "type": "cost",
 "desc": "هزینه IND، legalisation اسناد، مسکن، بیمه و استقرار.",
 "sources": [
  {
   "t": "IND — Fees",
   "u": "https://ind.nl/en/fees-costs-of-an-application"
  },
  {
   "t": "IND — Immigration and Naturalisation Service",
   "u": "https://ind.nl/en"
  }
 ],
 "code": "NL",
 "country": "Netherlands",
 "costs": {
  "currency": "EUR",
  "alt": "USD",
  "rate": 1.08,
  "groups": [
   {
    "g": "رسمی (IND)",
    "items": [
     {
      "t": "هزینه درخواست HSM/Blue Card (پرداخت توسط کارفرما یا متقاضی)",
      "v": 0,
      "official": true,
      "u": "https://ind.nl/en/fees-costs-of-an-application"
     },
     {
      "t": "همراه (همسر/فرزند)",
      "v": 0,
      "official": true,
      "u": "https://ind.nl/en/fees-costs-of-an-application"
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "آپوستیل و ترجمه سوگندخورده",
      "v": 80
     },
     {
      "t": "ارزیابی IDW",
      "v": 200
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "بلیت",
      "v": 500,
      "per": true
     },
     {
      "t": "ودیعه اجاره",
      "v": 3600
     },
     {
      "t": "اجاره ماه اول",
      "v": 1800
     },
     {
      "t": "بیمه درمانی پایه (ماهانه)",
      "v": 155,
      "per": true
     },
     {
      "t": "OV-chipkaart و دوچرخه",
      "v": 250
     }
    ]
   }
  ]
 },
 "id": "astra-netherlands-relocation-cost-calculator",
 "verified": "2026-10-01"
};
