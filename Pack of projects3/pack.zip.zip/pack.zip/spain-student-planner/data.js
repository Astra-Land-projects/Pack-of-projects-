window.APP = {
 "slug": "spain-student-planner",
 "title": "Spain Student Planner",
 "subtitle": "برنامه تحصیل در اسپانیا",
 "type": "planner",
 "desc": "از انتخاب برنامه و homologación تا visado de estudios، TIE و empadronamiento.",
 "sources": [
  {
   "t": "Study in Spain (SEPIE)",
   "u": "https://www.studyinspain.info/"
  },
  {
   "t": "Ministerio de Asuntos Exteriores — Visados",
   "u": "https://www.exteriores.gob.es/"
  },
  {
   "t": "Cita Previa Extranjería",
   "u": "https://icp.administracionelectronica.gob.es/icpplus/index.html"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "plan": {
  "targetLabel": "شروع ترم",
  "phases": [
   {
    "name": "تحقیق",
    "off": -300,
    "tasks": [
     {
      "t": "جست‌وجو در Study in Spain",
      "u": "https://www.studyinspain.info/"
     },
     "DELE/SIELE یا IELTS"
    ]
   },
   {
    "name": "اپلای",
    "off": -240,
    "tasks": [
     "اپلای دانشگاه (یا UNEDasiss برای کارشناسی)"
    ]
   },
   {
    "name": "ویزا",
    "off": -90,
    "tasks": [
     {
      "t": "Visado de estudios از کنسولگری",
      "u": "https://www.exteriores.gob.es/"
     },
     "اثبات مالی (۱۰۰٪ IPREM ماهانه)",
     "بیمه درمانی خصوصی بدون فرانشیز",
     "گواهی پزشکی و سوءپیشینه (برای دوره‌های بیش از ۶ ماه)"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     "Empadronamiento",
     {
      "t": "Cita previa برای TIE ظرف ۳۰ روز",
      "u": "https://icp.administracionelectronica.gob.es/icpplus/index.html"
     },
     "NIE/TIE و حساب بانکی"
    ]
   },
   {
    "name": "در طول تحصیل",
    "off": 120,
    "tasks": [
     "کار تا ۳۰ ساعت در هفته طبق قوانین جدید (Reglamento 2025) — بررسی کنید"
    ]
   }
  ]
 },
 "id": "astra-spain-student-planner",
 "verified": "2026-10-01"
};
