window.APP = {
 "slug": "france-cost-of-living-tool",
 "title": "France Cost of Living Tool",
 "subtitle": "مقایسه هزینه زندگی شهرهای فرانسه",
 "type": "costliving",
 "desc": "هزینه ماهانه پاریس و شهرهای دیگر فرانسه (تخمین قابل ویرایش).",
 "sources": [
  {
   "t": "INSEE",
   "u": "https://www.insee.fr/en/"
  },
  {
   "t": "CAF — Housing benefit",
   "u": "https://www.caf.fr/"
  }
 ],
 "code": "FR",
 "country": "France",
 "currency": "EUR",
 "cities": [
  {
   "city": "Paris",
   "rent": 1400,
   "food": 420,
   "transport": 90,
   "utilities": 200,
   "other": 300
  },
  {
   "city": "Lyon",
   "rent": 850,
   "food": 360,
   "transport": 70,
   "utilities": 180,
   "other": 220
  },
  {
   "city": "Toulouse",
   "rent": 750,
   "food": 340,
   "transport": 60,
   "utilities": 170,
   "other": 200
  },
  {
   "city": "Bordeaux",
   "rent": 850,
   "food": 350,
   "transport": 60,
   "utilities": 170,
   "other": 210
  },
  {
   "city": "Lille",
   "rent": 750,
   "food": 340,
   "transport": 50,
   "utilities": 170,
   "other": 200
  },
  {
   "city": "Nantes",
   "rent": 800,
   "food": 340,
   "transport": 55,
   "utilities": 170,
   "other": 200
  },
  {
   "city": "Marseille",
   "rent": 800,
   "food": 350,
   "transport": 55,
   "utilities": 170,
   "other": 210
  },
  {
   "city": "Grenoble",
   "rent": 700,
   "food": 330,
   "transport": 50,
   "utilities": 170,
   "other": 190
  }
 ],
 "id": "astra-france-cost-of-living-tool",
 "verified": "2026-10-01"
};
