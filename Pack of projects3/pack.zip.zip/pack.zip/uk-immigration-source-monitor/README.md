# UK Immigration Source Monitor

پایش تغییرات منابع رسمی بریتانیا

صفحات GOV.UK (قوانین، هزینه‌ها، زمان پردازش، sponsor register) را پایش و تغییرات را لاگ کنید.

**نوع ابزار:** پایش منابع رسمی · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- فهرست منابع رسمی با دوره بررسی
- وضعیت به‌روز/نیاز به بررسی/تغییر کرده
- monitor.py برای تشخیص خودکار تغییر
- لاگ اخبار با دسته و اثر

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## پایش خودکار
```bash
python3 monitor.py          # بررسی همه منابع و ساخت changes.json
python3 monitor.py --report # نمایش آخرین گزارش
```
سپس changes.json را در بخش «ورود گزارش monitor.py» وارد کنید. برای اجرای روزانه: `0 8 * * * cd /path && python3 monitor.py`

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — UK Visas and Immigration news](https://www.gov.uk/government/organisations/uk-visas-and-immigration)
- [GOV.UK — Immigration Rules](https://www.gov.uk/guidance/immigration-rules)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
