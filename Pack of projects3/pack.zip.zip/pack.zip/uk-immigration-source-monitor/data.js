window.APP = {
 "slug": "uk-immigration-source-monitor",
 "title": "UK Immigration Source Monitor",
 "subtitle": "پایش تغییرات منابع رسمی بریتانیا",
 "type": "sources",
 "desc": "صفحات GOV.UK (قوانین، هزینه‌ها، زمان پردازش، sponsor register) را پایش و تغییرات را لاگ کنید.",
 "sources": [
  {
   "t": "GOV.UK — UK Visas and Immigration news",
   "u": "https://www.gov.uk/government/organisations/uk-visas-and-immigration"
  },
  {
   "t": "GOV.UK — Immigration Rules",
   "u": "https://www.gov.uk/guidance/immigration-rules"
  }
 ],
 "code": "UK",
 "country": "UK",
 "tags": [
  "Immigration Rules",
  "هزینه",
  "زمان پردازش",
  "Sponsor",
  "eVisa",
  "سایر"
 ],
 "list": [
  {
   "t": "GOV.UK — Immigration Rules",
   "u": "https://www.gov.uk/guidance/immigration-rules",
   "cat": "Immigration Rules",
   "freq": 7
  },
  {
   "t": "GOV.UK — Statements of changes to the Immigration Rules",
   "u": "https://www.gov.uk/government/collections/immigration-rules-statement-of-changes",
   "cat": "Immigration Rules",
   "freq": 7
  },
  {
   "t": "GOV.UK — Home Office immigration and nationality fees",
   "u": "https://www.gov.uk/government/publications/visa-regulations-revised-table",
   "cat": "هزینه",
   "freq": 14
  },
  {
   "t": "GOV.UK — Immigration Health Surcharge",
   "u": "https://www.gov.uk/healthcare-immigration-application",
   "cat": "هزینه",
   "freq": 30
  },
  {
   "t": "GOV.UK — Visa processing times",
   "u": "https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk",
   "cat": "زمان پردازش",
   "freq": 7
  },
  {
   "t": "GOV.UK — Processing times inside the UK",
   "u": "https://www.gov.uk/guidance/visa-processing-times-applications-inside-the-uk",
   "cat": "زمان پردازش",
   "freq": 7
  },
  {
   "t": "GOV.UK — Register of licensed sponsors: workers",
   "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers",
   "cat": "Sponsor",
   "freq": 7
  },
  {
   "t": "GOV.UK — Get access to your eVisa",
   "u": "https://www.gov.uk/get-access-evisa",
   "cat": "eVisa",
   "freq": 14
  },
  {
   "t": "GOV.UK — UK Visas and Immigration news",
   "u": "https://www.gov.uk/government/organisations/uk-visas-and-immigration",
   "cat": "سایر",
   "freq": 3
  },
  {
   "t": "GOV.UK — Skilled Worker visa",
   "u": "https://www.gov.uk/skilled-worker-visa",
   "cat": "Immigration Rules",
   "freq": 14
  }
 ],
 "id": "astra-uk-immigration-source-monitor",
 "verified": "2026-10-01"
};
window.MONITOR_PY = "#!/usr/bin/env python3\n\"\"\"Official-source change monitor (Astra Global Migration).\nDownloads each official page, strips markup/scripts, normalises whitespace,\nhashes the text and compares with the previous run. Writes changes.json,\nwhich can be imported into the web dashboard. Standard library only.\n\nUsage:\n  python3 monitor.py            # check all sources\n  python3 monitor.py --report   # print last report\n  python3 monitor.py --diff URL # show a short text diff for one source\n\"\"\"\nimport hashlib, json, re, sys, time, difflib, html\nfrom datetime import datetime, timezone\nfrom pathlib import Path\nfrom urllib.request import Request, urlopen\nfrom concurrent.futures import ThreadPoolExecutor\n\nSOURCES = [\n {\n  \"t\": \"GOV.UK — Immigration Rules\",\n  \"u\": \"https://www.gov.uk/guidance/immigration-rules\",\n  \"cat\": \"Immigration Rules\"\n },\n {\n  \"t\": \"GOV.UK — Statements of changes to the Immigration Rules\",\n  \"u\": \"https://www.gov.uk/government/collections/immigration-rules-statement-of-changes\",\n  \"cat\": \"Immigration Rules\"\n },\n {\n  \"t\": \"GOV.UK — Home Office immigration and nationality fees\",\n  \"u\": \"https://www.gov.uk/government/publications/visa-regulations-revised-table\",\n  \"cat\": \"هزینه\"\n },\n {\n  \"t\": \"GOV.UK — Immigration Health Surcharge\",\n  \"u\": \"https://www.gov.uk/healthcare-immigration-application\",\n  \"cat\": \"هزینه\"\n },\n {\n  \"t\": \"GOV.UK — Visa processing times\",\n  \"u\": \"https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk\",\n  \"cat\": \"زمان پردازش\"\n },\n {\n  \"t\": \"GOV.UK — Processing times inside the UK\",\n  \"u\": \"https://www.gov.uk/guidance/visa-processing-times-applications-inside-the-uk\",\n  \"cat\": \"زمان پردازش\"\n },\n {\n  \"t\": \"GOV.UK — Register of licensed sponsors: workers\",\n  \"u\": \"https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers\",\n  \"cat\": \"Sponsor\"\n },\n {\n  \"t\": \"GOV.UK — Get access to your eVisa\",\n  \"u\": \"https://www.gov.uk/get-access-evisa\",\n  \"cat\": \"eVisa\"\n },\n {\n  \"t\": \"GOV.UK — UK Visas and Immigration news\",\n  \"u\": \"https://www.gov.uk/government/organisations/uk-visas-and-immigration\",\n  \"cat\": \"سایر\"\n },\n {\n  \"t\": \"GOV.UK — Skilled Worker visa\",\n  \"u\": \"https://www.gov.uk/skilled-worker-visa\",\n  \"cat\": \"Immigration Rules\"\n }\n]\n\nHERE = Path(__file__).resolve().parent\nSTATE = HERE / \"monitor_state.json\"\nREPORT = HERE / \"changes.json\"\nUA = \"Mozilla/5.0 (AstraGlobalMigration source monitor; +https://github.com/)\"\n\ndef clean(raw: str) -> str:\n    raw = re.sub(r\"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\\1>\", \" \", raw)\n    raw = re.sub(r\"(?s)<!--.*?-->\", \" \", raw)\n    text = html.unescape(re.sub(r\"(?s)<[^>]+>\", \" \", raw))\n    text = re.sub(r\"\\b\\d{1,2}:\\d{2}(:\\d{2})?\\b\", \" \", text)  # drop clock times that change every load\n    return re.sub(r\"\\s+\", \" \", text).strip()\n\ndef fetch(src):\n    url = src[\"u\"]\n    try:\n        with urlopen(Request(url, headers={\"User-Agent\": UA, \"Accept-Language\": \"en\"}), timeout=30) as r:\n            body = r.read().decode(r.headers.get_content_charset() or \"utf-8\", \"replace\")\n            text = clean(body)\n            return url, {\"status\": r.status, \"text\": text, \"hash\": hashlib.sha256(text.encode()).hexdigest()}\n    except Exception as e:  # network errors are reported, not fatal\n        return url, {\"status\": 0, \"error\": str(e)[:200]}\n\ndef run():\n    state = json.loads(STATE.read_text()) if STATE.exists() else {}\n    now = datetime.now(timezone.utc).isoformat(timespec=\"seconds\")\n    results = []\n    with ThreadPoolExecutor(max_workers=8) as ex:\n        for url, res in ex.map(fetch, SOURCES):\n            src = next(s for s in SOURCES if s[\"u\"] == url)\n            prev = state.get(url, {})\n            changed = bool(res.get(\"hash\") and prev.get(\"hash\") and prev[\"hash\"] != res[\"hash\"])\n            if res.get(\"hash\"):\n                state[url] = {\"hash\": res[\"hash\"], \"checked\": now, \"text\": res[\"text\"][:200000],\n                              \"prev_text\": prev.get(\"text\", \"\") if changed else prev.get(\"prev_text\", \"\")}\n            results.append({\"title\": src[\"t\"], \"url\": url, \"cat\": src.get(\"cat\", \"\"), \"status\": res.get(\"status\"),\n                            \"error\": res.get(\"error\"), \"changed\": changed, \"first_seen\": not prev, \"checked\": now})\n            flag = \"CHANGED\" if changed else (\"ERROR \" + res.get(\"error\", \"\")[:60] if res.get(\"error\") else \"ok\")\n            print(f\"[{flag:>8}] {src['t']}\")\n    STATE.write_text(json.dumps(state, ensure_ascii=False))\n    REPORT.write_text(json.dumps({\"generated\": now, \"results\": results}, ensure_ascii=False, indent=1))\n    print(f\"\\n{sum(r['changed'] for r in results)} changed / {len(results)} sources -> {REPORT.name}\")\n\ndef report():\n    if not REPORT.exists(): print(\"no report yet; run without arguments first\"); return\n    r = json.loads(REPORT.read_text())\n    print(\"generated:\", r[\"generated\"])\n    for x in r[\"results\"]: print((\"* \" if x[\"changed\"] else \"  \") + x[\"title\"], \"-\", x[\"url\"])\n\ndef diff(url):\n    st = json.loads(STATE.read_text()).get(url) if STATE.exists() else None\n    if not st or not st.get(\"prev_text\"): print(\"no previous version stored\"); return\n    a, b = st[\"prev_text\"].split(\". \"), st[\"text\"].split(\". \")\n    for line in list(difflib.unified_diff(a, b, lineterm=\"\", n=0))[:80]: print(line)\n\nif __name__ == \"__main__\":\n    if \"--report\" in sys.argv: report()\n    elif \"--diff\" in sys.argv: diff(sys.argv[sys.argv.index(\"--diff\") + 1])\n    else: run()\n";
