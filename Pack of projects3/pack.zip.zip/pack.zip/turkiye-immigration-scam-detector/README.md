# Türkiye Immigration Scam Detector

تشخیص سایت‌ها، دامنه‌ها و ادعاهای مشکوک

لینک یا متن پیام را وارد کنید؛ ابزار دامنه را با فهرست دامنه‌های رسمی ترکیه مقایسه می‌کند، تقلید نام (typosquatting)، punycode، کوتاه‌کننده‌ها و ادعاهای پرخطر را تشخیص می‌دهد.

**نوع ابزار:** تشخیص کلاهبرداری · **کشور/منطقه:** Türkiye · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- مقایسه با دامنه‌های رسمی
- تشخیص typosquatting (Levenshtein)، punycode، IP، کوتاه‌کننده
- تحلیل متن برای الگوهای پرخطر
- امتیاز ریسک و سابقه

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Göç İdaresi Başkanlığı (Presidency of Migration Management)](https://www.goc.gov.tr/)
- [e-İkamet — Residence Permit Online Application](https://e-ikamet.goc.gov.tr/)
- [Republic of Türkiye Electronic Visa Application System](https://www.evisa.gov.tr/)
- [YİMER 157 — Foreigners Communication Center](https://en.goc.gov.tr/foreigners-communication-center)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
