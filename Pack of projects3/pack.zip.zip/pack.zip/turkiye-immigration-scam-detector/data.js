window.APP = {
 "slug": "turkiye-immigration-scam-detector",
 "title": "Türkiye Immigration Scam Detector",
 "subtitle": "تشخیص سایت‌ها، دامنه‌ها و ادعاهای مشکوک",
 "type": "scam",
 "desc": "لینک یا متن پیام را وارد کنید؛ ابزار دامنه را با فهرست دامنه‌های رسمی ترکیه مقایسه می‌کند، تقلید نام (typosquatting)، punycode، کوتاه‌کننده‌ها و ادعاهای پرخطر را تشخیص می‌دهد.",
 "sources": [
  {
   "t": "Göç İdaresi Başkanlığı (Presidency of Migration Management)",
   "u": "https://www.goc.gov.tr/"
  },
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  },
  {
   "t": "Republic of Türkiye Electronic Visa Application System",
   "u": "https://www.evisa.gov.tr/"
  },
  {
   "t": "YİMER 157 — Foreigners Communication Center",
   "u": "https://en.goc.gov.tr/foreigners-communication-center"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "scam": {
  "official": [
   "goc.gov.tr",
   "e-ikamet.goc.gov.tr",
   "evisa.gov.tr",
   "mfa.gov.tr",
   "konsolosluk.gov.tr",
   "turkiye.gov.tr",
   "csgb.gov.tr",
   "turkiyeburslari.gov.tr",
   "studyinturkiye.gov.tr",
   "yok.gov.tr",
   "invest.gov.tr",
   "iskur.gov.tr",
   "gib.gov.tr"
  ],
  "keywords": [
   "ikamet",
   "evisa",
   "e-visa",
   "visa",
   "goc",
   "residence",
   "turkiye",
   "turkey",
   "vize"
  ],
  "text": [
   {
    "re": "(تضمین|guarantee|garanti|100%)",
    "w": 3,
    "m": "ادعای تضمین نتیجه (مقامات رسمی تضمین نمی‌دهند)"
   },
   {
    "re": "(crypto|bitcoin|usdt|tether|کریپتو|تتر)",
    "w": 4,
    "m": "درخواست پرداخت با رمزارز"
   },
   {
    "re": "(western union|moneygram|gift card|کارت هدیه)",
    "w": 3,
    "m": "روش پرداخت غیرقابل بازگشت"
   },
   {
    "re": "(whatsapp|telegram|تلگرام|واتساپ)",
    "w": 2,
    "m": "ارتباط فقط از طریق پیام‌رسان"
   },
   {
    "re": "(فوری|urgent|acil|24 ?(hours|ساعت))",
    "w": 2,
    "m": "ایجاد فوریت ساختگی"
   },
   {
    "re": "(passport.*(send|ارسال)|اصل گذرنامه را ارسال)",
    "w": 3,
    "m": "درخواست ارسال اصل گذرنامه"
   },
   {
    "re": "(randevu.*(satış|ücret)|فروش نوبت|خرید نوبت)",
    "w": 3,
    "m": "فروش نوبت؛ نوبت رسمی رایگان است"
   },
   {
    "re": "(no documents|بدون مدرک|belgesiz)",
    "w": 3,
    "m": "ادعای اقامت بدون مدرک"
   },
   {
    "re": "(fast[- ]?track|vip|ویژه)",
    "w": 1,
    "m": "وعده مسیر ویژه/سریع"
   }
  ],
  "advice": "درخواست اقامت فقط از e-ikamet.goc.gov.tr و e-Visa فقط از evisa.gov.tr ثبت می‌شود. در صورت تردید با YİMER 157 تماس بگیرید."
 },
 "id": "astra-turkiye-immigration-scam-detector",
 "verified": "2026-10-01"
};
