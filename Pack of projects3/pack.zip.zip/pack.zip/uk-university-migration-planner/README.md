# UK University Migration Planner

تحصیل + برنامه‌ریزی شغلی در UK

سناریوی تحصیل ← Graduate ← Skilled Worker را با تاریخ‌های کلیدی، کارآموزی و جست‌وجوی کار برنامه‌ریزی کنید.

**نوع ابزار:** برنامه‌ریز زمان‌بندی‌شده · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- برنامه فازبندی‌شده نسبت به تاریخ هدف
- سناریوهای مختلف
- کارهای دلخواه، پیشرفت و ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Student visa](https://www.gov.uk/student-visa)
- [GOV.UK — Graduate visa](https://www.gov.uk/graduate-visa)
- [GOV.UK — Skilled Worker visa](https://www.gov.uk/skilled-worker-visa)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
