window.APP = {
 "slug": "uk-university-migration-planner",
 "title": "UK University Migration Planner",
 "subtitle": "تحصیل + برنامه‌ریزی شغلی در UK",
 "type": "planner",
 "desc": "سناریوی تحصیل ← Graduate ← Skilled Worker را با تاریخ‌های کلیدی، کارآموزی و جست‌وجوی کار برنامه‌ریزی کنید.",
 "sources": [
  {
   "t": "GOV.UK — Student visa",
   "u": "https://www.gov.uk/student-visa"
  },
  {
   "t": "GOV.UK — Graduate visa",
   "u": "https://www.gov.uk/graduate-visa"
  },
  {
   "t": "GOV.UK — Skilled Worker visa",
   "u": "https://www.gov.uk/skilled-worker-visa"
  }
 ],
 "code": "UK",
 "country": "UK",
 "plan": {
  "targetLabel": "شروع دوره",
  "phases": [
   {
    "name": "پیش از شروع",
    "off": -120,
    "tasks": [
     "CAS و ویزا",
     "فهرست کارفرمایان sponsor در حوزه شما"
    ]
   }
  ],
  "variants": {
   "ma": {
    "label": "ارشد یک ساله",
    "phases": [
     {
      "name": "ترم اول",
      "off": 30,
      "tasks": [
       "Career service دانشگاه",
       "LinkedIn و رویدادهای استخدام",
       "قواعد کار دانشجویی (ساعات مجاز در ترم)"
      ]
     },
     {
      "name": "ترم دوم",
      "off": 120,
      "tasks": [
       "اپلای graduate schemes (اغلب پاییز/زمستان)"
      ]
     },
     {
      "name": "پایان دوره",
      "off": 330,
      "tasks": [
       {
        "t": "درخواست Graduate visa پیش از پایان Student visa",
        "u": "https://www.gov.uk/graduate-visa"
       }
      ]
     },
     {
      "name": "Graduate",
      "off": 420,
      "tasks": [
       "کار تمام‌وقت",
       "مذاکره با کارفرما برای CoS Skilled Worker"
      ]
     }
    ]
   },
   "ba": {
    "label": "کارشناسی سه ساله",
    "phases": [
     {
      "name": "سال دوم",
      "off": 400,
      "tasks": [
       "Summer internship",
       "Placement year (در صورت وجود)"
      ]
     },
     {
      "name": "سال آخر",
      "off": 800,
      "tasks": [
       "Graduate schemes",
       {
        "t": "Graduate visa",
        "u": "https://www.gov.uk/graduate-visa"
       }
      ]
     }
    ]
   },
   "phd": {
    "label": "دکتری",
    "phases": [
     {
      "name": "پژوهش",
      "off": 365,
      "tasks": [
       "انتشار و endorsement احتمالی Global Talent"
      ]
     },
     {
      "name": "پایان",
      "off": 1300,
      "tasks": [
       {
        "t": "Graduate visa (مدت ویژه PhD را بررسی کنید)",
        "u": "https://www.gov.uk/graduate-visa"
       },
       {
        "t": "Global Talent",
        "u": "https://www.gov.uk/global-talent"
       }
      ]
     }
    ]
   }
  }
 },
 "id": "astra-uk-university-migration-planner",
 "verified": "2026-10-01"
};
