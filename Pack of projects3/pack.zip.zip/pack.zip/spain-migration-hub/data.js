window.APP = {
 "slug": "spain-migration-hub",
 "title": "Spain Migration Hub",
 "subtitle": "مرکز ابزارهای اسپانیا",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "Portal de Inmigración — Ministerio de Inclusión",
   "u": "https://www.inclusion.gob.es/web/migraciones/"
  },
  {
   "t": "Ministerio de Asuntos Exteriores — Visados",
   "u": "https://www.exteriores.gob.es/"
  },
  {
   "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "intro": "ابزارهای اسپانیا به Portal de Inmigración، UGE-CE (قانون Startups) و Exteriores متصل‌اند.",
 "links": [
  {
   "slug": "spain-student-planner",
   "title": "Spain Student Planner",
   "desc": "برنامه تحصیل در اسپانیا"
  },
  {
   "slug": "spain-work-route-explorer",
   "title": "Spain Work Route Explorer",
   "desc": "بررسی مسیرهای کاری اسپانیا"
  },
  {
   "slug": "spain-digital-nomad-information-hub",
   "title": "Spain Digital Nomad Information Hub",
   "desc": "اطلاعات ویزای دیجیتال نومد اسپانیا"
  },
  {
   "slug": "spain-cost-calculator",
   "title": "Spain Cost Calculator",
   "desc": "برآورد هزینه مهاجرت به اسپانیا"
  },
  {
   "slug": "spain-document-manager",
   "title": "Spain Document Manager",
   "desc": "مدیریت امن اسناد اسپانیا"
  }
 ],
 "facts": [
  "SMI ۲۰۲۶: ۱٬۲۲۱ یورو در ماه در ۱۴ پرداخت (۱۷٬۰۹۴ یورو در سال)",
  "درآمد حداقلی دیجیتال نومد: ۲۰۰٪ SMI ماهانه"
 ],
 "id": "astra-spain-migration-hub",
 "verified": "2026-10-01"
};
