# EU Immigration Country Compare

مقایسه چند کشور اروپایی در یک داشبورد

اطلاعات پایه (زبان، ارز، Blue Card، مرجع مهاجرت، پورتال‌های رسمی) را مقایسه کنید و با امتیازدهی وزنی شخصی رتبه‌بندی بگیرید.

**نوع ابزار:** مقایسه کشورها · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- جدول مقایسه اطلاعات پایه
- وزن‌دهی معیارها و امتیاز شخصی
- رتبه‌بندی نهایی

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [EU Immigration Portal (European Commission)](https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en)
- [EURES — European Job Mobility Portal](https://eures.europa.eu/)
- [Your Europe](https://europa.eu/youreurope/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
