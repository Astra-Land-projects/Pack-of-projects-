window.APP = {
 "slug": "eu-immigration-country-compare",
 "title": "EU Immigration Country Compare",
 "subtitle": "مقایسه چند کشور اروپایی در یک داشبورد",
 "type": "compare",
 "desc": "اطلاعات پایه (زبان، ارز، Blue Card، مرجع مهاجرت، پورتال‌های رسمی) را مقایسه کنید و با امتیازدهی وزنی شخصی رتبه‌بندی بگیرید.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  },
  {
   "t": "Your Europe",
   "u": "https://europa.eu/youreurope/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "compare": {
  "fields": [
   {
    "k": "lang",
    "l": "زبان رسمی"
   },
   {
    "k": "cur",
    "l": "ارز"
   },
   {
    "k": "bc",
    "l": "EU Blue Card"
   },
   {
    "k": "auth",
    "l": "مرجع مهاجرت"
   },
   {
    "k": "imm",
    "l": "پورتال مهاجرت"
   },
   {
    "k": "jobs",
    "l": "پورتال کار"
   },
   {
    "k": "study",
    "l": "پورتال تحصیل"
   }
  ],
  "rows": [
   {
    "name": "Germany",
    "v": {
     "lang": "German",
     "cur": "EUR",
     "bc": "بله",
     "auth": "Ausländerbehörde / Federal Foreign Office",
     "imm": "https://www.make-it-in-germany.com/en/",
     "jobs": "https://www.arbeitsagentur.de/jobsuche/",
     "study": "https://www.daad.de/en/"
    }
   },
   {
    "name": "France",
    "v": {
     "lang": "French",
     "cur": "EUR",
     "bc": "بله (Passeport talent – carte bleue européenne)",
     "auth": "Préfecture / ANEF",
     "imm": "https://france-visas.gouv.fr/",
     "jobs": "https://www.francetravail.fr/accueil/",
     "study": "https://www.campusfrance.org/en"
    }
   },
   {
    "name": "Italy",
    "v": {
     "lang": "Italian",
     "cur": "EUR",
     "bc": "بله",
     "auth": "Prefettura (Sportello Unico) / Questura",
     "imm": "https://vistoperitalia.esteri.it/",
     "jobs": "https://www.cliclavoro.gov.it/",
     "study": "https://www.universitaly.it/"
    }
   },
   {
    "name": "Spain",
    "v": {
     "lang": "Spanish",
     "cur": "EUR",
     "bc": "بله",
     "auth": "Ministerio de Inclusión / Extranjería",
     "imm": "https://www.inclusion.gob.es/web/migraciones/",
     "jobs": "https://www.sepe.es/",
     "study": "https://www.studyinspain.info/"
    }
   },
   {
    "name": "Netherlands",
    "v": {
     "lang": "Dutch",
     "cur": "EUR",
     "bc": "بله",
     "auth": "IND",
     "imm": "https://ind.nl/en",
     "jobs": "https://www.werk.nl/",
     "study": "https://www.studyinnl.org/"
    }
   },
   {
    "name": "Sweden",
    "v": {
     "lang": "Swedish",
     "cur": "SEK",
     "bc": "بله",
     "auth": "Migrationsverket",
     "imm": "https://www.migrationsverket.se/English/Startpage.html",
     "jobs": "https://arbetsformedlingen.se/other-languages/english-engelska",
     "study": "https://studyinsweden.se/"
    }
   },
   {
    "name": "Finland",
    "v": {
     "lang": "Finnish/Swedish",
     "cur": "EUR",
     "bc": "بله",
     "auth": "Migri",
     "imm": "https://migri.fi/en/home",
     "jobs": "https://tyomarkkinatori.fi/en",
     "study": "https://www.studyinfinland.fi/"
    }
   },
   {
    "name": "Austria",
    "v": {
     "lang": "German",
     "cur": "EUR",
     "bc": "بله",
     "auth": "MA35 / Bezirkshauptmannschaft",
     "imm": "https://www.migration.gv.at/en/",
     "jobs": "https://www.ams.at/",
     "study": "https://oead.at/en/"
    }
   },
   {
    "name": "Portugal",
    "v": {
     "lang": "Portuguese",
     "cur": "EUR",
     "bc": "بله",
     "auth": "AIMA",
     "imm": "https://aima.gov.pt/en",
     "jobs": "https://www.iefp.pt/",
     "study": "https://www.study-research.pt/"
    }
   },
   {
    "name": "Belgium",
    "v": {
     "lang": "Dutch/French/German",
     "cur": "EUR",
     "bc": "بله",
     "auth": "Office des Étrangers / DVZ",
     "imm": "https://dofi.ibz.be/en",
     "jobs": "https://www.vdab.be/",
     "study": "https://www.studyinbelgium.be/"
    }
   },
   {
    "name": "Ireland",
    "v": {
     "lang": "English/Irish",
     "cur": "EUR",
     "bc": "خیر (در Blue Card مشارکت ندارد؛ Critical Skills Permit)",
     "auth": "Department of Enterprise / ISD",
     "imm": "https://www.irishimmigration.ie/",
     "jobs": "https://www.jobsireland.ie/",
     "study": "https://www.educationinireland.com/"
    }
   },
   {
    "name": "Denmark",
    "v": {
     "lang": "Danish",
     "cur": "DKK",
     "bc": "خیر (EU Blue Card دانمارک قانون ملی جداگانه دارد)",
     "auth": "SIRI",
     "imm": "https://www.nyidanmark.dk/en-GB",
     "jobs": "https://www.workindenmark.dk/",
     "study": "https://studyindenmark.dk/"
    }
   }
  ],
  "criteria": [
   "بازار کار رشته من",
   "سختی زبان (بالا=آسان‌تر)",
   "هزینه زندگی (بالا=ارزان‌تر)",
   "مسیر اقامت دائم",
   "سطح حقوق",
   "کیفیت زندگی",
   "مناسب خانواده"
  ]
 },
 "id": "astra-eu-immigration-country-compare",
 "verified": "2026-10-01"
};
