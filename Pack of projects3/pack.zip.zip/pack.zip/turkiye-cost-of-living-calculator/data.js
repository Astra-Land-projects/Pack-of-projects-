window.APP = {
 "slug": "turkiye-cost-of-living-calculator",
 "title": "Türkiye Cost of Living Calculator",
 "subtitle": "مقایسه شهرها و هزینه‌های زندگی ترکیه",
 "type": "costliving",
 "desc": "هزینه ماهانه شهرهای ترکیه را مقایسه کنید. به دلیل تورم بالا، اعداد به دلار و تخمینی هستند؛ آن‌ها را با آگهی‌های جاری جایگزین کنید.",
 "sources": [
  {
   "t": "TÜİK — Turkish Statistical Institute",
   "u": "https://www.tuik.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "currency": "USD",
 "cities": [
  {
   "city": "Istanbul",
   "rent": 800,
   "food": 320,
   "transport": 45,
   "utilities": 120,
   "other": 200
  },
  {
   "city": "Ankara",
   "rent": 450,
   "food": 270,
   "transport": 35,
   "utilities": 100,
   "other": 150
  },
  {
   "city": "Izmir",
   "rent": 550,
   "food": 290,
   "transport": 35,
   "utilities": 105,
   "other": 170
  },
  {
   "city": "Antalya",
   "rent": 600,
   "food": 300,
   "transport": 35,
   "utilities": 110,
   "other": 170
  },
  {
   "city": "Bursa",
   "rent": 400,
   "food": 260,
   "transport": 30,
   "utilities": 95,
   "other": 140
  },
  {
   "city": "Eskişehir",
   "rent": 330,
   "food": 240,
   "transport": 25,
   "utilities": 90,
   "other": 120
  },
  {
   "city": "Trabzon",
   "rent": 320,
   "food": 240,
   "transport": 25,
   "utilities": 90,
   "other": 120
  }
 ],
 "id": "astra-turkiye-cost-of-living-calculator",
 "verified": "2026-10-01"
};
