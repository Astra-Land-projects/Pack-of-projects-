window.APP = {
 "slug": "uk-student-route-planner",
 "title": "UK Student Route Planner",
 "subtitle": "برنامه تحصیل در بریتانیا",
 "type": "planner",
 "desc": "از UCAS/اپلای مستقیم تا CAS، اثبات مالی ۲۸ روزه، درخواست ویزا، IHS و eVisa.",
 "sources": [
  {
   "t": "GOV.UK — Student visa",
   "u": "https://www.gov.uk/student-visa"
  },
  {
   "t": "UCAS",
   "u": "https://www.ucas.com/"
  },
  {
   "t": "GOV.UK — Immigration Health Surcharge",
   "u": "https://www.gov.uk/healthcare-immigration-application"
  }
 ],
 "code": "UK",
 "country": "UK",
 "plan": {
  "targetLabel": "شروع دوره (Course start date)",
  "phases": [
   {
    "name": "تحقیق",
    "off": -365,
    "tasks": [
     "انتخاب دانشگاه‌ها (student sponsor دارای مجوز)",
     {
      "t": "آزمون زبان SELT/پذیرفته‌شده دانشگاه",
      "u": "https://www.gov.uk/guidance/prove-your-english-language-abilities-with-a-secure-english-language-test-selt"
     }
    ]
   },
   {
    "name": "اپلای",
    "off": -300,
    "tasks": [
     {
      "t": "UCAS (کارشناسی) یا اپلای مستقیم (ارشد)",
      "u": "https://www.ucas.com/"
     },
     {
      "t": "Chevening/بورسیه‌ها",
      "u": "https://www.chevening.org/"
     }
    ]
   },
   {
    "name": "پذیرش",
    "off": -120,
    "tasks": [
     "Unconditional offer",
     "پرداخت ودیعه و دریافت CAS"
    ]
   },
   {
    "name": "مالی",
    "off": -100,
    "tasks": [
     "نگهداری وجوه لازم به مدت ۲۸ روز متوالی",
     {
      "t": "تست TB (در صورت الزام کشور)",
      "u": "https://www.gov.uk/tb-test-visa"
     }
    ]
   },
   {
    "name": "ویزا",
    "off": -90,
    "tasks": [
     {
      "t": "درخواست Student visa (تا ۶ ماه قبل از شروع)",
      "u": "https://www.gov.uk/student-visa"
     },
     {
      "t": "پرداخت IHS",
      "u": "https://www.gov.uk/healthcare-immigration-application"
     },
     "بیومتریک در VAC یا اپ"
    ]
   },
   {
    "name": "ورود",
    "off": -7,
    "tasks": [
     {
      "t": "ایجاد حساب UKVI و دسترسی به eVisa",
      "u": "https://www.gov.uk/get-access-evisa"
     },
     "ثبت‌نام دانشگاه و GP"
    ]
   }
  ]
 },
 "id": "astra-uk-student-route-planner",
 "verified": "2026-10-01"
};
