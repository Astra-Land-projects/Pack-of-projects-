window.APP = {
 "slug": "uk-cost-of-relocation",
 "title": "UK Cost of Relocation",
 "subtitle": "برآورد هزینه انتقال به بریتانیا",
 "type": "cost",
 "desc": "هزینه ویزا و IHS (از جدول رسمی) و هزینه استقرار را برآورد کنید.",
 "sources": [
  {
   "t": "GOV.UK — Home Office immigration and nationality fees",
   "u": "https://www.gov.uk/government/publications/visa-regulations-revised-table"
  },
  {
   "t": "GOV.UK — Immigration Health Surcharge",
   "u": "https://www.gov.uk/healthcare-immigration-application"
  }
 ],
 "code": "UK",
 "country": "UK",
 "costs": {
  "currency": "GBP",
  "alt": "USD",
  "rate": 1.27,
  "groups": [
   {
    "g": "رسمی",
    "items": [
     {
      "t": "هزینه درخواست ویزا (از جدول Home Office)",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://www.gov.uk/government/publications/visa-regulations-revised-table"
     },
     {
      "t": "IHS × سال‌ها (تعداد را سال × نفر بگذارید)",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://www.gov.uk/healthcare-immigration-application"
     },
     {
      "t": "Priority service (اختیاری)",
      "v": 0,
      "official": true
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "تست TB",
      "v": 100,
      "per": true
     },
     {
      "t": "آزمون SELT",
      "v": 200
     },
     {
      "t": "ترجمه",
      "v": 40
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "بلیت",
      "v": 600,
      "per": true
     },
     {
      "t": "ودیعه (حداکثر ۵ هفته اجاره در انگلستان)",
      "v": 1700
     },
     {
      "t": "اجاره ماه اول",
      "v": 1500
     },
     {
      "t": "Council tax ماهانه",
      "v": 150
     },
     {
      "t": "حمل‌ونقل ماهانه",
      "v": 150,
      "per": true
     }
    ]
   }
  ]
 },
 "id": "astra-uk-cost-of-relocation",
 "verified": "2026-10-01"
};
