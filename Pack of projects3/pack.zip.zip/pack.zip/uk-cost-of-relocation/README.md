# UK Cost of Relocation

برآورد هزینه انتقال به بریتانیا

هزینه ویزا و IHS (از جدول رسمی) و هزینه استقرار را برآورد کنید.

**نوع ابزار:** ماشین‌حساب هزینه · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- گروه‌ها و آیتم‌های قابل ویرایش
- هزینه به ازای هر نفر
- تبدیل ارز و بافر
- نمودار گروه‌ها و خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Home Office immigration and nationality fees](https://www.gov.uk/government/publications/visa-regulations-revised-table)
- [GOV.UK — Immigration Health Surcharge](https://www.gov.uk/healthcare-immigration-application)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
