window.APP = {
 "slug": "eu-cross-border-worker-assistant",
 "title": "EU Cross-Border Worker Assistant",
 "subtitle": "اطلاعات کار بین کشورهای مرزی",
 "type": "navigator",
 "desc": "کشور محل زندگی و کار و نوع اشتغال را انتخاب کنید تا قواعد کلی تأمین اجتماعی، مالیات، بیمه درمانی و بیکاری برای کارگران مرزی نمایش داده شود.",
 "sources": [
  {
   "t": "Your Europe — Cross-border commuters",
   "u": "https://europa.eu/youreurope/citizens/work/work-abroad/cross-border-commuters/"
  },
  {
   "t": "Your Europe — Social security cover abroad",
   "u": "https://europa.eu/youreurope/citizens/work/social-security-and-benefits/country-coverage/index_en.htm"
  },
  {
   "t": "Your Europe — Income taxes abroad",
   "u": "https://europa.eu/youreurope/citizens/work/taxes/income-taxes-abroad/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "questions": [
  {
   "id": "status",
   "q": "تابعیت/وضعیت",
   "options": [
    {
     "v": "eu",
     "l": "شهروند EU/EEA/سوئیس"
    },
    {
     "v": "tcn",
     "l": "تبعه کشور ثالث با اقامت در EU"
    }
   ]
  },
  {
   "id": "type",
   "q": "نوع اشتغال",
   "options": [
    {
     "v": "emp",
     "l": "کارمند در کشور دیگر (رفت‌وآمد روزانه/هفتگی)"
    },
    {
     "v": "posted",
     "l": "اعزام موقت از طرف کارفرما"
    },
    {
     "v": "multi",
     "l": "کار همزمان در چند کشور"
    },
    {
     "v": "self",
     "l": "خوداشتغال"
    }
   ]
  },
  {
   "id": "q",
   "q": "موضوع اصلی",
   "options": [
    {
     "v": "soc",
     "l": "تأمین اجتماعی"
    },
    {
     "v": "tax",
     "l": "مالیات"
    },
    {
     "v": "health",
     "l": "بیمه درمانی"
    },
    {
     "v": "unemp",
     "l": "بیکاری"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "تأمین اجتماعی — قاعده کشور محل کار",
   "desc": "به‌عنوان قاعده کلی، کارگر مرزی مشمول نظام تأمین اجتماعی کشور محل کار است.",
   "when": {
    "type": [
     "emp"
    ],
    "q": [
     "soc"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Social security cover abroad",
     "u": "https://europa.eu/youreurope/citizens/work/social-security-and-benefits/country-coverage/index_en.htm"
    }
   ]
  },
  {
   "name": "کارگر اعزامی — فرم A1",
   "desc": "در اعزام موقت، ممکن است مشمول نظام کشور مبدأ بمانید و فرم A1 لازم است.",
   "when": {
    "type": [
     "posted"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Posted workers",
     "u": "https://europa.eu/youreurope/citizens/work/work-abroad/posted-workers/"
    }
   ]
  },
  {
   "name": "کار در چند کشور",
   "desc": "قواعد خاص برای تعیین یک نظام قابل اعمال (با درصد فعالیت در کشور محل سکونت) و A1.",
   "when": {
    "type": [
     "multi"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Social security cover abroad",
     "u": "https://europa.eu/youreurope/citizens/work/social-security-and-benefits/country-coverage/index_en.htm"
    }
   ]
  },
  {
   "name": "مالیات — معاهدات دوجانبه",
   "desc": "مالیات بر درآمد عمدتاً تابع معاهدات اجتناب از مالیات مضاعف بین دو کشور است.",
   "when": {
    "q": [
     "tax"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Income taxes abroad",
     "u": "https://europa.eu/youreurope/citizens/work/taxes/income-taxes-abroad/"
    }
   ]
  },
  {
   "name": "بیمه درمانی — فرم S1",
   "desc": "کارگران مرزی معمولاً با S1 در کشور محل زندگی و کار به خدمات درمانی دسترسی دارند.",
   "when": {
    "q": [
     "health"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Health cover for cross-border workers",
     "u": "https://europa.eu/youreurope/citizens/health/unplanned-healthcare/temporary-stays/index_en.htm"
    }
   ]
  },
  {
   "name": "بیکاری کامل کارگر مرزی",
   "desc": "در بیکاری کامل، کارگر مرزی معمولاً مزایا را از کشور محل سکونت دریافت می‌کند.",
   "when": {
    "q": [
     "unemp"
    ]
   },
   "sources": [
    {
     "t": "Your Europe — Unemployment for frontier workers",
     "u": "https://europa.eu/youreurope/citizens/work/unemployment-and-benefits/unemployment/"
    }
   ]
  },
  {
   "name": "اتباع کشور ثالث",
   "desc": "قواعد آزادی تردد EU عمدتاً برای شهروندان EU است؛ تبعه کشور ثالث معمولاً در کشور محل کار نیز مجوز جداگانه لازم دارد.",
   "when": {
    "status": [
     "tcn"
    ]
   },
   "sources": [
    {
     "t": "EU Immigration Portal (European Commission)",
     "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
    }
   ]
  },
  {
   "name": "EURES Cross-border partnerships",
   "desc": "مشاوران EURES در مناطق مرزی برای سؤالات عملی کمک می‌کنند.",
   "when": {
    "status": [
     "eu",
     "tcn"
    ]
   },
   "sources": [
    {
     "t": "EURES — European Job Mobility Portal",
     "u": "https://eures.europa.eu/"
    }
   ]
  }
 ],
 "id": "astra-eu-cross-border-worker-assistant",
 "verified": "2026-10-01"
};
