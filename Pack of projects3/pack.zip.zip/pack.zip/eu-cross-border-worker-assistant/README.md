# EU Cross-Border Worker Assistant

اطلاعات کار بین کشورهای مرزی

کشور محل زندگی و کار و نوع اشتغال را انتخاب کنید تا قواعد کلی تأمین اجتماعی، مالیات، بیمه درمانی و بیکاری برای کارگران مرزی نمایش داده شود.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Your Europe — Cross-border commuters](https://europa.eu/youreurope/citizens/work/work-abroad/cross-border-commuters/)
- [Your Europe — Social security cover abroad](https://europa.eu/youreurope/citizens/work/social-security-and-benefits/country-coverage/index_en.htm)
- [Your Europe — Income taxes abroad](https://europa.eu/youreurope/citizens/work/taxes/income-taxes-abroad/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
