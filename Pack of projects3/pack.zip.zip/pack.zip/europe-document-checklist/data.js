window.APP = {
 "slug": "europe-document-checklist",
 "title": "Europe Document Checklist",
 "subtitle": "مدارک موردنیاز بر اساس کشور و هدف",
 "type": "checklist",
 "desc": "هدف را انتخاب کنید و چک‌لیست مدارک معمول ویزای ملی اروپا را پیگیری کنید.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  },
  {
   "t": "European Commission — Schengen visa policy",
   "u": "https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "common": [
  "گذرنامه با اعتبار کافی و صفحات خالی",
  "فرم درخواست ویزای ملی (D) کشور مقصد",
  "عکس بیومتریک طبق استاندارد ICAO",
  "بیمه درمانی معتبر",
  "اسناد مدنی با آپوستیل/تأیید و ترجمه رسمی"
 ],
 "cases": {
  "work": {
   "label": "کار / Blue Card",
   "items": [
    "قرارداد یا پیشنهاد کار امضاشده",
    "مدرک تحصیلی + ارزیابی (ENIC-NARIC/anabin)",
    "رزومه",
    "تأییدیه آژانس کار یا مجوز (در صورت الزام)"
   ]
  },
  "study": {
   "label": "تحصیل",
   "items": [
    "پذیرش‌نامه دانشگاه",
    "اثبات مالی (حساب مسدود/بورسیه)",
    "مدرک زبان",
    "ریزنمرات و مدارک"
   ]
  },
  "seek": {
   "label": "جست‌وجوی کار (مثلاً Opportunity Card)",
   "items": [
    "مدرک تحصیلی + ارزیابی",
    "مدرک زبان",
    "اثبات مالی",
    "انگیزه‌نامه"
   ]
  },
  "family": {
   "label": "پیوستن خانواده",
   "items": [
    "سند ازدواج/تولد",
    "مدرک اقامت حامی",
    "اثبات درآمد و مسکن حامی",
    {
     "t": "مدرک زبان پایه (برخی کشورها)",
     "opt": true
    }
   ]
  },
  "nomad": {
   "label": "دیجیتال نومد",
   "items": [
    "قرارداد/فاکتورهای کارفرمای خارجی",
    "اثبات درآمد حداقلی",
    "گواهی عدم سوءپیشینه",
    "مدرک تحصیلی یا سابقه"
   ]
  }
 },
 "id": "astra-europe-document-checklist",
 "verified": "2026-10-01"
};
