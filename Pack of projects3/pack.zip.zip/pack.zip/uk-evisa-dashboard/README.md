# UK eVisa Dashboard

مدیریت وضعیت eVisa و share code

وضعیت درخواست‌ها، eVisa و share codeهای ساخته‌شده را با تاریخ و یادآوری انقضا ثبت کنید. ابزار به حساب UKVI متصل نمی‌شود.

**نوع ابزار:** ردیاب پرونده · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- ثبت چند پرونده با اعتبارسنجی شماره
- تاریخچه وضعیت و فاصله بین مراحل
- یادآوری، اعلان مرورگر و خروجی ICS
- ورود/خروج JSON

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Get access to your eVisa](https://www.gov.uk/get-access-evisa)
- [GOV.UK — View and prove your immigration status](https://www.gov.uk/view-prove-immigration-status)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
