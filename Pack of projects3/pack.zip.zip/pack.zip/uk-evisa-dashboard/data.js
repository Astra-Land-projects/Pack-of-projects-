window.APP = {
 "slug": "uk-evisa-dashboard",
 "title": "UK eVisa Dashboard",
 "subtitle": "مدیریت وضعیت eVisa و share code",
 "type": "tracker",
 "desc": "وضعیت درخواست‌ها، eVisa و share codeهای ساخته‌شده را با تاریخ و یادآوری انقضا ثبت کنید. ابزار به حساب UKVI متصل نمی‌شود.",
 "sources": [
  {
   "t": "GOV.UK — Get access to your eVisa",
   "u": "https://www.gov.uk/get-access-evisa"
  },
  {
   "t": "GOV.UK — View and prove your immigration status",
   "u": "https://www.gov.uk/view-prove-immigration-status"
  }
 ],
 "code": "UK",
 "country": "UK",
 "tracker": {
  "refLabel": "شماره مرجع (GWF/UAN/share code)",
  "refHint": "مثلاً GWF012345678 یا share code",
  "refRegex": "",
  "statuses": [
   "Application submitted",
   "Biometrics done",
   "Decision pending",
   "Decision: granted",
   "UKVI account created",
   "eVisa linked to passport",
   "Share code generated",
   "Share code expired",
   "Details updated (passport change)"
  ],
  "caseTypes": [
   "eVisa account",
   "Student",
   "Skilled Worker",
   "Graduate",
   "Visitor",
   "ILR",
   "Family",
   "Share code — right to work",
   "Share code — right to rent",
   "Share code — travel"
  ],
  "checkUrl": "https://www.gov.uk/view-prove-immigration-status"
 },
 "id": "astra-uk-evisa-dashboard",
 "verified": "2026-10-01"
};
