# Italy Document Checklist

چک‌لیست مدارک ایتالیا

مدارک ویزای ملی و permesso di soggiorno برای تحصیل، کار و خانواده.

**نوع ابزار:** چک‌لیست مدارک · **کشور/منطقه:** Italy · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند نوع پرونده
- تیک‌ها و موارد دلخواه ذخیره می‌شوند
- نوار پیشرفت
- خروجی متن و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Visto per l'Italia — MAECI visa portal](https://vistoperitalia.esteri.it/)
- [Portale Immigrazione (permesso di soggiorno kit)](https://www.portaleimmigrazione.it/)
- [Polizia di Stato — Permesso di soggiorno](https://www.poliziadistato.it/articolo/permesso-di-soggiorno)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
