window.APP = {
 "slug": "italy-document-checklist",
 "title": "Italy Document Checklist",
 "subtitle": "چک‌لیست مدارک ایتالیا",
 "type": "checklist",
 "desc": "مدارک ویزای ملی و permesso di soggiorno برای تحصیل، کار و خانواده.",
 "sources": [
  {
   "t": "Visto per l'Italia — MAECI visa portal",
   "u": "https://vistoperitalia.esteri.it/"
  },
  {
   "t": "Portale Immigrazione (permesso di soggiorno kit)",
   "u": "https://www.portaleimmigrazione.it/"
  },
  {
   "t": "Polizia di Stato — Permesso di soggiorno",
   "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "common": [
  "گذرنامه + کپی همه صفحات",
  "فرم ویزای ملی",
  "عکس",
  "بیمه درمانی",
  "Codice fiscale (پس از ورود)"
 ],
 "cases": {
  "st": {
   "label": "دانشجویی",
   "items": [
    "Riepilogo Universitaly",
    "اثبات مالی طبق حداقل سالانه وزارت",
    "مدرک اقامت/مسکن",
    "DoV یا CIMEA Statement"
   ],
   "source": {
    "t": "Universitaly",
    "u": "https://www.universitaly.it/"
   }
  },
  "work": {
   "label": "کار (Nulla osta / Carta Blu)",
   "items": [
    "Nulla osta از Sportello Unico",
    "قرارداد کار",
    "مدارک تحصیلی"
   ],
   "source": {
    "t": "Integrazione Migranti (Ministry of Labour)",
    "u": "https://integrazionemigranti.gov.it/"
   }
  },
  "permesso": {
   "label": "Permesso di soggiorno (پس از ورود)",
   "items": [
    "Kit پستی تکمیل‌شده (Modulo 1/2)",
    "Marca da bollo",
    "رسید پرداخت کارت",
    "کپی ویزا و مهر ورود",
    "نوبت Questura و انگشت‌نگاری"
   ],
   "source": {
    "t": "Polizia di Stato — Permesso di soggiorno",
    "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
   }
  },
  "fam": {
   "label": "Ricongiungimento familiare",
   "items": [
    "Nulla osta خانوادگی",
    "اسناد مدنی قانونی‌شده و ترجمه",
    "Idoneità alloggiativa (تأیید مسکن)",
    "درآمد حامی"
   ],
   "source": {
    "t": "Portale Immigrazione (permesso di soggiorno kit)",
    "u": "https://www.portaleimmigrazione.it/"
   }
  }
 },
 "id": "astra-italy-document-checklist",
 "verified": "2026-10-01"
};
