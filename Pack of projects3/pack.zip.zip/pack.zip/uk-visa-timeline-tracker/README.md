# UK Visa Timeline Tracker

تایم‌لاین پرونده ویزای UK

مراحل پرونده (درخواست، بیومتریک، تصمیم، eVisa) را بر اساس اهداف خدمت رسمی زمان‌بندی و پیگیری کنید.

**نوع ابزار:** تایم‌لاین مسیر · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند مسیر آماده
- مدت هر مرحله قابل ویرایش
- نمودار گانت SVG
- تیک انجام و خروجی ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Visa processing times](https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk)
- [GOV.UK — Processing times inside the UK](https://www.gov.uk/guidance/visa-processing-times-applications-inside-the-uk)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
