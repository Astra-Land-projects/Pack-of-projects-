window.APP = {
 "slug": "uk-visa-timeline-tracker",
 "title": "UK Visa Timeline Tracker",
 "subtitle": "تایم‌لاین پرونده ویزای UK",
 "type": "timeline",
 "desc": "مراحل پرونده (درخواست، بیومتریک، تصمیم، eVisa) را بر اساس اهداف خدمت رسمی زمان‌بندی و پیگیری کنید.",
 "sources": [
  {
   "t": "GOV.UK — Visa processing times",
   "u": "https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk"
  },
  {
   "t": "GOV.UK — Processing times inside the UK",
   "u": "https://www.gov.uk/guidance/visa-processing-times-applications-inside-the-uk"
  }
 ],
 "code": "UK",
 "country": "UK",
 "routes": {
  "out": {
   "label": "درخواست خارج از UK (استاندارد)",
   "steps": [
    {
     "t": "تکمیل فرم آنلاین",
     "days": 3
    },
    {
     "t": "نوبت بیومتریک VAC",
     "days": 10
    },
    {
     "t": "تصمیم (هدف: ۳ هفته)",
     "days": 21,
     "u": "https://www.gov.uk/guidance/visa-processing-times-applications-outside-the-uk"
    },
    {
     "t": "دسترسی eVisa و سفر",
     "days": 7,
     "u": "https://www.gov.uk/get-access-evisa"
    }
   ]
  },
  "in": {
   "label": "درخواست داخل UK (تمدید/تغییر)",
   "steps": [
    {
     "t": "درخواست",
     "days": 2
    },
    {
     "t": "UKVCAS / اپ",
     "days": 10
    },
    {
     "t": "تصمیم (هدف: ۸ هفته)",
     "days": 56,
     "u": "https://www.gov.uk/guidance/visa-processing-times-applications-inside-the-uk"
    }
   ]
  },
  "priority": {
   "label": "Priority / Super priority",
   "steps": [
    {
     "t": "درخواست",
     "days": 1
    },
    {
     "t": "بیومتریک",
     "days": 3
    },
    {
     "t": "تصمیم سریع",
     "days": 5
    }
   ]
  }
 },
 "id": "astra-uk-visa-timeline-tracker",
 "verified": "2026-10-01"
};
