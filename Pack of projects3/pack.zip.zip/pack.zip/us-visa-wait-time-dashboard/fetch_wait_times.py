#!/usr/bin/env python3
"""Fetch the official U.S. Department of State 'Global Visa Wait Times' page
and convert any HTML tables into a long-format CSV (post,type,days,date)
that the dashboard can import. Standard library only.

If the page layout changes or data is loaded dynamically, the script saves
raw tables to wait_times_raw.csv so you can map columns manually.
"""
import csv, re, sys
from datetime import date
from html.parser import HTMLParser
from urllib.request import Request, urlopen

URL = "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html"

class Tables(HTMLParser):
    def __init__(self):
        super().__init__(); self.tables, self.t, self.r, self.c = [], None, None, None
    def handle_starttag(self, tag, a):
        if tag == "table": self.t = []
        elif tag == "tr" and self.t is not None: self.r = []
        elif tag in ("td", "th") and self.r is not None: self.c = ""
    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.c is not None: self.r.append(re.sub(r"\s+", " ", self.c).strip()); self.c = None
        elif tag == "tr" and self.r is not None: (self.t.append(self.r) if self.r else None); self.r = None
        elif tag == "table" and self.t is not None: self.tables.append(self.t); self.t = None
    def handle_data(self, d):
        if self.c is not None: self.c += d

def days(v):
    m = re.search(r"(\d+)", v.replace(",", ""))
    return int(m.group(1)) if m else None

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else URL
    if src.startswith("http"):
        html = urlopen(Request(src, headers={"User-Agent": "Mozilla/5.0"}), timeout=40).read().decode("utf-8", "replace")
    else:
        html = open(src, encoding="utf-8").read()  # allow a saved HTML file
    p = Tables(); p.feed(html)
    today = date.today().isoformat(); out = []
    with open("wait_times_raw.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        for t in p.tables:
            for r in t: w.writerow(r)
            w.writerow([])
            head = t[0] if t else []
            for r in t[1:]:
                if not r: continue
                post = r[0]
                for i, cell in enumerate(r[1:], 1):
                    d = days(cell)
                    if d is not None and i < len(head): out.append([post, head[i], d, today])
    with open("wait_times.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["post", "type", "days", "date"]); w.writerows(out)
    print(f"tables: {len(p.tables)}  rows: {len(out)}  -> wait_times.csv (raw: wait_times_raw.csv)")
    if not out: print("No table data found. The page may load data dynamically; save the page as HTML from your browser and run: python3 fetch_wait_times.py saved.html")

if __name__ == "__main__": main()
