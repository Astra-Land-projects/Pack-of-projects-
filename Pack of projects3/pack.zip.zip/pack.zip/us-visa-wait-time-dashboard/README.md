# US Visa Wait Time Dashboard

داشبورد زمان انتظار ویزا بر اساس کنسولگری و نوع ویزا

داده‌های رسمی زمان انتظار وقت مصاحبه را ثبت یا وارد کنید تا کنسولگری‌ها مقایسه و روند هر کدام نمایش داده شود. اسکریپت پایتون همراه پروژه جدول صفحه رسمی را به CSV تبدیل می‌کند.

**نوع ابزار:** داشبورد زمان انتظار · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- ثبت دستی یا ورود CSV
- مقایسه کنسولگری‌ها
- نمودار روند
- fetch_wait_times.py برای تبدیل جدول رسمی

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## دریافت داده رسمی
```bash
python3 fetch_wait_times.py   # خروجی: wait_times.csv (post,type,days,date)
```
فایل CSV را در داشبورد وارد کنید.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Global Visa Wait Times — travel.state.gov](https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html)
- [U.S. Department of State — U.S. Visas](https://travel.state.gov/content/travel/en/us-visas.html)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
