window.APP = {
 "slug": "us-visa-wait-time-dashboard",
 "title": "US Visa Wait Time Dashboard",
 "subtitle": "داشبورد زمان انتظار ویزا بر اساس کنسولگری و نوع ویزا",
 "type": "waittimes",
 "desc": "داده‌های رسمی زمان انتظار وقت مصاحبه را ثبت یا وارد کنید تا کنسولگری‌ها مقایسه و روند هر کدام نمایش داده شود. اسکریپت پایتون همراه پروژه جدول صفحه رسمی را به CSV تبدیل می‌کند.",
 "sources": [
  {
   "t": "Global Visa Wait Times — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html"
  },
  {
   "t": "U.S. Department of State — U.S. Visas",
   "u": "https://travel.state.gov/content/travel/en/us-visas.html"
  }
 ],
 "code": "US",
 "country": "USA",
 "wait": {
  "src": {
   "t": "Global Visa Wait Times — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html"
  },
  "types": [
   "B1/B2 (Visitor)",
   "F/M/J (Student/Exchange)",
   "H/L/O/P/Q (Petition-based)",
   "C/D (Crew/Transit)"
  ],
  "sample": []
 },
 "id": "astra-us-visa-wait-time-dashboard",
 "verified": "2026-10-01"
};
