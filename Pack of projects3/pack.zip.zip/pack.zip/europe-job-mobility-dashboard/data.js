window.APP = {
 "slug": "europe-job-mobility-dashboard",
 "title": "Europe Job Mobility Dashboard",
 "subtitle": "داشبورد فرصت‌های کاری و جابه‌جایی",
 "type": "jobs",
 "desc": "با یک عبارت، لینک جست‌وجو در EURES و سرویس‌های اشتغال عمومی ۸ کشور ساخته می‌شود؛ درخواست‌ها را در یک داشبورد پیگیری کنید.",
 "sources": [
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  },
  {
   "t": "EURES — Living and working",
   "u": "https://eures.europa.eu/living-and-working_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "jobs": {
  "qHint": "software developer",
  "lHint": "Berlin",
  "boards": [
   {
    "t": "EURES",
    "u": "https://europa.eu/eures/portal/jv-se/home",
    "d": "پورتال کاریابی رسمی EU"
   },
   {
    "t": "Bundesagentur für Arbeit (DE)",
    "u": "https://www.arbeitsagentur.de/jobsuche/suche?was={q}&wo={l}"
   },
   {
    "t": "France Travail (FR)",
    "u": "https://candidat.francetravail.fr/offres/recherche?motsCles={q}&lieux={l}"
   },
   {
    "t": "Werk.nl (NL)",
    "u": "https://www.werk.nl/werkzoekenden/vacatures/?zoekterm={q}"
   },
   {
    "t": "Arbetsförmedlingen (SE)",
    "u": "https://arbetsformedlingen.se/platsbanken/annonser?q={q}"
   },
   {
    "t": "Job Market Finland (FI)",
    "u": "https://tyomarkkinatori.fi/en/personal-customers/vacancies?q={q}"
   },
   {
    "t": "AMS (AT)",
    "u": "https://jobs.ams.at/public/emps/jobs?query={q}"
   },
   {
    "t": "IEFP (PT)",
    "u": "https://iefponline.iefp.pt/IEFP/pesquisas/search.do"
   },
   {
    "t": "LinkedIn Europe",
    "u": "https://www.linkedin.com/jobs/search/?keywords={q}&location={l}",
    "add": "visa sponsorship"
   }
  ],
  "fields": [
   {
    "id": "title",
    "l": "عنوان"
   },
   {
    "id": "org",
    "l": "شرکت"
   },
   {
    "id": "country",
    "l": "کشور"
   },
   {
    "id": "url",
    "l": "لینک"
   },
   {
    "id": "permit",
    "l": "نوع مجوز (Blue Card و…)"
   }
  ],
  "tips": [
   "آگهی‌های EURES از خدمات اشتغال عمومی کشورها جمع می‌شوند.",
   "برای هر کشور، مسیر مجوز را با ابزار EU Migration Navigator بسنجید."
  ]
 },
 "id": "astra-europe-job-mobility-dashboard",
 "verified": "2026-10-01"
};
