window.APP = {
 "slug": "france-student-route",
 "title": "France Student Route",
 "subtitle": "مسیر تحصیل در فرانسه (Études en France)",
 "type": "planner",
 "desc": "برنامه زمان‌بندی‌شده رویه Campus France / Études en France تا VLS-TS و اعتبارسنجی آنلاین آن پس از ورود.",
 "sources": [
  {
   "t": "Campus France",
   "u": "https://www.campusfrance.org/en"
  },
  {
   "t": "France-Visas (official visa website)",
   "u": "https://france-visas.gouv.fr/"
  },
  {
   "t": "ANEF — Administration numérique pour les étrangers en France",
   "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
  }
 ],
 "code": "FR",
 "country": "France",
 "plan": {
  "targetLabel": "شروع سال تحصیلی (سپتامبر)",
  "phases": [
   {
    "name": "تحقیق",
    "off": -330,
    "tasks": [
     {
      "t": "جست‌وجوی برنامه در Campus France",
      "u": "https://www.campusfrance.org/en"
     },
     "آزمون TCF/DELF یا IELTS"
    ]
   },
   {
    "name": "Études en France",
    "off": -270,
    "tasks": [
     "ایجاد پرونده در پلتفرم Études en France (کشورهای مشمول)",
     "انتخاب برنامه‌ها و ارسال"
    ]
   },
   {
    "name": "مصاحبه Campus France",
    "off": -180,
    "tasks": [
     "مصاحبه و تأیید پرونده"
    ]
   },
   {
    "name": "پذیرش و ویزا",
    "off": -90,
    "tasks": [
     {
      "t": "درخواست VLS-TS در France-Visas",
      "u": "https://france-visas.gouv.fr/"
     },
     "اثبات منابع مالی و مسکن"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     {
      "t": "اعتبارسنجی آنلاین VLS-TS ظرف ۳ ماه (ANEF)",
      "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
     },
     "ثبت‌نام بیمه Sécurité sociale étudiante",
     "CVEC و ثبت‌نام نهایی"
    ]
   },
   {
    "name": "مالی/مسکن",
    "off": 30,
    "tasks": [
     {
      "t": "درخواست کمک‌هزینه مسکن CAF",
      "u": "https://www.caf.fr/"
     },
     "حساب بانکی"
    ]
   }
  ]
 },
 "id": "astra-france-student-route",
 "verified": "2026-10-01"
};
