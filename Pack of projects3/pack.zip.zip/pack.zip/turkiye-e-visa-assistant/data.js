window.APP = {
 "slug": "turkiye-e-visa-assistant",
 "title": "Türkiye e-Visa Assistant",
 "subtitle": "راهنمای استفاده از پورتال رسمی e-Visa",
 "type": "wizard",
 "desc": "گام‌به‌گام همراه با بررسی‌های امنیتی برای دریافت e-Visa از پورتال رسمی.",
 "sources": [
  {
   "t": "Republic of Türkiye Electronic Visa Application System",
   "u": "https://www.evisa.gov.tr/"
  },
  {
   "t": "MFA Türkiye — Visa Information for Foreigners",
   "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "steps": [
  {
   "t": "باز کردن دامنه رسمی",
   "body": "فقط www.evisa.gov.tr. سایت‌های مشابه با هزینه بیشتر یا اطلاعات نادرست وجود دارند.",
   "tips": [
    "پسوند .gov.tr را بررسی کنید",
    "روی تبلیغات موتور جست‌وجو کلیک نکنید"
   ],
   "link": {
    "t": "Republic of Türkiye Electronic Visa Application System",
    "u": "https://www.evisa.gov.tr/"
   }
  },
  {
   "t": "انتخاب کشور و نوع سند",
   "body": "کشور صادرکننده گذرنامه و نوع سند سفر را انتخاب کنید؛ سیستم شرایط واجد بودن کشور را نمایش می‌دهد."
  },
  {
   "t": "تاریخ ورود",
   "body": "تاریخ تقریبی ورود را وارد کنید؛ اعتبار ویزا از این تاریخ محاسبه می‌شود."
  },
  {
   "t": "تأیید شرایط پیش‌نیاز",
   "body": "برای برخی کشورها e-Visa مشروط است (مثلاً داشتن ویزا یا اقامت معتبر از کشورهای مشخص یا بلیت برخی ایرلاین‌ها). موارد را صادقانه تأیید کنید.",
   "link": {
    "t": "MFA Türkiye — Visa Information for Foreigners",
    "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
   }
  },
  {
   "t": "اطلاعات شخصی و گذرنامه",
   "body": "اطلاعات را دقیقاً مطابق گذرنامه وارد کنید؛ اشتباه ممکن است به رد ورود منجر شود."
  },
  {
   "t": "پرداخت",
   "body": "با کارت بانکی (Visa/MasterCard/UnionPay) پرداخت کنید. هزینه بر اساس تابعیت متفاوت است."
  },
  {
   "t": "دانلود و نگهداری",
   "body": "e-Visa را دانلود، چاپ و همراه داشته باشید. اعتبار آن را با سایت رسمی Verify کنید."
  }
 ],
 "faq": [
  {
   "q": "e-Visa برای کار یا تحصیل معتبر است؟",
   "a": "خیر. e-Visa برای گردشگری و تجارت است؛ کار و تحصیل ویزای مخصوص از نمایندگی نیاز دارد."
  },
  {
   "q": "اگر کشورم معاف است چه؟",
   "a": "اتباع کشورهای معاف در محدوده مدت مجاز به e-Visa نیاز ندارند؛ جدول MFA را ببینید."
  }
 ],
 "id": "astra-turkiye-e-visa-assistant",
 "verified": "2026-10-01"
};
