window.APP = {
 "slug": "europe-immigration-source-tracker",
 "title": "Europe Immigration Source Tracker",
 "subtitle": "ذخیره و پایش منابع رسمی هر کشور",
 "type": "sources",
 "desc": "منابع رسمی ۱۲ کشور اروپایی و EU را با دوره بررسی، یادداشت و تشخیص خودکار تغییر (monitor.py) پیگیری کنید.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  },
  {
   "t": "Your Europe",
   "u": "https://europa.eu/youreurope/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "list": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en",
   "cat": "EU",
   "freq": 14
  },
  {
   "t": "EU Immigration Portal — EU Blue Card",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en",
   "cat": "EU",
   "freq": 30
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/",
   "cat": "EU",
   "freq": 14
  },
  {
   "t": "Make it in Germany (Federal Government portal)",
   "u": "https://www.make-it-in-germany.com/en/",
   "cat": "Germany",
   "freq": 14
  },
  {
   "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card",
   "cat": "Germany",
   "freq": 14
  },
  {
   "t": "France-Visas (official visa website)",
   "u": "https://france-visas.gouv.fr/",
   "cat": "France",
   "freq": 14
  },
  {
   "t": "Welcome to France",
   "u": "https://www.welcometofrance.com/en",
   "cat": "France",
   "freq": 14
  },
  {
   "t": "Visto per l'Italia — MAECI visa portal",
   "u": "https://vistoperitalia.esteri.it/",
   "cat": "Italy",
   "freq": 14
  },
  {
   "t": "Portal de Inmigración — Ministerio de Inclusión",
   "u": "https://www.inclusion.gob.es/web/migraciones/",
   "cat": "Spain",
   "freq": 14
  },
  {
   "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
   "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/",
   "cat": "Spain",
   "freq": 14
  },
  {
   "t": "IND — Immigration and Naturalisation Service",
   "u": "https://ind.nl/en",
   "cat": "Netherlands",
   "freq": 7
  },
  {
   "t": "IND — Required amounts income requirements",
   "u": "https://ind.nl/en/required-amounts-income-requirements",
   "cat": "Netherlands",
   "freq": 30
  },
  {
   "t": "Migrationsverket (Sweden)",
   "u": "https://www.migrationsverket.se/English/Startpage.html",
   "cat": "Sweden",
   "freq": 14
  },
  {
   "t": "Migri — Finnish Immigration Service",
   "u": "https://migri.fi/en/home",
   "cat": "Finland",
   "freq": 14
  },
  {
   "t": "Migration.gv.at (Austria)",
   "u": "https://www.migration.gv.at/en/",
   "cat": "Austria",
   "freq": 14
  },
  {
   "t": "AIMA — Agência para a Integração, Migrações e Asilo (Portugal)",
   "u": "https://aima.gov.pt/en",
   "cat": "Portugal",
   "freq": 14
  }
 ],
 "id": "astra-europe-immigration-source-tracker",
 "verified": "2026-10-01"
};
window.MONITOR_PY = "#!/usr/bin/env python3\n\"\"\"Official-source change monitor (Astra Global Migration).\nDownloads each official page, strips markup/scripts, normalises whitespace,\nhashes the text and compares with the previous run. Writes changes.json,\nwhich can be imported into the web dashboard. Standard library only.\n\nUsage:\n  python3 monitor.py            # check all sources\n  python3 monitor.py --report   # print last report\n  python3 monitor.py --diff URL # show a short text diff for one source\n\"\"\"\nimport hashlib, json, re, sys, time, difflib, html\nfrom datetime import datetime, timezone\nfrom pathlib import Path\nfrom urllib.request import Request, urlopen\nfrom concurrent.futures import ThreadPoolExecutor\n\nSOURCES = [\n {\n  \"t\": \"EU Immigration Portal (European Commission)\",\n  \"u\": \"https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en\",\n  \"cat\": \"EU\"\n },\n {\n  \"t\": \"EU Immigration Portal — EU Blue Card\",\n  \"u\": \"https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en\",\n  \"cat\": \"EU\"\n },\n {\n  \"t\": \"EURES — European Job Mobility Portal\",\n  \"u\": \"https://eures.europa.eu/\",\n  \"cat\": \"EU\"\n },\n {\n  \"t\": \"Make it in Germany (Federal Government portal)\",\n  \"u\": \"https://www.make-it-in-germany.com/en/\",\n  \"cat\": \"Germany\"\n },\n {\n  \"t\": \"Make it in Germany — Opportunity Card (Chancenkarte)\",\n  \"u\": \"https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card\",\n  \"cat\": \"Germany\"\n },\n {\n  \"t\": \"France-Visas (official visa website)\",\n  \"u\": \"https://france-visas.gouv.fr/\",\n  \"cat\": \"France\"\n },\n {\n  \"t\": \"Welcome to France\",\n  \"u\": \"https://www.welcometofrance.com/en\",\n  \"cat\": \"France\"\n },\n {\n  \"t\": \"Visto per l'Italia — MAECI visa portal\",\n  \"u\": \"https://vistoperitalia.esteri.it/\",\n  \"cat\": \"Italy\"\n },\n {\n  \"t\": \"Portal de Inmigración — Ministerio de Inclusión\",\n  \"u\": \"https://www.inclusion.gob.es/web/migraciones/\",\n  \"cat\": \"Spain\"\n },\n {\n  \"t\": \"Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups\",\n  \"u\": \"https://www.inclusion.gob.es/web/unidadgrandesempresas/\",\n  \"cat\": \"Spain\"\n },\n {\n  \"t\": \"IND — Immigration and Naturalisation Service\",\n  \"u\": \"https://ind.nl/en\",\n  \"cat\": \"Netherlands\"\n },\n {\n  \"t\": \"IND — Required amounts income requirements\",\n  \"u\": \"https://ind.nl/en/required-amounts-income-requirements\",\n  \"cat\": \"Netherlands\"\n },\n {\n  \"t\": \"Migrationsverket (Sweden)\",\n  \"u\": \"https://www.migrationsverket.se/English/Startpage.html\",\n  \"cat\": \"Sweden\"\n },\n {\n  \"t\": \"Migri — Finnish Immigration Service\",\n  \"u\": \"https://migri.fi/en/home\",\n  \"cat\": \"Finland\"\n },\n {\n  \"t\": \"Migration.gv.at (Austria)\",\n  \"u\": \"https://www.migration.gv.at/en/\",\n  \"cat\": \"Austria\"\n },\n {\n  \"t\": \"AIMA — Agência para a Integração, Migrações e Asilo (Portugal)\",\n  \"u\": \"https://aima.gov.pt/en\",\n  \"cat\": \"Portugal\"\n }\n]\n\nHERE = Path(__file__).resolve().parent\nSTATE = HERE / \"monitor_state.json\"\nREPORT = HERE / \"changes.json\"\nUA = \"Mozilla/5.0 (AstraGlobalMigration source monitor; +https://github.com/)\"\n\ndef clean(raw: str) -> str:\n    raw = re.sub(r\"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\\1>\", \" \", raw)\n    raw = re.sub(r\"(?s)<!--.*?-->\", \" \", raw)\n    text = html.unescape(re.sub(r\"(?s)<[^>]+>\", \" \", raw))\n    text = re.sub(r\"\\b\\d{1,2}:\\d{2}(:\\d{2})?\\b\", \" \", text)  # drop clock times that change every load\n    return re.sub(r\"\\s+\", \" \", text).strip()\n\ndef fetch(src):\n    url = src[\"u\"]\n    try:\n        with urlopen(Request(url, headers={\"User-Agent\": UA, \"Accept-Language\": \"en\"}), timeout=30) as r:\n            body = r.read().decode(r.headers.get_content_charset() or \"utf-8\", \"replace\")\n            text = clean(body)\n            return url, {\"status\": r.status, \"text\": text, \"hash\": hashlib.sha256(text.encode()).hexdigest()}\n    except Exception as e:  # network errors are reported, not fatal\n        return url, {\"status\": 0, \"error\": str(e)[:200]}\n\ndef run():\n    state = json.loads(STATE.read_text()) if STATE.exists() else {}\n    now = datetime.now(timezone.utc).isoformat(timespec=\"seconds\")\n    results = []\n    with ThreadPoolExecutor(max_workers=8) as ex:\n        for url, res in ex.map(fetch, SOURCES):\n            src = next(s for s in SOURCES if s[\"u\"] == url)\n            prev = state.get(url, {})\n            changed = bool(res.get(\"hash\") and prev.get(\"hash\") and prev[\"hash\"] != res[\"hash\"])\n            if res.get(\"hash\"):\n                state[url] = {\"hash\": res[\"hash\"], \"checked\": now, \"text\": res[\"text\"][:200000],\n                              \"prev_text\": prev.get(\"text\", \"\") if changed else prev.get(\"prev_text\", \"\")}\n            results.append({\"title\": src[\"t\"], \"url\": url, \"cat\": src.get(\"cat\", \"\"), \"status\": res.get(\"status\"),\n                            \"error\": res.get(\"error\"), \"changed\": changed, \"first_seen\": not prev, \"checked\": now})\n            flag = \"CHANGED\" if changed else (\"ERROR \" + res.get(\"error\", \"\")[:60] if res.get(\"error\") else \"ok\")\n            print(f\"[{flag:>8}] {src['t']}\")\n    STATE.write_text(json.dumps(state, ensure_ascii=False))\n    REPORT.write_text(json.dumps({\"generated\": now, \"results\": results}, ensure_ascii=False, indent=1))\n    print(f\"\\n{sum(r['changed'] for r in results)} changed / {len(results)} sources -> {REPORT.name}\")\n\ndef report():\n    if not REPORT.exists(): print(\"no report yet; run without arguments first\"); return\n    r = json.loads(REPORT.read_text())\n    print(\"generated:\", r[\"generated\"])\n    for x in r[\"results\"]: print((\"* \" if x[\"changed\"] else \"  \") + x[\"title\"], \"-\", x[\"url\"])\n\ndef diff(url):\n    st = json.loads(STATE.read_text()).get(url) if STATE.exists() else None\n    if not st or not st.get(\"prev_text\"): print(\"no previous version stored\"); return\n    a, b = st[\"prev_text\"].split(\". \"), st[\"text\"].split(\". \")\n    for line in list(difflib.unified_diff(a, b, lineterm=\"\", n=0))[:80]: print(line)\n\nif __name__ == \"__main__\":\n    if \"--report\" in sys.argv: report()\n    elif \"--diff\" in sys.argv: diff(sys.argv[sys.argv.index(\"--diff\") + 1])\n    else: run()\n";
