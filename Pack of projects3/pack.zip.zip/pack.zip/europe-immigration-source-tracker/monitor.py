#!/usr/bin/env python3
"""Official-source change monitor (Astra Global Migration).
Downloads each official page, strips markup/scripts, normalises whitespace,
hashes the text and compares with the previous run. Writes changes.json,
which can be imported into the web dashboard. Standard library only.

Usage:
  python3 monitor.py            # check all sources
  python3 monitor.py --report   # print last report
  python3 monitor.py --diff URL # show a short text diff for one source
"""
import hashlib, json, re, sys, time, difflib, html
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor

SOURCES = [
 {
  "t": "EU Immigration Portal (European Commission)",
  "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en",
  "cat": "EU"
 },
 {
  "t": "EU Immigration Portal — EU Blue Card",
  "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en",
  "cat": "EU"
 },
 {
  "t": "EURES — European Job Mobility Portal",
  "u": "https://eures.europa.eu/",
  "cat": "EU"
 },
 {
  "t": "Make it in Germany (Federal Government portal)",
  "u": "https://www.make-it-in-germany.com/en/",
  "cat": "Germany"
 },
 {
  "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
  "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card",
  "cat": "Germany"
 },
 {
  "t": "France-Visas (official visa website)",
  "u": "https://france-visas.gouv.fr/",
  "cat": "France"
 },
 {
  "t": "Welcome to France",
  "u": "https://www.welcometofrance.com/en",
  "cat": "France"
 },
 {
  "t": "Visto per l'Italia — MAECI visa portal",
  "u": "https://vistoperitalia.esteri.it/",
  "cat": "Italy"
 },
 {
  "t": "Portal de Inmigración — Ministerio de Inclusión",
  "u": "https://www.inclusion.gob.es/web/migraciones/",
  "cat": "Spain"
 },
 {
  "t": "Unidad de Grandes Empresas y Colectivos Estratégicos (UGE-CE) — Ley de Startups",
  "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/",
  "cat": "Spain"
 },
 {
  "t": "IND — Immigration and Naturalisation Service",
  "u": "https://ind.nl/en",
  "cat": "Netherlands"
 },
 {
  "t": "IND — Required amounts income requirements",
  "u": "https://ind.nl/en/required-amounts-income-requirements",
  "cat": "Netherlands"
 },
 {
  "t": "Migrationsverket (Sweden)",
  "u": "https://www.migrationsverket.se/English/Startpage.html",
  "cat": "Sweden"
 },
 {
  "t": "Migri — Finnish Immigration Service",
  "u": "https://migri.fi/en/home",
  "cat": "Finland"
 },
 {
  "t": "Migration.gv.at (Austria)",
  "u": "https://www.migration.gv.at/en/",
  "cat": "Austria"
 },
 {
  "t": "AIMA — Agência para a Integração, Migrações e Asilo (Portugal)",
  "u": "https://aima.gov.pt/en",
  "cat": "Portugal"
 }
]

HERE = Path(__file__).resolve().parent
STATE = HERE / "monitor_state.json"
REPORT = HERE / "changes.json"
UA = "Mozilla/5.0 (AstraGlobalMigration source monitor; +https://github.com/)"

def clean(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?s)<!--.*?-->", " ", raw)
    text = html.unescape(re.sub(r"(?s)<[^>]+>", " ", raw))
    text = re.sub(r"\b\d{1,2}:\d{2}(:\d{2})?\b", " ", text)  # drop clock times that change every load
    return re.sub(r"\s+", " ", text).strip()

def fetch(src):
    url = src["u"]
    try:
        with urlopen(Request(url, headers={"User-Agent": UA, "Accept-Language": "en"}), timeout=30) as r:
            body = r.read().decode(r.headers.get_content_charset() or "utf-8", "replace")
            text = clean(body)
            return url, {"status": r.status, "text": text, "hash": hashlib.sha256(text.encode()).hexdigest()}
    except Exception as e:  # network errors are reported, not fatal
        return url, {"status": 0, "error": str(e)[:200]}

def run():
    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    results = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for url, res in ex.map(fetch, SOURCES):
            src = next(s for s in SOURCES if s["u"] == url)
            prev = state.get(url, {})
            changed = bool(res.get("hash") and prev.get("hash") and prev["hash"] != res["hash"])
            if res.get("hash"):
                state[url] = {"hash": res["hash"], "checked": now, "text": res["text"][:200000],
                              "prev_text": prev.get("text", "") if changed else prev.get("prev_text", "")}
            results.append({"title": src["t"], "url": url, "cat": src.get("cat", ""), "status": res.get("status"),
                            "error": res.get("error"), "changed": changed, "first_seen": not prev, "checked": now})
            flag = "CHANGED" if changed else ("ERROR " + res.get("error", "")[:60] if res.get("error") else "ok")
            print(f"[{flag:>8}] {src['t']}")
    STATE.write_text(json.dumps(state, ensure_ascii=False))
    REPORT.write_text(json.dumps({"generated": now, "results": results}, ensure_ascii=False, indent=1))
    print(f"\n{sum(r['changed'] for r in results)} changed / {len(results)} sources -> {REPORT.name}")

def report():
    if not REPORT.exists(): print("no report yet; run without arguments first"); return
    r = json.loads(REPORT.read_text())
    print("generated:", r["generated"])
    for x in r["results"]: print(("* " if x["changed"] else "  ") + x["title"], "-", x["url"])

def diff(url):
    st = json.loads(STATE.read_text()).get(url) if STATE.exists() else None
    if not st or not st.get("prev_text"): print("no previous version stored"); return
    a, b = st["prev_text"].split(". "), st["text"].split(". ")
    for line in list(difflib.unified_diff(a, b, lineterm="", n=0))[:80]: print(line)

if __name__ == "__main__":
    if "--report" in sys.argv: report()
    elif "--diff" in sys.argv: diff(sys.argv[sys.argv.index("--diff") + 1])
    else: run()
