window.APP = {
 "slug": "germany-cost-calculator",
 "title": "Germany Cost Calculator",
 "subtitle": "برآورد هزینه مهاجرت به آلمان",
 "type": "cost",
 "desc": "هزینه‌های رسمی (ویزا، حساب مسدود، ارزیابی مدرک) و استقرار در آلمان را برآورد کنید.",
 "sources": [
  {
   "t": "Federal Foreign Office — Visa for Germany",
   "u": "https://www.auswaertiges-amt.de/en/visa-service"
  },
  {
   "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
  },
  {
   "t": "Federal Foreign Office — Blocked account information",
   "u": "https://www.auswaertiges-amt.de/en/visa-service/-/2639790"
  },
  {
   "t": "ZAB — Statement of Comparability",
   "u": "https://zab.kmk.org/en/statement-comparability"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "costs": {
  "currency": "EUR",
  "alt": "USD",
  "rate": 1.08,
  "groups": [
   {
    "g": "رسمی",
    "items": [
     {
      "t": "هزینه ویزای ملی (D) — از سفارت بررسی کنید",
      "v": 75,
      "official": true,
      "per": true,
      "u": "https://www.auswaertiges-amt.de/en/visa-service"
     },
     {
      "t": "ZAB Statement of Comparability",
      "v": 200,
      "official": true,
      "u": "https://zab.kmk.org/en/statement-comparability"
     },
     {
      "t": "کارت اقامت (eAT)",
      "v": 100,
      "official": true,
      "per": true
     }
    ]
   },
   {
    "g": "اثبات مالی (برگشت‌پذیر)",
    "items": [
     {
      "t": "حساب مسدود Opportunity Card: ۱٬۰۹۱ × ماه",
      "v": 1091,
      "official": true,
      "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
     },
     {
      "t": "کارمزد ارائه‌دهنده حساب مسدود",
      "v": 150
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "ترجمه رسمی (هر سند)",
      "v": 40
     },
     {
      "t": "آزمون زبان (Goethe/IELTS)",
      "v": 250
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "بلیت",
      "v": 500,
      "per": true
     },
     {
      "t": "ودیعه اجاره (Kaution تا ۳ ماه اجاره سرد)",
      "v": 2700
     },
     {
      "t": "اجاره ماه اول",
      "v": 1100
     },
     {
      "t": "بیمه درمانی ماه اول",
      "v": 130,
      "per": true
     },
     {
      "t": "Deutschlandticket",
      "v": 58,
      "per": true
     }
    ]
   }
  ]
 },
 "id": "astra-germany-cost-calculator",
 "verified": "2026-10-01"
};
