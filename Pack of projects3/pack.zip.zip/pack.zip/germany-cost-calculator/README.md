# Germany Cost Calculator

برآورد هزینه مهاجرت به آلمان

هزینه‌های رسمی (ویزا، حساب مسدود، ارزیابی مدرک) و استقرار در آلمان را برآورد کنید.

**نوع ابزار:** ماشین‌حساب هزینه · **کشور/منطقه:** Germany · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- گروه‌ها و آیتم‌های قابل ویرایش
- هزینه به ازای هر نفر
- تبدیل ارز و بافر
- نمودار گروه‌ها و خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Federal Foreign Office — Visa for Germany](https://www.auswaertiges-amt.de/en/visa-service)
- [Make it in Germany — Opportunity Card (Chancenkarte)](https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card)
- [Federal Foreign Office — Blocked account information](https://www.auswaertiges-amt.de/en/visa-service/-/2639790)
- [ZAB — Statement of Comparability](https://zab.kmk.org/en/statement-comparability)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
