window.APP = {
 "slug": "uscis-case-timeline-visualizer",
 "title": "USCIS Case Timeline Visualizer",
 "subtitle": "تبدیل وضعیت پرونده به تایم‌لاین گرافیکی",
 "type": "visualizer",
 "desc": "تاریخچه وضعیت‌ها را از پیام‌ها یا حساب USCIS کپی کنید؛ ابزار تاریخ‌ها را استخراج، مراحل را دسته‌بندی و تایم‌لاین SVG قابل دانلود می‌سازد.",
 "sources": [
  {
   "t": "USCIS Case Status Online",
   "u": "https://egov.uscis.gov/"
  },
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/"
  }
 ],
 "code": "US",
 "country": "USA",
 "sample": "2026-01-05 Case Was Received\n2026-01-20 Biometrics Appointment Was Scheduled\n2026-02-03 Fingerprints Were Taken\nApril 14, 2026 Request for Additional Evidence Was Sent\n2026-05-02 Response To USCIS' Request For Evidence Was Received\n2026-06-18 Interview Was Scheduled\n2026-07-22 Case Was Approved\n2026-07-29 Card Was Mailed To Me",
 "stages": [
  {
   "n": "Received",
   "c": "#0f5c8c",
   "k": [
    "received",
    "accepted"
   ]
  },
  {
   "n": "Biometrics",
   "c": "#6b4fbb",
   "k": [
    "biometric",
    "fingerprint"
   ]
  },
  {
   "n": "RFE",
   "c": "#c88a00",
   "k": [
    "evidence",
    "rfe",
    "noid"
   ]
  },
  {
   "n": "Review",
   "c": "#2a7f9e",
   "k": [
    "review",
    "transferred"
   ]
  },
  {
   "n": "Interview",
   "c": "#9c3d8f",
   "k": [
    "interview"
   ]
  },
  {
   "n": "Approved",
   "c": "#1f7a4d",
   "k": [
    "approved",
    "produced"
   ]
  },
  {
   "n": "Card",
   "c": "#11845b",
   "k": [
    "mailed",
    "delivered",
    "card"
   ]
  },
  {
   "n": "Denied",
   "c": "#b42318",
   "k": [
    "denied",
    "rejected"
   ]
  }
 ],
 "id": "astra-uscis-case-timeline-visualizer",
 "verified": "2026-10-01"
};
