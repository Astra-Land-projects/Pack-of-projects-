window.APP = {
 "slug": "europe-cost-of-living-map",
 "title": "Europe Cost of Living Map",
 "subtitle": "مقایسه هزینه زندگی شهرهای اروپا",
 "type": "costliving",
 "desc": "۱۸ شهر اروپایی را با اجاره، خوراک، حمل‌ونقل و قبوض مقایسه کنید (تخمین‌های قابل ویرایش به یورو) و مانده درآمد را ببینید.",
 "sources": [
  {
   "t": "Eurostat",
   "u": "https://ec.europa.eu/eurostat"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "currency": "EUR",
 "cities": [
  {
   "city": "Berlin",
   "rent": 1250,
   "food": 350,
   "transport": 58,
   "utilities": 250,
   "other": 250
  },
  {
   "city": "Munich",
   "rent": 1550,
   "food": 380,
   "transport": 63,
   "utilities": 260,
   "other": 280
  },
  {
   "city": "Paris",
   "rent": 1400,
   "food": 420,
   "transport": 90,
   "utilities": 200,
   "other": 300
  },
  {
   "city": "Lyon",
   "rent": 850,
   "food": 360,
   "transport": 70,
   "utilities": 180,
   "other": 220
  },
  {
   "city": "Milan",
   "rent": 1250,
   "food": 380,
   "transport": 39,
   "utilities": 200,
   "other": 250
  },
  {
   "city": "Rome",
   "rent": 1050,
   "food": 360,
   "transport": 35,
   "utilities": 190,
   "other": 230
  },
  {
   "city": "Madrid",
   "rent": 1250,
   "food": 330,
   "transport": 25,
   "utilities": 140,
   "other": 220
  },
  {
   "city": "Barcelona",
   "rent": 1250,
   "food": 340,
   "transport": 25,
   "utilities": 150,
   "other": 230
  },
  {
   "city": "Valencia",
   "rent": 900,
   "food": 300,
   "transport": 25,
   "utilities": 130,
   "other": 190
  },
  {
   "city": "Amsterdam",
   "rent": 1900,
   "food": 400,
   "transport": 110,
   "utilities": 240,
   "other": 300
  },
  {
   "city": "Rotterdam",
   "rent": 1350,
   "food": 370,
   "transport": 100,
   "utilities": 230,
   "other": 250
  },
  {
   "city": "Stockholm",
   "rent": 1300,
   "food": 380,
   "transport": 85,
   "utilities": 120,
   "other": 260
  },
  {
   "city": "Helsinki",
   "rent": 1050,
   "food": 380,
   "transport": 65,
   "utilities": 130,
   "other": 240
  },
  {
   "city": "Vienna",
   "rent": 950,
   "food": 370,
   "transport": 30,
   "utilities": 230,
   "other": 240
  },
  {
   "city": "Lisbon",
   "rent": 1200,
   "food": 320,
   "transport": 40,
   "utilities": 150,
   "other": 200
  },
  {
   "city": "Porto",
   "rent": 950,
   "food": 300,
   "transport": 40,
   "utilities": 140,
   "other": 180
  },
  {
   "city": "Brussels",
   "rent": 1050,
   "food": 370,
   "transport": 55,
   "utilities": 210,
   "other": 240
  },
  {
   "city": "Dublin",
   "rent": 2000,
   "food": 400,
   "transport": 100,
   "utilities": 230,
   "other": 300
  }
 ],
 "id": "astra-europe-cost-of-living-map",
 "verified": "2026-10-01"
};
