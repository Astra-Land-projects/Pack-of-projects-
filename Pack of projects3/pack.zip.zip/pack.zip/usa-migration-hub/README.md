# USA Migration Hub

مرکز ابزارهای مهاجرتی آمریکا

همه ابزارهای مستقل آمریکا در یک صفحه.

**نوع ابزار:** هاب کشوری · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- لینک به ابزارهای مستقل کشور

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS — U.S. Citizenship and Immigration Services](https://www.uscis.gov/)
- [U.S. Department of State — U.S. Visas](https://travel.state.gov/content/travel/en/us-visas.html)
- [USCIS Check Case Processing Times](https://egov.uscis.gov/processing-times/)
- [USCIS Fee Schedule (G-1055)](https://www.uscis.gov/g-1055)
- [Visa Bulletin — travel.state.gov](https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
