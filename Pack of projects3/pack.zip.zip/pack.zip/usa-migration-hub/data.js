window.APP = {
 "slug": "usa-migration-hub",
 "title": "USA Migration Hub",
 "subtitle": "مرکز ابزارهای مهاجرتی آمریکا",
 "type": "hub",
 "desc": "همه ابزارهای مستقل آمریکا در یک صفحه.",
 "sources": [
  {
   "t": "USCIS — U.S. Citizenship and Immigration Services",
   "u": "https://www.uscis.gov/"
  },
  {
   "t": "U.S. Department of State — U.S. Visas",
   "u": "https://travel.state.gov/content/travel/en/us-visas.html"
  },
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/"
  },
  {
   "t": "USCIS Fee Schedule (G-1055)",
   "u": "https://www.uscis.gov/g-1055"
  },
  {
   "t": "Visa Bulletin — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html"
  }
 ],
 "code": "US",
 "country": "USA",
 "intro": "ابزارهای این مجموعه هر کدام یک پروژه مستقل‌اند و بدون سرور اجرا می‌شوند؛ اطلاعات به منابع رسمی USCIS و وزارت خارجه آمریکا لینک شده است.",
 "links": [
  {
   "slug": "usa-visa-navigator",
   "title": "USA Visa Navigator",
   "desc": "انتخاب مسیر ویزا بر اساس هدف، تحصیل، کار و خانواده"
  },
  {
   "slug": "us-immigration-route-explorer",
   "title": "US Immigration Route Explorer",
   "desc": "مسیر احتمالی از ورود تا اقامت دائم"
  },
  {
   "slug": "uscis-case-tracker-pro",
   "title": "USCIS Case Tracker Pro",
   "desc": "پیگیری حرفه‌ای پرونده‌ها با تاریخچه، تایم‌لاین و یادآوری"
  },
  {
   "slug": "uscis-case-timeline-visualizer",
   "title": "USCIS Case Timeline Visualizer",
   "desc": "تبدیل وضعیت پرونده به تایم‌لاین گرافیکی"
  },
  {
   "slug": "us-immigration-document-builder",
   "title": "US Immigration Document Builder",
   "desc": "ساخت چک‌لیست مدارک بر اساس نوع پرونده"
  },
  {
   "slug": "us-visa-wait-time-dashboard",
   "title": "US Visa Wait Time Dashboard",
   "desc": "داشبورد زمان انتظار ویزا بر اساس کنسولگری و نوع ویزا"
  },
  {
   "slug": "us-immigration-cost-calculator",
   "title": "US Immigration Cost Calculator",
   "desc": "برآورد هزینه‌های اداری، ترجمه، سفر و سایر هزینه‌ها"
  },
  {
   "slug": "us-student-migration-planner",
   "title": "US Student Migration Planner",
   "desc": "برنامه‌ریزی تحصیل ← کار ← ماندن در آمریکا (بدون ادعای تضمین)"
  },
  {
   "slug": "us-sponsor-job-finder",
   "title": "US Sponsor Job Finder",
   "desc": "جست‌وجوی موقعیت‌های شغلی مرتبط با sponsorship"
  },
  {
   "slug": "us-cv-job-match-ai",
   "title": "US CV → Job Match AI",
   "desc": "تحلیل رزومه و مقایسه با آگهی شغلی برای بازار آمریکا"
  },
  {
   "slug": "us-immigration-news-monitor",
   "title": "US Immigration News Monitor",
   "desc": "پایش و دسته‌بندی تغییرات رسمی"
  },
  {
   "slug": "us-case-document-vault",
   "title": "US Case Document Vault",
   "desc": "مدیریت امن اسناد، تاریخ انقضا و چک‌لیست"
  },
  {
   "slug": "astra-usa-immigration-copilot",
   "title": "Astra USA Immigration Copilot",
   "desc": "پروفایل ← مسیرها ← مدارک ← ددلاین ← هزینه ← شغل/دانشگاه ← منابع رسمی"
  }
 ],
 "id": "astra-usa-migration-hub",
 "verified": "2026-10-01"
};
