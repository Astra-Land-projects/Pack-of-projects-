window.APP = {
 "slug": "eu-relocation-planner",
 "title": "EU Relocation Planner",
 "subtitle": "برنامه کامل relocation به اروپا",
 "type": "planner",
 "desc": "از ویزا تا ثبت آدرس، شماره مالیاتی، بانک، بیمه و مدرسه—همه با تاریخ.",
 "sources": [
  {
   "t": "Your Europe",
   "u": "https://europa.eu/youreurope/"
  },
  {
   "t": "EURES — Living and working",
   "u": "https://eures.europa.eu/living-and-working_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "plan": {
  "targetLabel": "تاریخ ورود",
  "phases": [
   {
    "name": "۶ ماه قبل",
    "off": -180,
    "tasks": [
     "انتخاب کشور/شهر (ابزار Country Compare)",
     "ارزیابی مدارک",
     "شروع زبان"
    ]
   },
   {
    "name": "۳ ماه قبل",
    "off": -90,
    "tasks": [
     "درخواست ویزای ملی",
     "آپوستیل و ترجمه اسناد",
     "جست‌وجوی مسکن موقت"
    ]
   },
   {
    "name": "۱ ماه قبل",
    "off": -30,
    "tasks": [
     "بیمه سفر/درمانی ورود",
     "انتقال پول و کارت بین‌المللی",
     "گواهی واکسن و سوابق پزشکی"
    ]
   },
   {
    "name": "هفته اول",
    "off": 7,
    "tasks": [
     "ثبت آدرس (Anmeldung / empadronamiento / BRP-BSN)",
     "سیم‌کارت و حساب بانکی"
    ]
   },
   {
    "name": "ماه اول",
    "off": 30,
    "tasks": [
     "شماره مالیاتی/تأمین اجتماعی",
     "ثبت‌نام بیمه درمانی ملی",
     "درخواست کارت اقامت"
    ]
   },
   {
    "name": "ماه سوم",
    "off": 90,
    "tasks": [
     "مدرسه/مهدکودک",
     "تعویض گواهینامه رانندگی (مهلت‌ها را بررسی کنید)",
     "دوره ادغام/زبان"
    ]
   }
  ]
 },
 "id": "astra-eu-relocation-planner",
 "verified": "2026-10-01"
};
