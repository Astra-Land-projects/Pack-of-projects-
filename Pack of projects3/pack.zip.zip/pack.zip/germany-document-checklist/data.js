window.APP = {
 "slug": "germany-document-checklist",
 "title": "Germany Document Checklist",
 "subtitle": "چک‌لیست مدارک ویزای آلمان",
 "type": "checklist",
 "desc": "مدارک معمول ویزای ملی آلمان برای کار، Blue Card، Opportunity Card، تحصیل و پیوستن خانواده.",
 "sources": [
  {
   "t": "Make it in Germany — Visa checklists",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/procedure/entry-process"
  },
  {
   "t": "Federal Foreign Office — Visa for Germany",
   "u": "https://www.auswaertiges-amt.de/en/visa-service"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "common": [
  "گذرنامه + کپی",
  "فرم درخواست ویزای ملی (VIDEX یا پورتال دیجیتال)",
  "۲ عکس بیومتریک",
  "بیمه درمانی ورود",
  {
   "t": "رسید هزینه ویزا",
   "note": "مبلغ را از سفارت بررسی کنید"
  }
 ],
 "cases": {
  "bc": {
   "label": "EU Blue Card",
   "items": [
    "قرارداد کار/پیشنهاد مشخص با حقوق",
    "مدرک دانشگاهی + چاپ anabin یا ZAB",
    "رزومه",
    {
     "t": "Berufsausübungserlaubnis برای حرفه قانون‌مند",
     "opt": true
    },
    "فرم Erklärung zum Beschäftigungsverhältnis"
   ],
   "source": {
    "t": "Make it in Germany — EU Blue Card",
    "u": "https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card"
   }
  },
  "oc": {
   "label": "Opportunity Card",
   "items": [
    "مدرک تحصیلی و anabin/Digital Statement",
    "مدرک زبان (A1 آلمانی/B2 انگلیسی)",
    "مدارک امتیازی (سابقه، زبان، سن…)",
    "حساب مسدود ۱٬۰۹۱ یورو در ماه (۲۰۲۶)"
   ],
   "source": {
    "t": "Make it in Germany — Opportunity Card (Chancenkarte)",
    "u": "https://www.make-it-in-germany.com/en/visa-residence/types/job-search-opportunity-card"
   }
  },
  "st": {
   "label": "دانشجویی",
   "items": [
    "پذیرش دانشگاه یا شرطی",
    "حساب مسدود ۱۱٬۹۰۴ یورو (۲۰۲۶)",
    "مدرک زبان",
    "ریزنمرات و مدارک",
    "انگیزه‌نامه و رزومه"
   ],
   "source": {
    "t": "DAAD — Study in Germany",
    "u": "https://www.daad.de/en/"
   }
  },
  "fam": {
   "label": "پیوستن خانواده",
   "items": [
    "سند ازدواج قانونی‌شده",
    "کارت اقامت همسر",
    "مدرک A1 آلمانی (در برخی موارد معاف)",
    "اثبات مسکن و درآمد"
   ],
   "source": {
    "t": "Make it in Germany (Federal Government portal)",
    "u": "https://www.make-it-in-germany.com/en/"
   }
  }
 },
 "id": "astra-germany-document-checklist",
 "verified": "2026-10-01"
};
