# Germany Document Checklist

چک‌لیست مدارک ویزای آلمان

مدارک معمول ویزای ملی آلمان برای کار، Blue Card، Opportunity Card، تحصیل و پیوستن خانواده.

**نوع ابزار:** چک‌لیست مدارک · **کشور/منطقه:** Germany · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند نوع پرونده
- تیک‌ها و موارد دلخواه ذخیره می‌شوند
- نوار پیشرفت
- خروجی متن و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Make it in Germany — Visa checklists](https://www.make-it-in-germany.com/en/visa-residence/procedure/entry-process)
- [Federal Foreign Office — Visa for Germany](https://www.auswaertiges-amt.de/en/visa-service)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
