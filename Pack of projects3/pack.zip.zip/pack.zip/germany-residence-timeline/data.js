window.APP = {
 "slug": "germany-residence-timeline",
 "title": "Germany Residence Timeline",
 "subtitle": "تایم‌لاین اقامت آلمان تا اقامت دائم/شهروندی",
 "type": "timeline",
 "desc": "مسیرهای رایج (Blue Card، نیروی ماهر، تحصیل) را تا Niederlassungserlaubnis و تابعیت زمان‌بندی کنید. مدت‌ها را با قوانین جاری BAMF تطبیق دهید.",
 "sources": [
  {
   "t": "BAMF — Federal Office for Migration and Refugees",
   "u": "https://www.bamf.de/EN/"
  },
  {
   "t": "Make it in Germany — EU Blue Card",
   "u": "https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card"
  },
  {
   "t": "BAMF — Naturalisation",
   "u": "https://www.bamf.de/EN/Themen/Integration/ZugewanderteTeilnehmende/Einbuergerung/einbuergerung-node.html"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "routes": {
  "bc": {
   "label": "EU Blue Card → اقامت دائم",
   "steps": [
    {
     "t": "ویزا و ورود",
     "days": 90
    },
    {
     "t": "Anmeldung و کارت Blue Card",
     "days": 60
    },
    {
     "t": "کار با Blue Card (با B1 آلمانی: حدود ۲۱ ماه)",
     "days": 640,
     "u": "https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card"
    },
    {
     "t": "Niederlassungserlaubnis",
     "days": 90
    },
    {
     "t": "تا واجد شرایط تابعیت (قانون ۲۰۲۴: معمولاً ۵ سال اقامت کل)",
     "days": 1100
    }
   ]
  },
  "sw": {
   "label": "نیروی ماهر (§18a/b)",
   "steps": [
    {
     "t": "ویزا",
     "days": 90
    },
    {
     "t": "کارت اقامت",
     "days": 60
    },
    {
     "t": "اشتغال تا اقامت دائم (معمولاً ۳ سال برای نیروی ماهر)",
     "days": 1035
    },
    {
     "t": "Niederlassungserlaubnis",
     "days": 90
    }
   ]
  },
  "st": {
   "label": "تحصیل → کار",
   "steps": [
    {
     "t": "ویزای دانشجویی",
     "days": 90
    },
    {
     "t": "تحصیل ارشد",
     "days": 730
    },
    {
     "t": "اقامت جست‌وجوی کار (تا ۱۸ ماه)",
     "days": 180
    },
    {
     "t": "Blue Card",
     "days": 60
    },
    {
     "t": "Niederlassungserlaubnis (مسیر فارغ‌التحصیلان آلمانی: ۲ سال)",
     "days": 730
    }
   ]
  }
 },
 "id": "astra-germany-residence-timeline",
 "verified": "2026-10-01"
};
