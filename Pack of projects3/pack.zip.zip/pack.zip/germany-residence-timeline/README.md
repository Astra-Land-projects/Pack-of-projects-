# Germany Residence Timeline

تایم‌لاین اقامت آلمان تا اقامت دائم/شهروندی

مسیرهای رایج (Blue Card، نیروی ماهر، تحصیل) را تا Niederlassungserlaubnis و تابعیت زمان‌بندی کنید. مدت‌ها را با قوانین جاری BAMF تطبیق دهید.

**نوع ابزار:** تایم‌لاین مسیر · **کشور/منطقه:** Germany · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند مسیر آماده
- مدت هر مرحله قابل ویرایش
- نمودار گانت SVG
- تیک انجام و خروجی ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [BAMF — Federal Office for Migration and Refugees](https://www.bamf.de/EN/)
- [Make it in Germany — EU Blue Card](https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card)
- [BAMF — Naturalisation](https://www.bamf.de/EN/Themen/Integration/ZugewanderteTeilnehmende/Einbuergerung/einbuergerung-node.html)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
