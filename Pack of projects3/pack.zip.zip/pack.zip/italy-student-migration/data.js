window.APP = {
 "slug": "italy-student-migration",
 "title": "Italy Student Migration",
 "subtitle": "برنامه تحصیل در ایتالیا",
 "type": "planner",
 "desc": "از پیش‌ثبت‌نام Universitaly تا ویزای دانشجویی، permesso di soggiorno و بورسیه DSU.",
 "sources": [
  {
   "t": "Universitaly",
   "u": "https://www.universitaly.it/"
  },
  {
   "t": "Study in Italy (MAECI)",
   "u": "https://studyinitaly.esteri.it/"
  },
  {
   "t": "Visto per l'Italia — MAECI visa portal",
   "u": "https://vistoperitalia.esteri.it/"
  },
  {
   "t": "Polizia di Stato — Permesso di soggiorno",
   "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "plan": {
  "targetLabel": "شروع سال تحصیلی (سپتامبر/اکتبر)",
  "phases": [
   {
    "name": "انتخاب برنامه",
    "off": -330,
    "tasks": [
     {
      "t": "جست‌وجوی برنامه‌ها در Universitaly",
      "u": "https://www.universitaly.it/"
     },
     "بررسی آزمون ورودی (TOLC/IMAT…)"
    ]
   },
   {
    "name": "اپلای دانشگاه",
    "off": -240,
    "tasks": [
     "ارسال مدارک به دانشگاه",
     "ارزیابی CIMEA / DoV"
    ]
   },
   {
    "name": "پیش‌ثبت‌نام",
    "off": -150,
    "tasks": [
     {
      "t": "Pre-enrollment در Universitaly",
      "u": "https://www.universitaly.it/"
     }
    ]
   },
   {
    "name": "بورسیه",
    "off": -120,
    "tasks": [
     {
      "t": "درخواست DSU منطقه‌ای (مثلاً ER.GO)",
      "u": "https://www.er-go.it/"
     },
     "ISEE parificato / مدارک درآمد خانوار"
    ]
   },
   {
    "name": "ویزا",
    "off": -90,
    "tasks": [
     {
      "t": "ویزای دانشجویی از کنسولگری",
      "u": "https://vistoperitalia.esteri.it/"
     }
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     {
      "t": "درخواست permesso ظرف ۸ روز کاری (kit پستی)",
      "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
     },
     "Codice fiscale",
     "ثبت‌نام نهایی دانشگاه"
    ]
   }
  ]
 },
 "id": "astra-italy-student-migration",
 "verified": "2026-10-01"
};
