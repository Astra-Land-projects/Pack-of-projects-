# Italy Student Migration

برنامه تحصیل در ایتالیا

از پیش‌ثبت‌نام Universitaly تا ویزای دانشجویی، permesso di soggiorno و بورسیه DSU.

**نوع ابزار:** برنامه‌ریز زمان‌بندی‌شده · **کشور/منطقه:** Italy · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- برنامه فازبندی‌شده نسبت به تاریخ هدف
- سناریوهای مختلف
- کارهای دلخواه، پیشرفت و ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Universitaly](https://www.universitaly.it/)
- [Study in Italy (MAECI)](https://studyinitaly.esteri.it/)
- [Visto per l'Italia — MAECI visa portal](https://vistoperitalia.esteri.it/)
- [Polizia di Stato — Permesso di soggiorno](https://www.poliziadistato.it/articolo/permesso-di-soggiorno)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
