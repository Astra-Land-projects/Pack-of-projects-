window.APP = {
 "slug": "italy-migration-hub",
 "title": "Italy Migration Hub",
 "subtitle": "مرکز ابزارهای ایتالیا",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "Visto per l'Italia — MAECI visa portal",
   "u": "https://vistoperitalia.esteri.it/"
  },
  {
   "t": "Study in Italy (MAECI)",
   "u": "https://studyinitaly.esteri.it/"
  },
  {
   "t": "Integrazione Migranti (Ministry of Labour)",
   "u": "https://integrazionemigranti.gov.it/"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "intro": "ابزارهای ایتالیا به Visto per l'Italia، Universitaly، Study in Italy و پورتال‌های permesso di soggiorno متصل‌اند.",
 "links": [
  {
   "slug": "italy-student-migration",
   "title": "Italy Student Migration",
   "desc": "برنامه تحصیل در ایتالیا"
  },
  {
   "slug": "italy-work-opportunity-finder",
   "title": "Italy Work Opportunity Finder",
   "desc": "جست‌وجوی فرصت‌های کاری ایتالیا"
  },
  {
   "slug": "italy-scholarship-finder",
   "title": "Italy Scholarship Finder",
   "desc": "موتور جست‌وجوی بورسیه ایتالیا"
  },
  {
   "slug": "italy-document-checklist",
   "title": "Italy Document Checklist",
   "desc": "چک‌لیست مدارک ایتالیا"
  },
  {
   "slug": "italy-relocation-calculator",
   "title": "Italy Relocation Calculator",
   "desc": "برآورد هزینه انتقال به ایتالیا"
  }
 ],
 "facts": [
  "پس از ورود با ویزای ملی، درخواست permesso di soggiorno ظرف ۸ روز کاری ثبت می‌شود.",
  "پیش‌ثبت‌نام دانشجویان بین‌المللی از طریق Universitaly."
 ],
 "id": "astra-italy-migration-hub",
 "verified": "2026-10-01"
};
