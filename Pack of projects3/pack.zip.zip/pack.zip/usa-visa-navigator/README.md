# USA Visa Navigator

انتخاب مسیر ویزا بر اساس هدف، تحصیل، کار و خانواده

با پاسخ به چند سؤال، دسته‌های ویزای مرتبط (غیرمهاجرتی و مهاجرتی) بر اساس معیارهای منتشرشده رتبه‌بندی می‌شوند.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Directory of Visa Categories](https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/all-visa-categories.html)
- [U.S. Department of State — U.S. Visas](https://travel.state.gov/content/travel/en/us-visas.html)
- [USCIS — U.S. Citizenship and Immigration Services](https://www.uscis.gov/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
