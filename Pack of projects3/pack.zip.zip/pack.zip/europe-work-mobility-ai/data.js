window.APP = {
 "slug": "europe-work-mobility-ai",
 "title": "Europe Work Mobility AI",
 "subtitle": "پیدا کردن کشورها/بازارهای مرتبط با مهارت شما",
 "type": "mobility",
 "desc": "حوزه تخصصی و زبان‌ها را انتخاب کنید؛ مدل امتیازی کشورهای اروپایی را بر اساس تقاضای بخش، تطابق زبانی و کاربرد انگلیسی رتبه‌بندی می‌کند. داده‌های کمبود را با گزارش رسمی EURES تطبیق دهید.",
 "sources": [
  {
   "t": "EURES — Labour shortages and surpluses report",
   "u": "https://eures.europa.eu/living-and-working/labour-market-information_en"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "mobility": {
  "sectors": [
   "IT/نرم‌افزار",
   "مهندسی",
   "سلامت/پرستاری",
   "آموزش",
   "مالی/حسابداری",
   "ساخت‌وساز/فنی",
   "لجستیک",
   "گردشگری/هتلداری",
   "پژوهش/دانشگاه"
  ],
  "languages": [
   "German",
   "Dutch",
   "French",
   "Spanish",
   "Italian",
   "Swedish",
   "Finnish/Swedish",
   "Portuguese",
   "Danish",
   "English"
  ],
  "countries": [
   {
    "c": "Germany",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "ساخت‌وساز/فنی",
     "لجستیک",
     "آموزش"
    ],
    "langs": [
     "German"
    ],
    "english": 1,
    "links": [
     {
      "t": "Make it in Germany (Federal Government portal)",
      "u": "https://www.make-it-in-germany.com/en/"
     },
     {
      "t": "Bundesagentur für Arbeit — Jobsuche",
      "u": "https://www.arbeitsagentur.de/jobsuche/"
     }
    ],
    "note": "کمبود گسترده نیروی ماهر؛ Opportunity Card برای جست‌وجوی کار."
   },
   {
    "c": "Netherlands",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "لجستیک",
     "مالی/حسابداری",
     "پژوهش/دانشگاه"
    ],
    "langs": [
     "Dutch"
    ],
    "english": 2,
    "links": [
     {
      "t": "IND — Immigration and Naturalisation Service",
      "u": "https://ind.nl/en"
     },
     {
      "t": "Werk.nl (UWV)",
      "u": "https://www.werk.nl/"
     }
    ],
    "note": "بازار بین‌المللی با کاربرد بالای انگلیسی."
   },
   {
    "c": "Sweden",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "آموزش",
     "پژوهش/دانشگاه"
    ],
    "langs": [
     "Swedish"
    ],
    "english": 2,
    "links": [
     {
      "t": "Migrationsverket (Sweden)",
      "u": "https://www.migrationsverket.se/English/Startpage.html"
     },
     {
      "t": "Arbetsförmedlingen (Sweden)",
      "u": "https://arbetsformedlingen.se/other-languages/english-engelska"
     }
    ],
    "note": ""
   },
   {
    "c": "Finland",
    "sectors": [
     "IT/نرم‌افزار",
     "سلامت/پرستاری",
     "مهندسی",
     "پژوهش/دانشگاه"
    ],
    "langs": [
     "Finnish/Swedish"
    ],
    "english": 1,
    "links": [
     {
      "t": "Work in Finland",
      "u": "https://www.workinfinland.com/en"
     },
     {
      "t": "Job Market Finland (Työmarkkinatori)",
      "u": "https://tyomarkkinatori.fi/en"
     }
    ],
    "note": ""
   },
   {
    "c": "Ireland",
    "sectors": [
     "IT/نرم‌افزار",
     "سلامت/پرستاری",
     "مالی/حسابداری",
     "مهندسی"
    ],
    "langs": [
     "English"
    ],
    "english": 2,
    "links": [
     {
      "t": "Irish Immigration Service",
      "u": "https://www.irishimmigration.ie/"
     },
     {
      "t": "Jobs Ireland",
      "u": "https://www.jobsireland.ie/"
     }
    ],
    "note": "Critical Skills Employment Permit به‌جای Blue Card."
   },
   {
    "c": "France",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "گردشگری/هتلداری",
     "پژوهش/دانشگاه"
    ],
    "langs": [
     "French"
    ],
    "english": 0,
    "links": [
     {
      "t": "Welcome to France",
      "u": "https://www.welcometofrance.com/en"
     },
     {
      "t": "France Travail (public employment service)",
      "u": "https://www.francetravail.fr/accueil/"
     }
    ],
    "note": ""
   },
   {
    "c": "Spain",
    "sectors": [
     "گردشگری/هتلداری",
     "IT/نرم‌افزار",
     "سلامت/پرستاری",
     "ساخت‌وساز/فنی"
    ],
    "langs": [
     "Spanish"
    ],
    "english": 0,
    "links": [
     {
      "t": "Portal de Inmigración — Ministerio de Inclusión",
      "u": "https://www.inclusion.gob.es/web/migraciones/"
     },
     {
      "t": "SEPE — Servicio Público de Empleo Estatal",
      "u": "https://www.sepe.es/"
     }
    ],
    "note": ""
   },
   {
    "c": "Italy",
    "sectors": [
     "مهندسی",
     "ساخت‌وساز/فنی",
     "گردشگری/هتلداری",
     "سلامت/پرستاری"
    ],
    "langs": [
     "Italian"
    ],
    "english": 0,
    "links": [
     {
      "t": "Integrazione Migranti (Ministry of Labour)",
      "u": "https://integrazionemigranti.gov.it/"
     }
    ],
    "note": ""
   },
   {
    "c": "Austria",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "ساخت‌وساز/فنی",
     "گردشگری/هتلداری"
    ],
    "langs": [
     "German"
    ],
    "english": 1,
    "links": [
     {
      "t": "Migration.gv.at (Austria)",
      "u": "https://www.migration.gv.at/en/"
     },
     {
      "t": "AMS — Austrian Public Employment Service",
      "u": "https://www.ams.at/"
     }
    ],
    "note": "فهرست مشاغل کمبود سالانه در migration.gv.at."
   },
   {
    "c": "Portugal",
    "sectors": [
     "IT/نرم‌افزار",
     "گردشگری/هتلداری",
     "ساخت‌وساز/فنی"
    ],
    "langs": [
     "Portuguese"
    ],
    "english": 1,
    "links": [
     {
      "t": "AIMA — Agência para a Integração, Migrações e Asilo (Portugal)",
      "u": "https://aima.gov.pt/en"
     },
     {
      "t": "IEFP — Portugal employment service",
      "u": "https://www.iefp.pt/"
     }
    ],
    "note": ""
   },
   {
    "c": "Belgium",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "لجستیک",
     "مالی/حسابداری"
    ],
    "langs": [
     "Dutch",
     "French"
    ],
    "english": 1,
    "links": [
     {
      "t": "Belgium — Immigration Office",
      "u": "https://dofi.ibz.be/en"
     }
    ],
    "note": ""
   },
   {
    "c": "Denmark",
    "sectors": [
     "IT/نرم‌افزار",
     "مهندسی",
     "سلامت/پرستاری",
     "پژوهش/دانشگاه"
    ],
    "langs": [
     "Danish"
    ],
    "english": 2,
    "links": [
     {
      "t": "New to Denmark",
      "u": "https://www.nyidanmark.dk/en-GB"
     },
     {
      "t": "Work in Denmark",
      "u": "https://www.workindenmark.dk/"
     }
    ],
    "note": ""
   }
  ]
 },
 "id": "astra-europe-work-mobility-ai",
 "verified": "2026-10-01"
};
