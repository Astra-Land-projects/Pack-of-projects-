window.APP = {
 "slug": "eu-blue-card-explorer",
 "title": "EU Blue Card Explorer",
 "subtitle": "مقایسه اطلاعات Blue Card کشورهای مختلف",
 "type": "explorer",
 "desc": "اطلاعات Blue Card کشورهای عضو را مرور و مقایسه کنید و حقوق پیشنهادی را با آستانه رسمی کشور مقصد بسنجید.",
 "sources": [
  {
   "t": "EU Immigration Portal — EU Blue Card",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en"
  },
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "listTitle": "Blue Card در کشورهای عضو",
 "items": [
  {
   "name": "Germany — Blaue Karte EU",
   "tags": [
    "DE"
   ],
   "summary": "حداقل حقوق سالانه هر سال اعلام می‌شود و برای مشاغل کمبود و فارغ‌التحصیلان اخیر کمتر است.",
   "facts": {
    "مرجع": "Ausländerbehörde / سفارت",
    "زبان": "آلمانی (الزام زبان برای Blue Card ندارد)",
    "مسیر اقامت دائم": "کوتاه‌تر با زبان B1",
    "قرارداد": "حداقل ۶ ماه طبق دستورالعمل"
   },
   "url": "https://www.make-it-in-germany.com/en/visa-residence/types/eu-blue-card"
  },
  {
   "name": "France — Passeport talent (carte bleue européenne)",
   "tags": [
    "FR"
   ],
   "summary": "زیر مجموعه «Passeport talent»؛ آستانه حقوق در صفحه رسمی اعلام می‌شود.",
   "facts": {
    "مرجع": "Préfecture / France-Visas",
    "زبان": "فرانسوی",
    "مسیر اقامت دائم": "طبق قوانین carte de résident",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://www.welcometofrance.com/en/fiche/talent-passport"
  },
  {
   "name": "Netherlands — European Blue Card",
   "tags": [
    "NL"
   ],
   "summary": "کارفرما می‌تواند sponsor شناخته‌شده باشد؛ مبالغ حقوق در صفحه Required amounts IND.",
   "facts": {
    "مرجع": "IND",
    "زبان": "هلندی/انگلیسی در بازار کار IT",
    "مسیر اقامت دائم": "۵ سال",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://ind.nl/en/residence-permits/work/european-blue-card-residence-permit"
  },
  {
   "name": "Italy — Carta Blu UE",
   "tags": [
    "IT"
   ],
   "summary": "درخواست nulla osta از Sportello Unico per l'Immigrazione توسط کارفرما.",
   "facts": {
    "مرجع": "Prefettura",
    "زبان": "ایتالیایی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://integrazionemigranti.gov.it/en-gb/"
  },
  {
   "name": "Spain — Tarjeta Azul-UE",
   "tags": [
    "ES"
   ],
   "summary": "از طریق UGE-CE در قالب قانون Ley 14/2013 برای کارفرمایان مشمول یا مسیر عمومی.",
   "facts": {
    "مرجع": "UGE-CE / Extranjería",
    "زبان": "اسپانیایی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
  },
  {
   "name": "Sweden — EU Blue Card",
   "tags": [
    "SE"
   ],
   "summary": "آستانه حقوق ضریبی از میانگین حقوق ناخالص سوئد است.",
   "facts": {
    "مرجع": "Migrationsverket",
    "زبان": "سوئدی/انگلیسی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://www.migrationsverket.se/en/you-want-to-apply/work/employee-or-self-employed/eu-blue-cards.html"
  },
  {
   "name": "Finland — EU Blue Card",
   "tags": [
    "FI"
   ],
   "summary": "امکان رسیدگی سریع (fast track) برای متخصصان طبق اعلام Migri.",
   "facts": {
    "مرجع": "Migri",
    "زبان": "فنلاندی/انگلیسی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://migri.fi/en/eu-blue-card"
  },
  {
   "name": "Austria — Blue Card EU",
   "tags": [
    "AT"
   ],
   "summary": "بخشی از سیستم Red-White-Red Card؛ نیاز به پیشنهاد کار و حقوق حداقلی.",
   "facts": {
    "مرجع": "AMS + مرجع اقامت",
    "زبان": "آلمانی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://www.migration.gv.at/en/types-of-immigration/permanent-immigration/eu-blue-card/"
  },
  {
   "name": "Portugal — Cartão Azul UE",
   "tags": [
    "PT"
   ],
   "summary": "ویزای کاری متخصص و سپس اقامت از طریق AIMA.",
   "facts": {
    "مرجع": "AIMA / Vistos MNE",
    "زبان": "پرتغالی",
    "قرارداد": "حداقل ۶ ماه"
   },
   "url": "https://aima.gov.pt/en"
  }
 ],
 "calc": {
  "title": "بررسی حقوق در برابر آستانه",
  "fields": [
   {
    "id": "salary",
    "l": "حقوق ناخالص سالانه پیشنهادی (EUR)",
    "v": 60000
   },
   {
    "id": "thr",
    "l": "آستانه عمومی کشور (از صفحه رسمی)",
    "v": 0
   },
   {
    "id": "thrs",
    "l": "آستانه کاهش‌یافته مشاغل کمبود/فارغ‌التحصیلان (اختیاری)",
    "v": 0
   },
   {
    "id": "short",
    "l": "شغل کمبود یا فارغ‌التحصیل اخیر؟ (۱=بله، ۰=خیر)",
    "v": 0
   }
  ],
  "formula": "(()=>{const t=(short&&thrs)?thrs:thr; if(!t) return {ok:false,msg:'آستانه رسمی کشور را از صفحه Blue Card آن کشور وارد کنید.'}; const d=salary-t; return d>=0?{ok:true,msg:'حقوق '+Math.round(d).toLocaleString()+' یورو بالاتر از آستانه است (مطابقت اولیه).'}:{ok:false,msg:'حقوق '+Math.round(-d).toLocaleString()+' یورو کمتر از آستانه است.'}})()",
  "note": "آستانه‌ها سالانه به‌روز می‌شوند. عدد دقیق را از صفحه رسمی کشور بخوانید.",
  "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en"
 },
 "id": "astra-eu-blue-card-explorer",
 "verified": "2026-10-01"
};
