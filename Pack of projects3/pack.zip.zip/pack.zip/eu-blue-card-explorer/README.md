# EU Blue Card Explorer

مقایسه اطلاعات Blue Card کشورهای مختلف

اطلاعات Blue Card کشورهای عضو را مرور و مقایسه کنید و حقوق پیشنهادی را با آستانه رسمی کشور مقصد بسنجید.

**نوع ابزار:** اکسپلورر + محاسبه‌گر · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- کارت‌ها با فیلتر و جست‌وجو
- مقایسه تا ۳ گزینه
- محاسبه‌گر مطابقت اولیه

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [EU Immigration Portal — EU Blue Card](https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal/eu-blue-card_en)
- [EU Immigration Portal (European Commission)](https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
