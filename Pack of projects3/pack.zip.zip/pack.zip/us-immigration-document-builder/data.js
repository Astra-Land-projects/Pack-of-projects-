window.APP = {
 "slug": "us-immigration-document-builder",
 "title": "US Immigration Document Builder",
 "subtitle": "ساخت چک‌لیست مدارک بر اساس نوع پرونده",
 "type": "checklist",
 "desc": "نوع پرونده را انتخاب کنید تا چک‌لیست مدارک معمول ساخته شود؛ پیشرفت ذخیره می‌شود و خروجی متنی/چاپی دارد. فهرست نهایی را همیشه با دستورالعمل همان فرم تطبیق دهید.",
 "sources": [
  {
   "t": "USCIS Forms",
   "u": "https://www.uscis.gov/forms/all-forms"
  },
  {
   "t": "USCIS Policy Manual — Translations (8 CFR 103.2(b)(3))",
   "u": "https://www.ecfr.gov/current/title-8/chapter-I/subchapter-B/part-103/subpart-A/section-103.2"
  },
  {
   "t": "USCIS Fee Schedule (G-1055)",
   "u": "https://www.uscis.gov/g-1055"
  }
 ],
 "code": "US",
 "country": "USA",
 "common": [
  "گذرنامه معتبر (صفحه مشخصات)",
  "عکس‌های پاسپورتی طبق مشخصات فرم",
  {
   "t": "ترجمه انگلیسی کامل با گواهی مترجم برای هر سند غیرانگلیسی",
   "note": "8 CFR 103.2(b)(3)"
  },
  "پرداخت هزینه طبق G-1055 یا Fee Calculator",
  "امضای فرم با جوهر یا الکترونیکی طبق دستورالعمل"
 ],
 "cases": {
  "i130": {
   "label": "I-130 — درخواست برای بستگان",
   "items": [
    "فرم I-130 (و I-130A برای همسر)",
    "مدرک شهروندی/گرین‌کارت درخواست‌کننده",
    "سند ازدواج یا شناسنامه برای اثبات نسبت",
    {
     "t": "مدرک انحلال ازدواج‌های قبلی",
     "opt": true
    },
    "شواهد ازدواج واقعی (اجاره‌نامه مشترک، حساب مشترک، عکس‌ها)"
   ],
   "source": {
    "t": "USCIS I-130",
    "u": "https://www.uscis.gov/i-130"
   }
  },
  "i485": {
   "label": "I-485 — تطبیق وضعیت",
   "items": [
    "فرم I-485",
    "I-693 معاینه پزشکی توسط civil surgeon",
    "I-864 تعهد حمایت مالی (در صورت الزام)",
    "شناسنامه",
    "I-94 و سابقه ورود قانونی",
    "رسید/تأیید پرونده پایه (I-797)",
    {
     "t": "I-765 و I-131 همزمان",
     "opt": true
    }
   ],
   "source": {
    "t": "USCIS I-485",
    "u": "https://www.uscis.gov/i-485"
   }
  },
  "i765": {
   "label": "I-765 — مجوز کار (EAD)",
   "items": [
    "فرم I-765",
    "EAD قبلی (در صورت وجود)",
    "مدرک مبنای واجد شرایط بودن (کد دسته)",
    "I-94"
   ],
   "source": {
    "t": "USCIS I-765",
    "u": "https://www.uscis.gov/i-765"
   }
  },
  "n400": {
   "label": "N-400 — شهروندی",
   "items": [
    "فرم N-400",
    "کپی دو طرف گرین‌کارت",
    {
     "t": "مدرک ازدواج با شهروند (مسیر ۳ ساله)",
     "opt": true
    },
    "سوابق سفرهای خارج از آمریکا",
    "سوابق مالیاتی در صورت نیاز"
   ],
   "source": {
    "t": "USCIS N-400",
    "u": "https://www.uscis.gov/n-400"
   }
  },
  "f1": {
   "label": "F-1 — مصاحبه دانشجویی",
   "items": [
    "فرم I-20 امضاشده",
    "رسید SEVIS I-901",
    "صفحه تأیید DS-160",
    "رسید MRV",
    "مدارک مالی پوشش هزینه‌ها",
    "پذیرش‌نامه و ریزنمرات",
    "نمره آزمون زبان/استاندارد"
   ],
   "source": {
    "t": "Study in the States (DHS/SEVP)",
    "u": "https://studyinthestates.dhs.gov/"
   }
  },
  "i140niw": {
   "label": "I-140 — EB-2 NIW",
   "items": [
    "فرم I-140",
    "نامه پوششی و proposed endeavor",
    "مدارک تحصیلی و ارزیابی معادل‌سازی",
    "نامه‌های توصیه مستقل",
    "شواهد استناد/انتشار/پروژه",
    "رزومه کامل"
   ],
   "source": {
    "t": "USCIS EB-2",
    "u": "https://www.uscis.gov/working-in-the-united-states/permanent-workers/employment-based-immigration-second-preference-eb-2"
   }
  },
  "i751": {
   "label": "I-751 — رفع شرط اقامت",
   "items": [
    "فرم I-751",
    "کپی گرین‌کارت مشروط",
    "شواهد ادامه زندگی مشترک",
    "مالیات مشترک، بیمه، حساب بانکی"
   ],
   "source": {
    "t": "USCIS I-751",
    "u": "https://www.uscis.gov/i-751"
   }
  }
 },
 "id": "astra-us-immigration-document-builder",
 "verified": "2026-10-01"
};
