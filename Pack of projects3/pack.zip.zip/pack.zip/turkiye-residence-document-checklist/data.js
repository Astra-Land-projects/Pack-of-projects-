window.APP = {
 "slug": "turkiye-residence-document-checklist",
 "title": "Türkiye Residence Document Checklist",
 "subtitle": "چک‌لیست مدارک اقامت ترکیه",
 "type": "checklist",
 "desc": "مدارک معمول هر نوع اقامت را تیک بزنید و خروجی بگیرید. فهرست رسمی هر نوع در goc.gov.tr منتشر می‌شود.",
 "sources": [
  {
   "t": "Residence Permit Types — goc.gov.tr",
   "u": "https://en.goc.gov.tr/residence-permits"
  },
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "common": [
  "فرم درخواست e-İkamet امضاشده",
  "اصل و کپی گذرنامه (صفحه مشخصات، ورود، ویزا)",
  "۴ عکس بیومتریک جدید",
  "رسید پرداخت هزینه کارت",
  {
   "t": "رسید هزینه مجوز اقامت",
   "opt": true
  },
  "اثبات آدرس (قرارداد اجاره محضری یا سند ملک)",
  "بیمه درمانی معتبر در طول اقامت"
 ],
 "cases": {
  "short": {
   "label": "Short-term",
   "items": [
    "اثبات توان مالی کافی (صورتحساب بانکی)",
    "مدرک هدف اقامت (مثلاً ثبت‌نام دوره زبان، سند ملک، دعوت‌نامه تجاری)"
   ],
   "source": {
    "t": "Residence Permit Types — goc.gov.tr",
    "u": "https://en.goc.gov.tr/residence-permits"
   }
  },
  "family": {
   "label": "Family",
   "items": [
    "سند ازدواج/تولد با آپوستیل و ترجمه رسمی ترکی",
    "کپی کارت اقامت یا هویت حامی",
    "مدرک درآمد حامی",
    {
     "t": "رضایت‌نامه والد دیگر برای فرزند",
     "opt": true
    }
   ],
   "source": {
    "t": "Residence Permit Types — goc.gov.tr",
    "u": "https://en.goc.gov.tr/residence-permits"
   }
  },
  "student": {
   "label": "Student",
   "items": [
    "Öğrenci Belgesi (گواهی دانشجویی با کد e-Devlet)",
    {
     "t": "بیمه درمانی دانشجویی/GSS",
     "opt": true
    }
   ],
   "source": {
    "t": "Residence Permit Types — goc.gov.tr",
    "u": "https://en.goc.gov.tr/residence-permits"
   }
  },
  "long": {
   "label": "Long-term",
   "items": [
    "سوابق اقامت ۸ ساله",
    "اثبات درآمد منظم",
    "گواهی عدم سوءپیشینه"
   ],
   "source": {
    "t": "Residence Permit Types — goc.gov.tr",
    "u": "https://en.goc.gov.tr/residence-permits"
   }
  },
  "renewal": {
   "label": "Extension (تمدید)",
   "items": [
    "کارت اقامت فعلی",
    "مدارک به‌روز هدف اقامت",
    "ثبت درخواست پیش از پایان اعتبار"
   ],
   "source": {
    "t": "e-İkamet — Residence Permit Online Application",
    "u": "https://e-ikamet.goc.gov.tr/"
   }
  }
 },
 "id": "astra-turkiye-residence-document-checklist",
 "verified": "2026-10-01"
};
