window.APP = {
 "slug": "france-document-manager",
 "title": "France Document Manager",
 "subtitle": "مدیریت امن اسناد مهاجرتی فرانسه",
 "type": "vault",
 "desc": "اسناد (titre de séjour، VLS-TS، attestation CAF، justificatif de domicile) را رمزگذاری‌شده ذخیره و انقضاها را پیگیری کنید.",
 "sources": [
  {
   "t": "ANEF — Administration numérique pour les étrangers en France",
   "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
  },
  {
   "t": "Service-Public.fr — Foreigners in France",
   "u": "https://www.service-public.fr/particuliers/vosdroits/N110"
  }
 ],
 "code": "FR",
 "country": "France",
 "vault": {
  "warnDays": 120,
  "categories": [
   "Passeport",
   "Visa/VLS-TS",
   "Titre de séjour",
   "Justificatif de domicile",
   "Acte de naissance/mariage",
   "Diplômes",
   "Contrat de travail",
   "Bulletins de salaire",
   "Impôts",
   "Other"
  ],
  "suggested": [
   {
    "t": "گذرنامه",
    "cat": "Passeport"
   },
   {
    "t": "VLS-TS / titre de séjour",
    "cat": "Titre de séjour"
   },
   {
    "t": "Justificatif de domicile کمتر از ۳ ماه",
    "cat": "Justificatif de domicile"
   },
   {
    "t": "Acte de naissance ترجمه رسمی",
    "cat": "Acte de naissance/mariage"
   },
   {
    "t": "Bulletins de salaire",
    "cat": "Bulletins de salaire"
   }
  ]
 },
 "id": "astra-france-document-manager",
 "verified": "2026-10-01"
};
