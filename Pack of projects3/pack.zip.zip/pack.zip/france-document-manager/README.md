# France Document Manager

مدیریت امن اسناد مهاجرتی فرانسه

اسناد (titre de séjour، VLS-TS، attestation CAF، justificatif de domicile) را رمزگذاری‌شده ذخیره و انقضاها را پیگیری کنید.

**نوع ابزار:** گاوصندوق رمزگذاری‌شده · **کشور/منطقه:** France · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- رمزگذاری AES-GCM 256 با PBKDF2 (Web Crypto)
- ذخیره در IndexedDB
- هشدار انقضا و خروجی ICS
- چک‌لیست مدارک پیشنهادی

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [ANEF — Administration numérique pour les étrangers en France](https://administration-etrangers-en-france.interieur.gouv.fr/)
- [Service-Public.fr — Foreigners in France](https://www.service-public.fr/particuliers/vosdroits/N110)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
