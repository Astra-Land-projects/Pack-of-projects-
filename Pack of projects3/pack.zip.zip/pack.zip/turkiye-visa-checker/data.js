window.APP = {
 "slug": "turkiye-visa-checker",
 "title": "Türkiye Visa Checker",
 "subtitle": "بررسی اولیه نیاز به ویزا بر اساس تابعیت و نوع سفر",
 "type": "navigator",
 "desc": "تابعیت، هدف و مدت سفر را انتخاب کنید تا مسیر ورود مرتبط (معافیت، e-Visa، ویزای کنسولی یا ویزای خاص + اقامت) نمایش داده شود. وضعیت کشور خود را همیشه در جدول وزارت خارجه تأیید کنید.",
 "sources": [
  {
   "t": "MFA Türkiye — Visa Information for Foreigners",
   "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
  },
  {
   "t": "Republic of Türkiye Electronic Visa Application System",
   "u": "https://www.evisa.gov.tr/"
  },
  {
   "t": "Konsolosluk (MFA consular portal)",
   "u": "https://www.konsolosluk.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "questions": [
  {
   "id": "nat",
   "q": "وضعیت تابعیت (طبق جدول MFA)",
   "options": [
    {
     "v": "exempt",
     "l": "کشور معاف از ویزا برای سفر کوتاه (مثلاً ایران تا ۹۰ روز)"
    },
    {
     "v": "evisa",
     "l": "کشور واجد e-Visa"
    },
    {
     "v": "cond",
     "l": "e-Visa مشروط (نیازمند ویزا/اقامت معتبر کشورهای مشخص)"
    },
    {
     "v": "sticker",
     "l": "نیازمند ویزای کنسولی"
    },
    {
     "v": "unknown",
     "l": "نمی‌دانم"
    }
   ]
  },
  {
   "id": "purpose",
   "q": "هدف",
   "options": [
    {
     "v": "tour",
     "l": "گردشگری/دیدار"
    },
    {
     "v": "biz",
     "l": "جلسه/کنفرانس تجاری"
    },
    {
     "v": "study",
     "l": "تحصیل"
    },
    {
     "v": "work",
     "l": "کار"
    },
    {
     "v": "live",
     "l": "زندگی/اقامت بلندمدت"
    }
   ]
  },
  {
   "id": "dur",
   "q": "مدت",
   "options": [
    {
     "v": "short",
     "l": "تا ۹۰ روز در ۱۸۰ روز"
    },
    {
     "v": "long",
     "l": "بیش از ۹۰ روز"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "ورود بدون ویزا",
   "desc": "اتباع کشورهای معاف برای سفر کوتاه با گذرنامه معتبر وارد می‌شوند؛ مدت مجاز بسته به تابعیت متفاوت است.",
   "when": {
    "nat": [
     "exempt"
    ],
    "purpose": [
     "tour",
     "biz"
    ],
    "dur": [
     "short"
    ]
   },
   "steps": [
    "بررسی مدت مجاز در جدول MFA",
    "گذرنامه با اعتبار کافی",
    "در صورت ماندن بیش از ۹۰ روز: اجازه اقامت"
   ],
   "sources": [
    {
     "t": "MFA Türkiye — Visa Information for Foreigners",
     "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
    }
   ]
  },
  {
   "name": "e-Visa",
   "desc": "ویزای الکترونیکی برای گردشگری/تجارت؛ فقط از evisa.gov.tr.",
   "when": {
    "nat": [
     "evisa",
     "cond"
    ],
    "purpose": [
     "tour",
     "biz"
    ],
    "dur": [
     "short"
    ]
   },
   "steps": [
    "بررسی شرایط کشور در evisa.gov.tr",
    "در e-Visa مشروط: داشتن ویزا یا اقامت معتبر شنگن/آمریکا/بریتانیا/ایرلند طبق شرایط",
    "پرداخت آنلاین و دانلود"
   ],
   "sources": [
    {
     "t": "Republic of Türkiye Electronic Visa Application System",
     "u": "https://www.evisa.gov.tr/"
    }
   ]
  },
  {
   "name": "ویزای کنسولی (Sticker)",
   "desc": "درخواست از نمایندگی ترکیه با نوبت از konsolosluk.gov.tr.",
   "when": {
    "nat": [
     "sticker",
     "unknown"
    ],
    "dur": [
     "short"
    ]
   },
   "steps": [
    "نوبت در konsolosluk.gov.tr",
    "فرم و مدارک",
    "مصاحبه/تحویل"
   ],
   "sources": [
    {
     "t": "Konsolosluk (MFA consular portal)",
     "u": "https://www.konsolosluk.gov.tr/"
    }
   ]
  },
  {
   "name": "ویزای تحصیلی + اقامت دانشجویی",
   "desc": "با پذیرش دانشگاه ویزای تحصیلی گرفته و پس از ورود اقامت دانشجویی از e-İkamet ثبت می‌شود.",
   "when": {
    "purpose": [
     "study"
    ]
   },
   "steps": [
    "پذیرش دانشگاه",
    "ویزای تحصیلی از نمایندگی",
    "ثبت‌نام دانشگاه و Öğrenci Belgesi",
    "اقامت دانشجویی در e-İkamet"
   ],
   "sources": [
    {
     "t": "Study in Türkiye",
     "u": "https://www.studyinturkiye.gov.tr/"
    },
    {
     "t": "e-İkamet — Residence Permit Online Application",
     "u": "https://e-ikamet.goc.gov.tr/"
    }
   ]
  },
  {
   "name": "ویزای کاری + مجوز کار",
   "desc": "کارفرما مجوز کار را از وزارت کار درخواست می‌کند؛ ویزای کاری از نمایندگی صادر می‌شود.",
   "when": {
    "purpose": [
     "work"
    ]
   },
   "steps": [
    "پیشنهاد کار",
    "درخواست ویزای کاری و ثبت مجوز توسط کارفرما در e-İzin",
    "ورود و دریافت کارت"
   ],
   "sources": [
    {
     "t": "Ministry of Labour — Work Permit for Foreigners (e-Izin)",
     "u": "https://www.csgb.gov.tr/uigm/"
    }
   ]
  },
  {
   "name": "اجازه اقامت (بیش از ۹۰ روز)",
   "desc": "برای ماندن طولانی‌تر باید پیش از پایان مدت مجاز ورود، اقامت مناسب از e-İkamet ثبت شود.",
   "when": {
    "dur": [
     "long"
    ],
    "purpose": [
     "tour",
     "live",
     "biz"
    ]
   },
   "steps": [
    "انتخاب نوع اقامت",
    "ثبت در e-İkamet",
    "حضور در اداره مهاجرت"
   ],
   "sources": [
    {
     "t": "e-İkamet — Residence Permit Online Application",
     "u": "https://e-ikamet.goc.gov.tr/"
    },
    {
     "t": "Residence Permit Types — goc.gov.tr",
     "u": "https://en.goc.gov.tr/residence-permits"
    }
   ]
  }
 ],
 "id": "astra-turkiye-visa-checker",
 "verified": "2026-10-01"
};
