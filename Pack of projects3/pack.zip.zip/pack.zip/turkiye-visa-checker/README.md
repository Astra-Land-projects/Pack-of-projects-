# Türkiye Visa Checker

بررسی اولیه نیاز به ویزا بر اساس تابعیت و نوع سفر

تابعیت، هدف و مدت سفر را انتخاب کنید تا مسیر ورود مرتبط (معافیت، e-Visa، ویزای کنسولی یا ویزای خاص + اقامت) نمایش داده شود. وضعیت کشور خود را همیشه در جدول وزارت خارجه تأیید کنید.

**نوع ابزار:** مسیریاب (rule-based matching) · **کشور/منطقه:** Türkiye · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- پرسش‌نامه پروفایل و امتیازدهی مسیرها
- نمایش موارد نامنطبق
- مراحل، مدارک و منابع رسمی هر مسیر
- خروجی گزارش متنی و چاپ

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [MFA Türkiye — Visa Information for Foreigners](https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa)
- [Republic of Türkiye Electronic Visa Application System](https://www.evisa.gov.tr/)
- [Konsolosluk (MFA consular portal)](https://www.konsolosluk.gov.tr/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
