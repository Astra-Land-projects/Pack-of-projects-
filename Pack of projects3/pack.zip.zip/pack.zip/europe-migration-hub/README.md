# Europe Migration Hub

مرکز ابزارهای اروپا

همه ابزارهای مستقل اروپا و هاب‌های کشوری.

**نوع ابزار:** هاب کشوری · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- لینک به ابزارهای مستقل کشور

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [EU Immigration Portal (European Commission)](https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en)
- [EURES — European Job Mobility Portal](https://eures.europa.eu/)
- [Your Europe](https://europa.eu/youreurope/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
