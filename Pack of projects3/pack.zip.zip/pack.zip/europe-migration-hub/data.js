window.APP = {
 "slug": "europe-migration-hub",
 "title": "Europe Migration Hub",
 "subtitle": "مرکز ابزارهای اروپا",
 "type": "hub",
 "desc": "همه ابزارهای مستقل اروپا و هاب‌های کشوری.",
 "sources": [
  {
   "t": "EU Immigration Portal (European Commission)",
   "u": "https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en"
  },
  {
   "t": "EURES — European Job Mobility Portal",
   "u": "https://eures.europa.eu/"
  },
  {
   "t": "Your Europe",
   "u": "https://europa.eu/youreurope/"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "intro": "ابزارهای اروپایی به EU Immigration Portal، EURES، Your Europe و پورتال‌های رسمی هر کشور متصل‌اند.",
 "links": [
  {
   "slug": "eu-migration-navigator",
   "title": "EU Migration Navigator",
   "desc": "مسیرها، مدارک، هزینه و منابع رسمی کشورهای اروپایی"
  },
  {
   "slug": "eu-blue-card-explorer",
   "title": "EU Blue Card Explorer",
   "desc": "مقایسه اطلاعات Blue Card کشورهای مختلف"
  },
  {
   "slug": "eu-immigration-country-compare",
   "title": "EU Immigration Country Compare",
   "desc": "مقایسه چند کشور اروپایی در یک داشبورد"
  },
  {
   "slug": "europe-work-mobility-ai",
   "title": "Europe Work Mobility AI",
   "desc": "پیدا کردن کشورها/بازارهای مرتبط با مهارت شما"
  },
  {
   "slug": "eures-job-matcher-ai",
   "title": "EURES Job Matcher AI",
   "desc": "تطبیق رزومه با مشاغل اروپایی"
  },
  {
   "slug": "europe-cv-converter",
   "title": "Europe CV Converter",
   "desc": "تبدیل رزومه به قالب‌های کشورهای مختلف"
  },
  {
   "slug": "eu-qualification-navigator",
   "title": "EU Qualification Navigator",
   "desc": "راهنمای شناسایی و معادل‌سازی مدارک"
  },
  {
   "slug": "europe-document-checklist",
   "title": "Europe Document Checklist",
   "desc": "مدارک موردنیاز بر اساس کشور و هدف"
  },
  {
   "slug": "eu-relocation-planner",
   "title": "EU Relocation Planner",
   "desc": "برنامه کامل relocation به اروپا"
  },
  {
   "slug": "europe-cost-of-living-map",
   "title": "Europe Cost of Living Map",
   "desc": "مقایسه هزینه زندگی شهرهای اروپا"
  },
  {
   "slug": "europe-student-route-finder",
   "title": "Europe Student Route Finder",
   "desc": "جست‌وجوی مسیرهای تحصیلی اروپا"
  },
  {
   "slug": "europe-scholarship-finder",
   "title": "Europe Scholarship Finder",
   "desc": "موتور جست‌وجوی بورسیه"
  },
  {
   "slug": "europe-job-mobility-dashboard",
   "title": "Europe Job Mobility Dashboard",
   "desc": "داشبورد فرصت‌های کاری و جابه‌جایی"
  },
  {
   "slug": "eu-cross-border-worker-assistant",
   "title": "EU Cross-Border Worker Assistant",
   "desc": "اطلاعات کار بین کشورهای مرزی"
  },
  {
   "slug": "europe-migration-deadline-manager",
   "title": "Europe Migration Deadline Manager",
   "desc": "مدیریت ددلاین‌های مهاجرت اروپا"
  },
  {
   "slug": "europe-immigration-source-tracker",
   "title": "Europe Immigration Source Tracker",
   "desc": "ذخیره و پایش منابع رسمی هر کشور"
  },
  {
   "slug": "germany-migration-hub",
   "title": "Germany Migration Hub",
   "desc": "مرکز ابزارهای آلمان"
  },
  {
   "slug": "france-migration-hub",
   "title": "France Migration Hub",
   "desc": "مرکز ابزارهای فرانسه"
  },
  {
   "slug": "italy-migration-hub",
   "title": "Italy Migration Hub",
   "desc": "مرکز ابزارهای ایتالیا"
  },
  {
   "slug": "spain-migration-hub",
   "title": "Spain Migration Hub",
   "desc": "مرکز ابزارهای اسپانیا"
  },
  {
   "slug": "netherlands-migration-hub",
   "title": "Netherlands Migration Hub",
   "desc": "مرکز ابزارهای هلند"
  }
 ],
 "id": "astra-europe-migration-hub",
 "verified": "2026-10-01"
};
