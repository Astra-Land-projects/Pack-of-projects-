window.APP = {
 "slug": "us-case-document-vault",
 "title": "US Case Document Vault",
 "subtitle": "مدیریت امن اسناد، تاریخ انقضا و چک‌لیست",
 "type": "vault",
 "desc": "اسناد پرونده را با رمزگذاری AES-256 داخل مرورگر ذخیره کنید، تاریخ انقضای گذرنامه/ویزا/EAD را پیگیری و تقویم یادآوری بسازید.",
 "sources": [
  {
   "t": "USCIS Online Account",
   "u": "https://my.uscis.gov/"
  },
  {
   "t": "I-94 Official Website (CBP)",
   "u": "https://i94.cbp.dhs.gov/"
  }
 ],
 "code": "US",
 "country": "USA",
 "vault": {
  "warnDays": 180,
  "categories": [
   "Passport",
   "Visa",
   "I-94",
   "I-797 Notice",
   "EAD",
   "Green Card",
   "Birth/Marriage",
   "Education",
   "Employment",
   "Financial/Tax",
   "Medical (I-693)",
   "Other"
  ],
  "suggested": [
   {
    "t": "گذرنامه (حداقل ۶ ماه اعتبار)",
    "cat": "Passport"
   },
   {
    "t": "I-797 همه پرونده‌ها",
    "cat": "I-797 Notice"
   },
   {
    "t": "آخرین I-94",
    "cat": "I-94"
   },
   {
    "t": "EAD / Green Card",
    "cat": "EAD"
   },
   {
    "t": "شناسنامه/سند ازدواج + ترجمه",
    "cat": "Birth/Marriage"
   },
   {
    "t": "مدارک تحصیلی و ارزیابی",
    "cat": "Education"
   },
   {
    "t": "نامه کارفرما / فیش‌ها",
    "cat": "Employment"
   },
   {
    "t": "W-2 و اظهارنامه مالیاتی",
    "cat": "Financial/Tax"
   }
  ]
 },
 "id": "astra-us-case-document-vault",
 "verified": "2026-10-01"
};
