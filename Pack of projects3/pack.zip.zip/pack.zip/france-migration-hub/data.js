window.APP = {
 "slug": "france-migration-hub",
 "title": "France Migration Hub",
 "subtitle": "مرکز ابزارهای فرانسه",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "France-Visas (official visa website)",
   "u": "https://france-visas.gouv.fr/"
  },
  {
   "t": "Welcome to France",
   "u": "https://www.welcometofrance.com/en"
  },
  {
   "t": "ANEF — Administration numérique pour les étrangers en France",
   "u": "https://administration-etrangers-en-france.interieur.gouv.fr/"
  }
 ],
 "code": "FR",
 "country": "France",
 "intro": "ابزارهای فرانسه به France-Visas، Welcome to France، Campus France و ANEF متصل‌اند.",
 "links": [
  {
   "slug": "france-student-route",
   "title": "France Student Route",
   "desc": "مسیر تحصیل در فرانسه (Études en France)"
  },
  {
   "slug": "france-work-route-explorer",
   "title": "France Work Route Explorer",
   "desc": "بررسی مسیرهای کاری فرانسه"
  },
  {
   "slug": "france-document-manager",
   "title": "France Document Manager",
   "desc": "مدیریت امن اسناد مهاجرتی فرانسه"
  },
  {
   "slug": "france-cv-matcher",
   "title": "France CV Matcher",
   "desc": "تطبیق رزومه با آگهی‌های فرانسه"
  },
  {
   "slug": "france-relocation-planner",
   "title": "France Relocation Planner",
   "desc": "برنامه انتقال به فرانسه"
  },
  {
   "slug": "france-cost-of-living-tool",
   "title": "France Cost of Living Tool",
   "desc": "مقایسه هزینه زندگی شهرهای فرانسه"
  }
 ],
 "id": "astra-france-migration-hub",
 "verified": "2026-10-01"
};
