"""Astra Global Migration — optional API (FastAPI).
Serves the project catalog, an aggregated index of official sources, and a
server-side official-source change monitor backed by SQLite (or PostgreSQL via
DATABASE_URL). The static tools work without this service.

Run:  pip install -r requirements.txt && uvicorn app:app --reload --port 8000
"""
import hashlib, json, os, re, html, sqlite3
from datetime import datetime, timezone
from pathlib import Path
import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent.parent
CATALOG = json.loads((ROOT / "catalog.json").read_text(encoding="utf-8"))
DB = os.environ.get("ASTRA_DB", str(Path(__file__).parent / "astra.db"))

app = FastAPI(title="Astra Global Migration API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"], allow_headers=["*"])

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("create table if not exists snapshots(url text primary key, hash text, checked text, status int)")
    c.execute("create table if not exists changes(id integer primary key autoincrement, url text, detected text)")
    return c

def sources():
    seen = {}
    for p in CATALOG:
        for s in p["sources"]:
            seen.setdefault(s["u"], {"title": s["t"], "url": s["u"], "projects": []})["projects"].append(p["slug"])
    return list(seen.values())

def clean(raw):
    raw = re.sub(r"(?is)<(script|style|noscript|svg|nav|footer)[^>]*>.*?</\1>", " ", raw)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"(?s)<[^>]+>", " ", raw))).strip()

@app.get("/api/health")
def health(): return {"ok": True, "projects": len(CATALOG)}

@app.get("/api/projects")
def projects(country: str | None = None, q: str | None = None):
    r = CATALOG
    if country: r = [p for p in r if p["country"].lower() == country.lower()]
    if q: r = [p for p in r if q.lower() in (p["title"] + p["desc"]).lower()]
    return r

@app.get("/api/projects/{slug}")
def project(slug: str):
    for p in CATALOG:
        if p["slug"] == slug: return p
    raise HTTPException(404, "not found")

@app.get("/api/sources")
def list_sources(): return sources()

@app.post("/api/monitor/run")
async def run_monitor(limit: int = Query(50, le=300)):
    c = db(); now = datetime.now(timezone.utc).isoformat(timespec="seconds"); out = []
    async with httpx.AsyncClient(timeout=25, follow_redirects=True, headers={"User-Agent": "Mozilla/5.0 AstraMonitor"}) as cli:
        for s in sources()[:limit]:
            try:
                r = await cli.get(s["url"]); h = hashlib.sha256(clean(r.text).encode()).hexdigest(); st = r.status_code
            except Exception:
                h, st = None, 0
            prev = c.execute("select hash from snapshots where url=?", (s["url"],)).fetchone()
            changed = bool(h and prev and prev["hash"] != h)
            if h: c.execute("insert or replace into snapshots values(?,?,?,?)", (s["url"], h, now, st))
            if changed: c.execute("insert into changes(url, detected) values(?,?)", (s["url"], now))
            out.append({"url": s["url"], "title": s["title"], "status": st, "changed": changed})
    c.commit()
    return {"generated": now, "results": out}

@app.get("/api/monitor/changes")
def changes(): return [dict(r) for r in db().execute("select * from changes order by id desc limit 200")]

# Serve the static portfolio (lobby + all tools) from the same origin
app.mount("/", StaticFiles(directory=str(ROOT), html=True), name="static")
