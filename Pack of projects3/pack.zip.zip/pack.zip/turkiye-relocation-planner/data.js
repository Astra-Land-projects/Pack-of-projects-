window.APP = {
 "slug": "turkiye-relocation-planner",
 "title": "Türkiye Relocation Planner",
 "subtitle": "برنامه انتقال به ترکیه",
 "type": "planner",
 "desc": "تاریخ مهاجرت را وارد کنید تا کارهای قبل و بعد از ورود (اقامت، کد مالیاتی، بانک، مسکن، تلفن، بیمه) زمان‌بندی شوند.",
 "sources": [
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  },
  {
   "t": "e-Devlet (turkiye.gov.tr)",
   "u": "https://www.turkiye.gov.tr/"
  },
  {
   "t": "Gelir İdaresi (tax office) — Foreigners tax ID",
   "u": "https://ivd.gib.gov.tr/"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "plan": {
  "targetLabel": "تاریخ ورود به ترکیه",
  "phases": [
   {
    "name": "۳ ماه قبل",
    "off": -90,
    "tasks": [
     "انتخاب شهر و نوع اقامت",
     {
      "t": "بررسی نیاز به ویزا",
      "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
     },
     "آپوستیل و ترجمه اسناد ازدواج/تولد/تحصیل"
    ]
   },
   {
    "name": "۱ ماه قبل",
    "off": -30,
    "tasks": [
     "رزرو اقامت موقت",
     "بیمه درمانی که برای اقامت پذیرفته شود",
     "تهیه ارز و کارت بین‌المللی"
    ]
   },
   {
    "name": "هفته اول",
    "off": 3,
    "tasks": [
     {
      "t": "دریافت شماره مالیاتی (Vergi Numarası)",
      "u": "https://ivd.gib.gov.tr/"
     },
     "خط تلفن و ثبت IMEI در صورت نیاز",
     "افتتاح حساب بانکی"
    ]
   },
   {
    "name": "ماه اول",
    "off": 20,
    "tasks": [
     "قرارداد اجاره محضری",
     {
      "t": "ثبت درخواست اقامت در e-İkamet پیش از پایان مدت مجاز ورود",
      "u": "https://e-ikamet.goc.gov.tr/"
     },
     "ثبت آدرس"
    ]
   },
   {
    "name": "پس از دریافت کارت",
    "off": 90,
    "tasks": [
     {
      "t": "فعال‌سازی e-Devlet",
      "u": "https://www.turkiye.gov.tr/"
     },
     "ثبت‌نام مدرسه فرزندان",
     "یادآوری تمدید (ابزار Renewal Reminder)"
    ]
   }
  ]
 },
 "id": "astra-turkiye-relocation-planner",
 "verified": "2026-10-01"
};
