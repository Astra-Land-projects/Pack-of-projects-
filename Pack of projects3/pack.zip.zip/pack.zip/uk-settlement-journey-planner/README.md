# UK Settlement Journey Planner

مراحل و ددلاین‌های مسیر اقامت دائم (ILR) و شهروندی

مسیر خود را انتخاب کنید تا مراحل تا ILR و شهروندی با تاریخ زمان‌بندی شود. دولت بریتانیا تغییر مسیر settlement (earned settlement) را مطرح کرده است؛ قوانین جاری را بررسی کنید.

**نوع ابزار:** تایم‌لاین مسیر · **کشور/منطقه:** UK · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- چند مسیر آماده
- مدت هر مرحله قابل ویرایش
- نمودار گانت SVG
- تیک انجام و خروجی ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [GOV.UK — Indefinite leave to remain](https://www.gov.uk/indefinite-leave-to-remain)
- [GOV.UK — Become a British citizen](https://www.gov.uk/becoming-a-british-citizen)
- [GOV.UK — Life in the UK Test](https://www.gov.uk/life-in-the-uk-test)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
