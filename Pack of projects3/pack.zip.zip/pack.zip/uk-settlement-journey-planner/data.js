window.APP = {
 "slug": "uk-settlement-journey-planner",
 "title": "UK Settlement Journey Planner",
 "subtitle": "مراحل و ددلاین‌های مسیر اقامت دائم (ILR) و شهروندی",
 "type": "timeline",
 "desc": "مسیر خود را انتخاب کنید تا مراحل تا ILR و شهروندی با تاریخ زمان‌بندی شود. دولت بریتانیا تغییر مسیر settlement (earned settlement) را مطرح کرده است؛ قوانین جاری را بررسی کنید.",
 "sources": [
  {
   "t": "GOV.UK — Indefinite leave to remain",
   "u": "https://www.gov.uk/indefinite-leave-to-remain"
  },
  {
   "t": "GOV.UK — Become a British citizen",
   "u": "https://www.gov.uk/becoming-a-british-citizen"
  },
  {
   "t": "GOV.UK — Life in the UK Test",
   "u": "https://www.gov.uk/life-in-the-uk-test"
  }
 ],
 "code": "UK",
 "country": "UK",
 "routes": {
  "sw": {
   "label": "Skilled Worker → ILR → شهروندی",
   "steps": [
    {
     "t": "ویزای Skilled Worker",
     "days": 60,
     "u": "https://www.gov.uk/skilled-worker-visa"
    },
    {
     "t": "اقامت پیوسته واجد شرایط (قانون فعلی: ۵ سال؛ پیشنهاد «earned settlement» تا ۱۰ سال را دنبال کنید)",
     "days": 1825,
     "u": "https://www.gov.uk/indefinite-leave-to-remain"
    },
    {
     "t": "آزمون Life in the UK و درخواست ILR",
     "days": 90,
     "u": "https://www.gov.uk/life-in-the-uk-test"
    },
    {
     "t": "۱۲ ماه با ILR",
     "days": 365
    },
    {
     "t": "درخواست شهروندی",
     "days": 180,
     "u": "https://www.gov.uk/becoming-a-british-citizen"
    }
   ]
  },
  "gt": {
   "label": "Global Talent → ILR",
   "steps": [
    {
     "t": "Endorsement",
     "days": 60
    },
    {
     "t": "ویزا",
     "days": 30
    },
    {
     "t": "۳ سال (برخی زیرشاخه‌ها) یا ۵ سال",
     "days": 1095,
     "u": "https://www.gov.uk/global-talent"
    },
    {
     "t": "ILR",
     "days": 90
    }
   ]
  },
  "fam": {
   "label": "Partner → ILR",
   "steps": [
    {
     "t": "Partner visa",
     "days": 90,
     "u": "https://www.gov.uk/uk-family-visa"
    },
    {
     "t": "۵ سال (دو دوره ۳۰ + ۳۰ ماه)",
     "days": 1825
    },
    {
     "t": "ILR",
     "days": 180
    }
   ]
  },
  "st": {
   "label": "Student → Graduate → Skilled Worker",
   "steps": [
    {
     "t": "Student visa",
     "days": 45
    },
    {
     "t": "دوره ارشد",
     "days": 365
    },
    {
     "t": "Graduate visa (مدت را از GOV.UK بررسی کنید)",
     "days": 540,
     "u": "https://www.gov.uk/graduate-visa"
    },
    {
     "t": "تغییر به Skilled Worker",
     "days": 60,
     "u": "https://www.gov.uk/skilled-worker-visa"
    },
    {
     "t": "مسیر Skilled Worker تا ILR",
     "days": 1825
    }
   ]
  }
 },
 "id": "astra-uk-settlement-journey-planner",
 "verified": "2026-10-01"
};
