# Europe Scholarship Finder

موتور جست‌وجوی بورسیه

بورسیه‌های رسمی اروپا (و چند برنامه بین‌المللی مرتبط) را بر اساس کشور، مقطع و نوع حمایت فیلتر، نشان‌گذاری و ددلاین شخصی را به تقویم اضافه کنید.

**نوع ابزار:** جست‌وجوی بورسیه · **کشور/منطقه:** Europe · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- فیلتر کشور/مقطع/نوع حمایت
- نشان‌گذاری
- ددلاین شخصی و خروجی ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Erasmus Mundus Joint Masters catalogue](https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en)
- [DAAD Scholarship Database](https://www2.daad.de/deutschland/stipendium/datenbank/en/21148-scholarship-database/)
- [Study in Europe (European Commission)](https://education.ec.europa.eu/study-in-europe)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
