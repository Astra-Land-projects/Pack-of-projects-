window.APP = {
 "slug": "europe-scholarship-finder",
 "title": "Europe Scholarship Finder",
 "subtitle": "موتور جست‌وجوی بورسیه",
 "type": "scholarships",
 "desc": "بورسیه‌های رسمی اروپا (و چند برنامه بین‌المللی مرتبط) را بر اساس کشور، مقطع و نوع حمایت فیلتر، نشان‌گذاری و ددلاین شخصی را به تقویم اضافه کنید.",
 "sources": [
  {
   "t": "Erasmus Mundus Joint Masters catalogue",
   "u": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en"
  },
  {
   "t": "DAAD Scholarship Database",
   "u": "https://www2.daad.de/deutschland/stipendium/datenbank/en/21148-scholarship-database/"
  },
  {
   "t": "Study in Europe (European Commission)",
   "u": "https://education.ec.europa.eu/study-in-europe"
  }
 ],
 "code": "EU",
 "country": "Europe",
 "items": [
  {
   "n": "Erasmus Mundus Joint Masters",
   "country": "EU (multi)",
   "level": [
    "Master"
   ],
   "funding": "full",
   "who": "دانشجویان سراسر جهان؛ برنامه‌های مشترک چند دانشگاه اروپایی",
   "url": "https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en",
   "months": "اکتبر تا ژانویه (بسته به برنامه)"
  },
  {
   "n": "DAAD Scholarships",
   "country": "Germany",
   "level": [
    "Master",
    "PhD",
    "Research"
   ],
   "funding": "full",
   "who": "پایگاه‌داده بورسیه‌های DAAD برای فارغ‌التحصیلان و پژوهشگران",
   "url": "https://www2.daad.de/deutschland/stipendium/datenbank/en/21148-scholarship-database/",
   "months": "متغیر"
  },
  {
   "n": "Deutschlandstipendium",
   "country": "Germany",
   "level": [
    "Bachelor",
    "Master"
   ],
   "funding": "partial",
   "who": "دانشجویان ممتاز دانشگاه‌های آلمان",
   "url": "https://www.deutschlandstipendium.de/deutschlandstipendium/en/",
   "months": "از طریق دانشگاه"
  },
  {
   "n": "Eiffel Excellence Scholarship",
   "country": "France",
   "level": [
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "دانشجویان بین‌المللی معرفی‌شده توسط مؤسسات فرانسوی",
   "url": "https://www.campusfrance.org/en/eiffel-scholarship-program-of-excellence",
   "months": "پاییز (از طریق دانشگاه)"
  },
  {
   "n": "Campus France scholarship search (Campus Bourses)",
   "country": "France",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "partial",
   "who": "پایگاه جست‌وجوی بورسیه‌های فرانسه",
   "url": "https://campusbourses.campusfrance.org/",
   "months": "متغیر"
  },
  {
   "n": "MAECI / Invest Your Talent in Italy",
   "country": "Italy",
   "level": [
    "Master",
    "PhD",
    "Research"
   ],
   "funding": "full",
   "who": "بورسیه دولت ایتالیا برای دانشجویان خارجی",
   "url": "https://studyinitaly.esteri.it/",
   "months": "معمولاً بهار"
  },
  {
   "n": "Regional DSU scholarships (e.g. ER.GO)",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "partial",
   "who": "بر اساس درآمد خانوار (ISEE) برای دانشجویان دانشگاه‌های ایتالیا",
   "url": "https://www.er-go.it/",
   "months": "تابستان"
  },
  {
   "n": "NL Scholarship",
   "country": "Netherlands",
   "level": [
    "Bachelor",
    "Master"
   ],
   "funding": "partial",
   "who": "دانشجویان غیر EEA در دانشگاه‌های شرکت‌کننده هلند",
   "url": "https://www.studyinnl.org/finances/nl-scholarship",
   "months": "فوریه تا مه"
  },
  {
   "n": "Swedish Institute Scholarships for Global Professionals",
   "country": "Sweden",
   "level": [
    "Master"
   ],
   "funding": "full",
   "who": "متخصصان کشورهای واجد شرایط با سابقه کار و رهبری",
   "url": "https://si.se/en/apply/scholarships/swedish-institute-scholarships-for-global-professionals/",
   "months": "فوریه تا مارس"
  },
  {
   "n": "Finland — university scholarships",
   "country": "Finland",
   "level": [
    "Bachelor",
    "Master"
   ],
   "funding": "partial",
   "who": "بورسیه‌های شهریه دانشگاه‌های فنلاند برای غیر EU",
   "url": "https://www.studyinfinland.fi/scholarships",
   "months": "همراه با اپلای"
  },
  {
   "n": "OeAD scholarships (Austria)",
   "country": "Austria",
   "level": [
    "Master",
    "PhD",
    "Research"
   ],
   "funding": "partial",
   "who": "پایگاه بورسیه‌های اتریش",
   "url": "https://grants.at/en/",
   "months": "متغیر"
  },
  {
   "n": "Fundación Carolina",
   "country": "Spain",
   "level": [
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "عمدتاً برای اتباع کشورهای آمریکای لاتین",
   "url": "https://www.fundacioncarolina.es/",
   "months": "زمستان-بهار"
  },
  {
   "n": "Stipendium Hungaricum",
   "country": "Hungary",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "دانشجویان کشورهای شریک (از جمله ایران در دوره‌هایی)",
   "url": "https://stipendiumhungaricum.hu/",
   "months": "نوامبر تا ژانویه"
  },
  {
   "n": "Chevening",
   "country": "UK",
   "level": [
    "Master"
   ],
   "funding": "full",
   "who": "رهبران آینده از کشورهای واجد شرایط؛ ارشد یک ساله",
   "url": "https://www.chevening.org/",
   "months": "اوت تا نوامبر"
  },
  {
   "n": "Commonwealth Scholarships",
   "country": "UK",
   "level": [
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "اتباع کشورهای مشترک‌المنافع",
   "url": "https://cscuk.fcdo.gov.uk/",
   "months": "پاییز"
  },
  {
   "n": "GREAT Scholarships",
   "country": "UK",
   "level": [
    "Master"
   ],
   "funding": "partial",
   "who": "کشورهای مشخص؛ از طریق دانشگاه‌های بریتانیا",
   "url": "https://study-uk.britishcouncil.org/scholarships-funding/great-scholarships",
   "months": "متغیر"
  },
  {
   "n": "Fulbright Foreign Student Program",
   "country": "USA",
   "level": [
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "از طریق کمیسیون/سفارت آمریکا در کشور متقاضی",
   "url": "https://foreign.fulbrightonline.org/",
   "months": "متغیر بر اساس کشور"
  },
  {
   "n": "Türkiye Bursları",
   "country": "Türkiye",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "full",
   "who": "دانشجویان بین‌المللی همه کشورها",
   "url": "https://www.turkiyeburslari.gov.tr/",
   "months": "ژانویه تا فوریه"
  }
 ],
 "id": "astra-europe-scholarship-finder",
 "verified": "2026-10-01"
};
