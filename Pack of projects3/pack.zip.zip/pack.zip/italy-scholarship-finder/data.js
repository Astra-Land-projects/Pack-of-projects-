window.APP = {
 "slug": "italy-scholarship-finder",
 "title": "Italy Scholarship Finder",
 "subtitle": "موتور جست‌وجوی بورسیه ایتالیا",
 "type": "scholarships",
 "desc": "بورسیه‌های دولتی، منطقه‌ای و دانشگاهی ایتالیا.",
 "sources": [
  {
   "t": "Study in Italy (MAECI)",
   "u": "https://studyinitaly.esteri.it/"
  },
  {
   "t": "Invest Your Talent / MAECI Scholarships",
   "u": "https://studyinitaly.esteri.it/"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "items": [
  {
   "n": "MAECI / Invest Your Talent in Italy",
   "country": "Italy",
   "level": [
    "Master",
    "PhD",
    "Research"
   ],
   "funding": "full",
   "who": "بورسیه دولت ایتالیا برای دانشجویان خارجی",
   "url": "https://studyinitaly.esteri.it/",
   "months": "معمولاً بهار"
  },
  {
   "n": "Regional DSU scholarships (e.g. ER.GO)",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "partial",
   "who": "بر اساس درآمد خانوار (ISEE) برای دانشجویان دانشگاه‌های ایتالیا",
   "url": "https://www.er-go.it/",
   "months": "تابستان"
  },
  {
   "n": "DiSCo Lazio",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "partial",
   "who": "دانشجویان دانشگاه‌های منطقه لاتسیو (رم) بر اساس درآمد",
   "url": "https://www.laziodisco.it/",
   "months": "تابستان"
  },
  {
   "n": "EDISU Piemonte",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master",
    "PhD"
   ],
   "funding": "partial",
   "who": "دانشجویان تورین و پیه‌مونته",
   "url": "https://www.edisu.piemonte.it/",
   "months": "تابستان"
  },
  {
   "n": "ESU Padova",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master"
   ],
   "funding": "partial",
   "who": "دانشجویان دانشگاه پادوا (منطقه ونتو)",
   "url": "https://www.esu.pd.it/",
   "months": "تابستان"
  },
  {
   "n": "Politecnico di Milano — Merit scholarships",
   "country": "Italy",
   "level": [
    "Master"
   ],
   "funding": "partial",
   "who": "دانشجویان بین‌المللی ارشد بر اساس رتبه",
   "url": "https://www.polimi.it/en/",
   "months": "همراه اپلای"
  },
  {
   "n": "Bocconi — International scholarships",
   "country": "Italy",
   "level": [
    "Bachelor",
    "Master"
   ],
   "funding": "partial",
   "who": "دانشجویان بین‌المللی ممتاز",
   "url": "https://www.unibocconi.it/en",
   "months": "همراه اپلای"
  }
 ],
 "id": "astra-italy-scholarship-finder",
 "verified": "2026-10-01"
};
