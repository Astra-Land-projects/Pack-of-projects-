window.APP = {
 "slug": "uk-visa-navigator",
 "title": "UK Visa Navigator",
 "subtitle": "پیدا کردن مسیر ویزای بریتانیا",
 "type": "navigator",
 "desc": "پاسخ دهید تا مسیرهای مرتبط ویزای UK رتبه‌بندی شوند؛ سپس با ابزار رسمی Check if you need a UK visa تأیید کنید.",
 "sources": [
  {
   "t": "GOV.UK — Check if you need a UK visa",
   "u": "https://www.gov.uk/check-uk-visa"
  },
  {
   "t": "GOV.UK — Visas and immigration",
   "u": "https://www.gov.uk/browse/visas-immigration"
  }
 ],
 "code": "UK",
 "country": "UK",
 "questions": [
  {
   "id": "goal",
   "q": "هدف",
   "options": [
    {
     "v": "visit",
     "l": "بازدید/تجاری کوتاه"
    },
    {
     "v": "study",
     "l": "تحصیل"
    },
    {
     "v": "work",
     "l": "کار"
    },
    {
     "v": "family",
     "l": "خانواده"
    },
    {
     "v": "talent",
     "l": "استعداد/پژوهش"
    },
    {
     "v": "grad",
     "l": "پس از تحصیل در UK"
    }
   ]
  },
  {
   "id": "offer",
   "q": "پیشنهاد کار از sponsor دارای مجوز",
   "options": [
    {
     "v": "yes",
     "l": "دارم"
    },
    {
     "v": "no",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "edu",
   "q": "تحصیلات",
   "options": [
    {
     "v": "top",
     "l": "فارغ‌التحصیل دانشگاه‌های برتر جهان (۵ سال اخیر)"
    },
    {
     "v": "deg",
     "l": "مدرک دانشگاهی"
    },
    {
     "v": "none",
     "l": "بدون مدرک دانشگاهی"
    }
   ]
  },
  {
   "id": "rel",
   "q": "خانواده در UK",
   "options": [
    {
     "v": "partner",
     "l": "همسر/شریک شهروند یا settled"
    },
    {
     "v": "none",
     "l": "ندارم"
    }
   ]
  },
  {
   "id": "eta",
   "q": "تابعیت نیازمند ویزای Visitor؟",
   "options": [
    {
     "v": "eta",
     "l": "خیر — نیاز به ETA"
    },
    {
     "v": "visa",
     "l": "بله — ویزای Visitor لازم است"
    }
   ]
  }
 ],
 "routes": [
  {
   "name": "Electronic Travel Authorisation (ETA)",
   "desc": "برای اتباع غیرنیازمند ویزا در سفر کوتاه.",
   "when": {
    "goal": [
     "visit"
    ],
    "eta": [
     "eta"
    ]
   },
   "steps": [
    "درخواست ETA در اپ یا GOV.UK",
    "سفر"
   ],
   "sources": [
    {
     "t": "GOV.UK — Electronic Travel Authorisation (ETA)",
     "u": "https://www.gov.uk/guidance/apply-for-an-electronic-travel-authorisation-eta"
    }
   ]
  },
  {
   "name": "Standard Visitor visa",
   "desc": "گردشگری، دیدار، جلسات کاری تا ۶ ماه.",
   "when": {
    "goal": [
     "visit"
    ],
    "eta": [
     "visa"
    ]
   },
   "steps": [
    "درخواست آنلاین",
    "بیومتریک در VAC",
    "تصمیم"
   ],
   "docs": [
    "گذرنامه",
    "مدارک مالی",
    "برنامه سفر"
   ],
   "sources": [
    {
     "t": "GOV.UK — Standard Visitor visa",
     "u": "https://www.gov.uk/standard-visitor"
    }
   ],
   "timeline": [
    {
     "t": "درخواست و بیومتریک",
     "days": 14
    },
    {
     "t": "تصمیم (هدف استاندارد)",
     "days": 21
    }
   ]
  },
  {
   "name": "Student visa",
   "desc": "تحصیل در student sponsor دارای مجوز با CAS، مدرک زبان و اثبات مالی.",
   "when": {
    "goal": [
     "study"
    ]
   },
   "steps": [
    "پذیرش و CAS",
    "اثبات مالی (۲۸ روز)",
    "درخواست و IHS",
    "بیومتریک",
    "سفر و eVisa"
   ],
   "docs": [
    "CAS",
    "گذرنامه",
    "مدارک مالی",
    "نتیجه ATAS در صورت نیاز",
    "تست TB (برخی کشورها)"
   ],
   "sources": [
    {
     "t": "GOV.UK — Student visa",
     "u": "https://www.gov.uk/student-visa"
    },
    {
     "t": "GOV.UK — Immigration Health Surcharge",
     "u": "https://www.gov.uk/healthcare-immigration-application"
    },
    {
     "t": "GOV.UK — Tuberculosis tests for visa applicants",
     "u": "https://www.gov.uk/tb-test-visa"
    }
   ],
   "timeline": [
    {
     "t": "CAS",
     "days": 30
    },
    {
     "t": "درخواست و بیومتریک",
     "days": 14
    },
    {
     "t": "تصمیم",
     "days": 21
    }
   ],
   "costs": [
    {
     "t": "Student visa fee",
     "u": "https://www.gov.uk/government/publications/visa-regulations-revised-table"
    },
    {
     "t": "IHS",
     "u": "https://www.gov.uk/healthcare-immigration-application"
    }
   ]
  },
  {
   "name": "Skilled Worker visa",
   "desc": "شغل واجد شرایط با sponsor دارای مجوز و حقوق بالاتر از آستانه (عمومی ۴۱٬۷۰۰ پوند یا نرخ شغل؛ استثنائات کاهش‌یافته).",
   "when": {
    "goal": [
     "work"
    ],
    "offer": [
     "yes"
    ]
   },
   "steps": [
    "CoS از کارفرما",
    "مدرک انگلیسی",
    "درخواست + IHS",
    "بیومتریک",
    "eVisa"
   ],
   "docs": [
    "CoS",
    "گذرنامه",
    "مدرک زبان",
    "تست TB در صورت نیاز",
    "گواهی سوءپیشینه برای برخی مشاغل"
   ],
   "sources": [
    {
     "t": "GOV.UK — Skilled Worker visa",
     "u": "https://www.gov.uk/skilled-worker-visa"
    },
    {
     "t": "GOV.UK — Register of licensed sponsors: workers",
     "u": "https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers"
    },
    {
     "t": "GOV.UK — Skilled Worker eligible occupations",
     "u": "https://www.gov.uk/government/publications/skilled-worker-visa-eligible-occupations"
    }
   ],
   "timeline": [
    {
     "t": "CoS",
     "days": 14
    },
    {
     "t": "درخواست و بیومتریک",
     "days": 14
    },
    {
     "t": "تصمیم",
     "days": 21
    },
    {
     "t": "سفر",
     "days": 14
    }
   ],
   "costs": [
    {
     "t": "Skilled Worker fee",
     "u": "https://www.gov.uk/government/publications/visa-regulations-revised-table"
    },
    {
     "t": "IHS",
     "u": "https://www.gov.uk/healthcare-immigration-application"
    }
   ]
  },
  {
   "name": "Global Talent",
   "desc": "رهبران/رهبران آینده در علوم، مهندسی، دیجیتال، هنر و پژوهش با endorsement یا جایزه معتبر؛ بدون نیاز به پیشنهاد کار.",
   "when": {
    "goal": [
     "talent",
     "work"
    ]
   },
   "steps": [
    "Endorsement از نهاد تأییدکننده (یا جایزه واجد شرایط)",
    "درخواست ویزا"
   ],
   "sources": [
    {
     "t": "GOV.UK — Global Talent visa",
     "u": "https://www.gov.uk/global-talent"
    }
   ]
  },
  {
   "name": "High Potential Individual",
   "desc": "فارغ‌التحصیلان دانشگاه‌های فهرست‌شده جهانی در ۵ سال اخیر؛ بدون sponsor.",
   "when": {
    "edu": [
     "top"
    ],
    "goal": [
     "work",
     "grad"
    ]
   },
   "sources": [
    {
     "t": "GOV.UK — High Potential Individual visa",
     "u": "https://www.gov.uk/high-potential-individual-visa"
    }
   ]
  },
  {
   "name": "Graduate visa",
   "desc": "پس از تکمیل مدرک در UK با Student visa؛ کار بدون sponsor برای مدت محدود.",
   "when": {
    "goal": [
     "grad"
    ]
   },
   "sources": [
    {
     "t": "GOV.UK — Graduate visa",
     "u": "https://www.gov.uk/graduate-visa"
    }
   ]
  },
  {
   "name": "Family visa (Partner)",
   "desc": "همسر/شریک شهروند بریتانیا یا فرد settled با الزامات مالی و زبان.",
   "when": {
    "goal": [
     "family"
    ],
    "rel": [
     "partner"
    ]
   },
   "sources": [
    {
     "t": "GOV.UK — Family visas",
     "u": "https://www.gov.uk/uk-family-visa"
    }
   ]
  }
 ],
 "id": "astra-uk-visa-navigator",
 "verified": "2026-10-01"
};
