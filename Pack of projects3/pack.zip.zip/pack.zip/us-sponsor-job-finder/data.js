window.APP = {
 "slug": "us-sponsor-job-finder",
 "title": "US Sponsor Job Finder",
 "subtitle": "جست‌وجوی موقعیت‌های شغلی مرتبط با sponsorship",
 "type": "jobs",
 "desc": "لینک‌های جست‌وجوی هدفمند بسازید، فایل CSV رسمی H-1B Employer Data Hub یا داده‌های افشای DOL را بارگذاری و کارفرمایان اسپانسر را جست‌وجو کنید، و درخواست‌هایتان را پیگیری کنید.",
 "sources": [
  {
   "t": "USCIS H-1B Employer Data Hub",
   "u": "https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub"
  },
  {
   "t": "DOL OFLC Performance Data (LCA/PERM disclosure)",
   "u": "https://www.dol.gov/agencies/eta/foreign-labor/performance"
  },
  {
   "t": "USCIS Working in the United States",
   "u": "https://www.uscis.gov/working-in-the-united-states"
  }
 ],
 "code": "US",
 "country": "USA",
 "jobs": {
  "qHint": "software engineer",
  "lHint": "New York, NY",
  "extra": [
   "visa sponsorship",
   "H-1B",
   "will sponsor",
   "OPT friendly",
   "cap-exempt (universities)"
  ],
  "boards": [
   {
    "t": "LinkedIn Jobs",
    "u": "https://www.linkedin.com/jobs/search/?keywords={q}&location={l}",
    "add": "visa sponsorship"
   },
   {
    "t": "Indeed",
    "u": "https://www.indeed.com/jobs?q={q}&l={l}",
    "add": "visa sponsorship"
   },
   {
    "t": "Google Jobs",
    "u": "https://www.google.com/search?q={q}+jobs+{l}&ibp=htl;jobs",
    "add": "H-1B sponsorship"
   },
   {
    "t": "Glassdoor",
    "u": "https://www.glassdoor.com/Job/jobs.htm?sc.keyword={q}",
    "add": "visa sponsorship"
   },
   {
    "t": "HigherEdJobs (cap-exempt)",
    "u": "https://www.higheredjobs.com/search/advanced_action.cfm?Keyword={q}"
   },
   {
    "t": "USCIS H-1B Employer Data Hub",
    "u": "https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub",
    "d": "داده رسمی کارفرمایان H-1B"
   }
  ],
  "csv": {
   "title": "جست‌وجو در داده رسمی کارفرمایان H-1B / LCA",
   "hint": "فایل CSV را از USCIS Employer Data Hub یا DOL Disclosure Data دانلود کنید و اینجا بارگذاری کنید؛ پردازش کاملاً داخل مرورگر انجام می‌شود.",
   "src": {
    "t": "USCIS H-1B Employer Data Hub",
    "u": "https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub"
   }
  },
  "fields": [
   {
    "id": "title",
    "l": "عنوان شغل"
   },
   {
    "id": "org",
    "l": "شرکت"
   },
   {
    "id": "loc",
    "l": "شهر"
   },
   {
    "id": "url",
    "l": "لینک"
   },
   {
    "id": "spons",
    "l": "سابقه اسپانسری (H-1B/PERM)"
   }
  ],
  "tips": [
   "سابقه اسپانسری شرکت را در داده رسمی H-1B Employer Data Hub بررسی کنید.",
   "دانشگاه‌ها و مؤسسات پژوهشی غیرانتفاعی وابسته معمولاً از سقف H-1B معاف‌اند (cap-exempt).",
   "قوانین و هزینه‌های H-1B در سال‌های اخیر تغییر کرده؛ پیش از تصمیم، صفحه رسمی USCIS را بخوانید."
  ]
 },
 "id": "astra-us-sponsor-job-finder",
 "verified": "2026-10-01"
};
