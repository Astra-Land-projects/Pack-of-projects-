# US Sponsor Job Finder

جست‌وجوی موقعیت‌های شغلی مرتبط با sponsorship

لینک‌های جست‌وجوی هدفمند بسازید، فایل CSV رسمی H-1B Employer Data Hub یا داده‌های افشای DOL را بارگذاری و کارفرمایان اسپانسر را جست‌وجو کنید، و درخواست‌هایتان را پیگیری کنید.

**نوع ابزار:** جست‌وجو + ردیاب · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- سازنده لینک جست‌وجو در چند پورتال
- جست‌وجوی CSV رسمی داخل مرورگر (در صورت وجود)
- ردیاب وضعیت با KPI
- خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS H-1B Employer Data Hub](https://www.uscis.gov/tools/reports-and-studies/h-1b-employer-data-hub)
- [DOL OFLC Performance Data (LCA/PERM disclosure)](https://www.dol.gov/agencies/eta/foreign-labor/performance)
- [USCIS Working in the United States](https://www.uscis.gov/working-in-the-united-states)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
