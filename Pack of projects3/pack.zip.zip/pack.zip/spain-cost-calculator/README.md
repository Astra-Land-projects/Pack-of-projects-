# Spain Cost Calculator

برآورد هزینه مهاجرت به اسپانیا

هزینه ویزا، tasa 790، TIE، مسکن و استقرار.

**نوع ابزار:** ماشین‌حساب هزینه · **کشور/منطقه:** Spain · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- گروه‌ها و آیتم‌های قابل ویرایش
- هزینه به ازای هر نفر
- تبدیل ارز و بافر
- نمودار گروه‌ها و خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Ministerio de Asuntos Exteriores — Visados](https://www.exteriores.gob.es/)
- [Sede Electrónica — Mercurio (immigration applications)](https://sede.administracionespublicas.gob.es/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
