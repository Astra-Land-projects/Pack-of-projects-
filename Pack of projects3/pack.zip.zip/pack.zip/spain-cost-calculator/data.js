window.APP = {
 "slug": "spain-cost-calculator",
 "title": "Spain Cost Calculator",
 "subtitle": "برآورد هزینه مهاجرت به اسپانیا",
 "type": "cost",
 "desc": "هزینه ویزا، tasa 790، TIE، مسکن و استقرار.",
 "sources": [
  {
   "t": "Ministerio de Asuntos Exteriores — Visados",
   "u": "https://www.exteriores.gob.es/"
  },
  {
   "t": "Sede Electrónica — Mercurio (immigration applications)",
   "u": "https://sede.administracionespublicas.gob.es/"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "costs": {
  "currency": "EUR",
  "alt": "USD",
  "rate": 1.08,
  "groups": [
   {
    "g": "رسمی",
    "items": [
     {
      "t": "ویزای ملی (کنسولگری؛ بسته به تابعیت)",
      "v": 80,
      "official": true,
      "per": true,
      "u": "https://www.exteriores.gob.es/"
     },
     {
      "t": "Tasa 790-012 (TIE)",
      "v": 16,
      "official": true,
      "per": true,
      "u": "https://sede.policia.gob.es/Tasa790_012/"
     },
     {
      "t": "Tasa 038 (اقامت UGE)",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://www.inclusion.gob.es/web/unidadgrandesempresas/"
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "ترجمه رسمی (traductor jurado)",
      "v": 60
     },
     {
      "t": "آپوستیل",
      "v": 30
     },
     {
      "t": "بیمه درمانی خصوصی (ماهانه)",
      "v": 60,
      "per": true
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "بلیت",
      "v": 500,
      "per": true
     },
     {
      "t": "Fianza (۱-۲ ماه)",
      "v": 2400
     },
     {
      "t": "اجاره ماه اول",
      "v": 1200
     }
    ]
   }
  ]
 },
 "id": "astra-spain-cost-calculator",
 "verified": "2026-10-01"
};
