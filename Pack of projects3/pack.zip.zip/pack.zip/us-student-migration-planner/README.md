# US Student Migration Planner

برنامه‌ریزی تحصیل ← کار ← ماندن در آمریکا (بدون ادعای تضمین)

تاریخ شروع کلاس‌ها را وارد کنید تا برنامه دقیق از تحقیق دانشگاه تا OPT ساخته شود؛ هر کار تاریخ‌دار، قابل تیک‌زدن و قابل خروجی تقویم است.

**نوع ابزار:** برنامه‌ریز زمان‌بندی‌شده · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- برنامه فازبندی‌شده نسبت به تاریخ هدف
- سناریوهای مختلف
- کارهای دلخواه، پیشرفت و ICS

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [EducationUSA](https://educationusa.state.gov/)
- [Study in the States (DHS/SEVP)](https://studyinthestates.dhs.gov/)
- [USCIS OPT for F-1 Students](https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students)
- [DS-160 Online Nonimmigrant Visa Application (CEAC)](https://ceac.state.gov/genniv/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
