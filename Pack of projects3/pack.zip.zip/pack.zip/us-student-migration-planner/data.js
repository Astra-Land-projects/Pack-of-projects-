window.APP = {
 "slug": "us-student-migration-planner",
 "title": "US Student Migration Planner",
 "subtitle": "برنامه‌ریزی تحصیل ← کار ← ماندن در آمریکا (بدون ادعای تضمین)",
 "type": "planner",
 "desc": "تاریخ شروع کلاس‌ها را وارد کنید تا برنامه دقیق از تحقیق دانشگاه تا OPT ساخته شود؛ هر کار تاریخ‌دار، قابل تیک‌زدن و قابل خروجی تقویم است.",
 "sources": [
  {
   "t": "EducationUSA",
   "u": "https://educationusa.state.gov/"
  },
  {
   "t": "Study in the States (DHS/SEVP)",
   "u": "https://studyinthestates.dhs.gov/"
  },
  {
   "t": "USCIS OPT for F-1 Students",
   "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
  },
  {
   "t": "DS-160 Online Nonimmigrant Visa Application (CEAC)",
   "u": "https://ceac.state.gov/genniv/"
  }
 ],
 "code": "US",
 "country": "USA",
 "plan": {
  "targetLabel": "تاریخ شروع برنامه (Program start date در I-20)",
  "phases": [
   {
    "name": "تحقیق و آزمون‌ها",
    "off": -540,
    "tasks": [
     "فهرست ۸ تا ۱۲ دانشگاه با رتبه و هزینه",
     {
      "t": "بررسی EducationUSA و مشاوره رایگان",
      "u": "https://educationusa.state.gov/"
     },
     "ثبت‌نام TOEFL/IELTS و در صورت نیاز GRE/GMAT"
    ]
   },
   {
    "name": "اپلای",
    "off": -400,
    "tasks": [
     "SOP و رزومه آکادمیک",
     "درخواست توصیه‌نامه‌ها",
     "ارسال اپلیکیشن‌ها و درخواست فاند/RA/TA"
    ]
   },
   {
    "name": "پذیرش و I-20",
    "off": -210,
    "tasks": [
     "مقایسه پذیرش‌ها و فاند",
     "ارسال مدارک مالی برای صدور I-20",
     "دریافت I-20"
    ]
   },
   {
    "name": "ویزا",
    "off": -150,
    "tasks": [
     {
      "t": "پرداخت SEVIS I-901",
      "u": "https://www.fmjfee.com/"
     },
     {
      "t": "تکمیل DS-160",
      "u": "https://ceac.state.gov/genniv/"
     },
     {
      "t": "رزرو وقت مصاحبه (زمان انتظار را چک کنید)",
      "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html"
     },
     "آماده‌سازی مصاحبه و مدارک"
    ]
   },
   {
    "name": "پیش از سفر",
    "off": -30,
    "tasks": [
     "بیمه سلامت دانشگاه",
     "مسکن و بلیت (ورود حداکثر ۳۰ روز قبل از شروع)",
     "کپی دیجیتال مدارک"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     {
      "t": "دریافت I-94",
      "u": "https://i94.cbp.dhs.gov/"
     },
     "Check-in با DSO دانشگاه",
     "SSN در صورت اشتغال در کمپوس"
    ]
   }
  ],
  "variants": {
   "ms": {
    "label": "ارشد دو ساله",
    "phases": [
     {
      "name": "تابستان اول: CPT/کارآموزی",
      "off": 240,
      "tasks": [
       "هماهنگی CPT با DSO",
       "کارآموزی تابستانی"
      ]
     },
     {
      "name": "OPT",
      "off": 550,
      "tasks": [
       {
        "t": "ثبت I-765 برای OPT (از ۹۰ روز پیش از پایان)",
        "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
       },
       "جست‌وجوی کار مرتبط"
      ]
     },
     {
      "name": "پس از تحصیل",
      "off": 700,
      "tasks": [
       "بررسی ثبت‌نام H-1B با کارفرما",
       "در صورت STEM: تمدید ۲۴ ماهه"
      ]
     }
    ]
   },
   "phd": {
    "label": "دکتری",
    "phases": [
     {
      "name": "سال‌های پژوهش",
      "off": 365,
      "tasks": [
       "انتشار مقاله و ساخت سابقه برای NIW/EB-1",
       "شرکت در کنفرانس‌ها"
      ]
     },
     {
      "name": "نزدیک دفاع",
      "off": 1600,
      "tasks": [
       "OPT یا H-1B (cap-exempt در دانشگاه‌ها)",
       "بررسی EB-2 NIW"
      ]
     }
    ]
   },
   "ba": {
    "label": "کارشناسی چهار ساله",
    "phases": [
     {
      "name": "سال دوم و سوم",
      "off": 400,
      "tasks": [
       "کارآموزی CPT",
       "ساخت پورتفولیو"
      ]
     },
     {
      "name": "سال آخر",
      "off": 1300,
      "tasks": [
       {
        "t": "ثبت OPT",
        "u": "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students"
       },
       "جست‌وجوی کار"
      ]
     }
    ]
   }
  }
 },
 "id": "astra-us-student-migration-planner",
 "verified": "2026-10-01"
};
