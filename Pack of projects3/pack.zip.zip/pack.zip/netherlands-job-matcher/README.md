# Netherlands Job Matcher

تطبیق رزومه با آگهی‌های هلند + بررسی sponsor

تطبیق رزومه با آگهی و یادآوری بررسی کارفرما در فهرست recognised sponsors IND.

**نوع ابزار:** تحلیل/تطبیق رزومه · **کشور/منطقه:** Netherlands · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- استخراج مهارت از دیکشنری ۱۰۰+ مهارت
- کلیدواژه‌های پرتکرار آگهی (TF)
- درصد تطابق، موارد غایب
- بررسی‌های قالب و نکات بازار

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [IND — Public register of recognised sponsors](https://ind.nl/en/public-register-recognised-sponsors)
- [Werk.nl (UWV)](https://www.werk.nl/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
