window.APP = {
 "slug": "italy-relocation-calculator",
 "title": "Italy Relocation Calculator",
 "subtitle": "برآورد هزینه انتقال به ایتالیا",
 "type": "cost",
 "desc": "هزینه ویزا، permesso، مسکن و استقرار در ایتالیا.",
 "sources": [
  {
   "t": "Polizia di Stato — Permesso di soggiorno",
   "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
  },
  {
   "t": "Visto per l'Italia — MAECI visa portal",
   "u": "https://vistoperitalia.esteri.it/"
  }
 ],
 "code": "IT",
 "country": "Italy",
 "costs": {
  "currency": "EUR",
  "alt": "USD",
  "rate": 1.08,
  "groups": [
   {
    "g": "رسمی",
    "items": [
     {
      "t": "ویزای ملی (D)",
      "v": 116,
      "official": true,
      "per": true,
      "u": "https://vistoperitalia.esteri.it/"
     },
     {
      "t": "Permesso: هزینه کارت + marca da bollo + پست",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://www.poliziadistato.it/articolo/permesso-di-soggiorno"
     },
     {
      "t": "CIMEA / DoV",
      "v": 150,
      "official": true
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "ترجمه رسمی و legalizzazione",
      "v": 50
     },
     {
      "t": "بیمه درمانی سالانه / SSN",
      "v": 150,
      "per": true
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "بلیت",
      "v": 450,
      "per": true
     },
     {
      "t": "ودیعه (cauzione)",
      "v": 2000
     },
     {
      "t": "اجاره ماه اول",
      "v": 1000
     },
     {
      "t": "Abbonamento حمل‌ونقل",
      "v": 39,
      "per": true
     }
    ]
   }
  ]
 },
 "id": "astra-italy-relocation-calculator",
 "verified": "2026-10-01"
};
