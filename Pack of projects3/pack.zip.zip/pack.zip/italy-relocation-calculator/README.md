# Italy Relocation Calculator

برآورد هزینه انتقال به ایتالیا

هزینه ویزا، permesso، مسکن و استقرار در ایتالیا.

**نوع ابزار:** ماشین‌حساب هزینه · **کشور/منطقه:** Italy · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- گروه‌ها و آیتم‌های قابل ویرایش
- هزینه به ازای هر نفر
- تبدیل ارز و بافر
- نمودار گروه‌ها و خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Polizia di Stato — Permesso di soggiorno](https://www.poliziadistato.it/articolo/permesso-di-soggiorno)
- [Visto per l'Italia — MAECI visa portal](https://vistoperitalia.esteri.it/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
