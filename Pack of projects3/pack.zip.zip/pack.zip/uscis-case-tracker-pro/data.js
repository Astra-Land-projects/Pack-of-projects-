window.APP = {
 "slug": "uscis-case-tracker-pro",
 "title": "USCIS Case Tracker Pro",
 "subtitle": "پیگیری حرفه‌ای پرونده‌ها با تاریخچه، تایم‌لاین و یادآوری",
 "type": "tracker",
 "desc": "چند پرونده را با شماره رسید ثبت کنید، هر تغییر وضعیت را با تاریخ ذخیره کنید، فاصله بین مراحل را ببینید و یادآوری تقویمی بسازید.",
 "sources": [
  {
   "t": "USCIS Case Status Online",
   "u": "https://egov.uscis.gov/"
  },
  {
   "t": "USCIS e-Request / Case Inquiry",
   "u": "https://egov.uscis.gov/e-request/Intro.do"
  },
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/"
  },
  {
   "t": "USCIS Online Account",
   "u": "https://my.uscis.gov/"
  }
 ],
 "code": "US",
 "country": "USA",
 "tracker": {
  "refLabel": "شماره رسید (Receipt Number)",
  "refHint": "۳ حرف + ۱۰ رقم، مثل IOE0912345678",
  "refRegex": "^[A-Z]{3}[0-9]{10}$",
  "statuses": [
   "Case Was Received",
   "Biometrics Appointment Was Scheduled",
   "Fingerprints Were Taken",
   "Case Is Being Actively Reviewed",
   "Request for Additional Evidence Was Sent",
   "Response To USCIS' Request For Evidence Was Received",
   "Interview Was Scheduled",
   "Interview Was Completed",
   "Case Was Approved",
   "New Card Is Being Produced",
   "Card Was Mailed To Me",
   "Card Was Delivered",
   "Case Was Transferred",
   "Case Was Denied"
  ],
  "caseTypes": [
   "I-130",
   "I-485",
   "I-765 (EAD)",
   "I-131 (Travel)",
   "I-140",
   "I-129",
   "I-539",
   "I-751",
   "I-90",
   "N-400",
   "I-526E",
   "I-821D",
   "سایر"
  ],
  "checkUrl": "https://egov.uscis.gov/"
 },
 "id": "astra-uscis-case-tracker-pro",
 "verified": "2026-10-01"
};
