# USCIS Case Tracker Pro

پیگیری حرفه‌ای پرونده‌ها با تاریخچه، تایم‌لاین و یادآوری

چند پرونده را با شماره رسید ثبت کنید، هر تغییر وضعیت را با تاریخ ذخیره کنید، فاصله بین مراحل را ببینید و یادآوری تقویمی بسازید.

**نوع ابزار:** ردیاب پرونده · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- ثبت چند پرونده با اعتبارسنجی شماره
- تاریخچه وضعیت و فاصله بین مراحل
- یادآوری، اعلان مرورگر و خروجی ICS
- ورود/خروج JSON

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS Case Status Online](https://egov.uscis.gov/)
- [USCIS e-Request / Case Inquiry](https://egov.uscis.gov/e-request/Intro.do)
- [USCIS Check Case Processing Times](https://egov.uscis.gov/processing-times/)
- [USCIS Online Account](https://my.uscis.gov/)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
