window.APP = {
 "slug": "spain-document-manager",
 "title": "Spain Document Manager",
 "subtitle": "مدیریت امن اسناد اسپانیا",
 "type": "vault",
 "desc": "NIE/TIE، empadronamiento، قراردادها و ترجمه‌ها را رمزگذاری‌شده نگه دارید و تمدیدها را پیگیری کنید.",
 "sources": [
  {
   "t": "Sede Electrónica — Mercurio (immigration applications)",
   "u": "https://sede.administracionespublicas.gob.es/"
  },
  {
   "t": "Cita Previa Extranjería",
   "u": "https://icp.administracionelectronica.gob.es/icpplus/index.html"
  }
 ],
 "code": "ES",
 "country": "Spain",
 "vault": {
  "warnDays": 90,
  "categories": [
   "Pasaporte",
   "Visado",
   "TIE/NIE",
   "Empadronamiento",
   "Contrato",
   "Antecedentes penales",
   "Seguro médico",
   "Títulos",
   "Other"
  ],
  "suggested": [
   {
    "t": "TIE",
    "cat": "TIE/NIE"
   },
   {
    "t": "Volante de empadronamiento",
    "cat": "Empadronamiento"
   },
   {
    "t": "بیمه درمانی",
    "cat": "Seguro médico"
   },
   {
    "t": "سوءپیشینه آپوستیل",
    "cat": "Antecedentes penales"
   }
  ]
 },
 "id": "astra-spain-document-manager",
 "verified": "2026-10-01"
};
