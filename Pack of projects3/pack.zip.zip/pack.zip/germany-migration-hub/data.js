window.APP = {
 "slug": "germany-migration-hub",
 "title": "Germany Migration Hub",
 "subtitle": "مرکز ابزارهای آلمان",
 "type": "hub",
 "desc": "",
 "sources": [
  {
   "t": "Make it in Germany (Federal Government portal)",
   "u": "https://www.make-it-in-germany.com/en/"
  },
  {
   "t": "Federal Foreign Office — Visa for Germany",
   "u": "https://www.auswaertiges-amt.de/en/visa-service"
  },
  {
   "t": "BAMF — Federal Office for Migration and Refugees",
   "u": "https://www.bamf.de/EN/"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "intro": "ابزارهای آلمان به Make it in Germany (پورتال رسمی دولت فدرال)، وزارت خارجه و پورتال شناسایی مدارک متصل‌اند.",
 "links": [
  {
   "slug": "germany-opportunity-card-explorer",
   "title": "Opportunity Card Explorer",
   "desc": "محاسبه امتیاز Chancenkarte (کارت فرصت)"
  },
  {
   "slug": "germany-student-planner",
   "title": "Germany Student Planner",
   "desc": "برنامه تحصیل در آلمان"
  },
  {
   "slug": "germany-job-matcher-ai",
   "title": "Germany Job Matcher AI",
   "desc": "تطبیق رزومه با آگهی‌های آلمان"
  },
  {
   "slug": "germany-document-checklist",
   "title": "Germany Document Checklist",
   "desc": "چک‌لیست مدارک ویزای آلمان"
  },
  {
   "slug": "germany-cost-calculator",
   "title": "Germany Cost Calculator",
   "desc": "برآورد هزینه مهاجرت به آلمان"
  },
  {
   "slug": "germany-residence-timeline",
   "title": "Germany Residence Timeline",
   "desc": "تایم‌لاین اقامت آلمان تا اقامت دائم/شهروندی"
  },
  {
   "slug": "germany-cv-analyzer",
   "title": "Germany CV Analyzer",
   "desc": "تحلیل رزومه برای بازار آلمان"
  }
 ],
 "facts": [
  "Opportunity Card: حداقل ۶ امتیاز یا مدرک کاملاً شناخته‌شده؛ اثبات مالی ۲۰۲۶: ۱٬۰۹۱ یورو در ماه",
  "حساب مسدود دانشجویی ۲۰۲۶: ۱۱٬۹۰۴ یورو در سال (۹۹۲ یورو در ماه)",
  "درخواست ویزای ملی در بسیاری از کشورها از طریق Consular Services Portal"
 ],
 "id": "astra-germany-migration-hub",
 "verified": "2026-10-01"
};
