#!/usr/bin/env python3
"""Official-source change monitor (Astra Global Migration).
Downloads each official page, strips markup/scripts, normalises whitespace,
hashes the text and compares with the previous run. Writes changes.json,
which can be imported into the web dashboard. Standard library only.

Usage:
  python3 monitor.py            # check all sources
  python3 monitor.py --report   # print last report
  python3 monitor.py --diff URL # show a short text diff for one source
"""
import hashlib, json, re, sys, time, difflib, html
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor

SOURCES = [
 {
  "t": "USCIS Newsroom",
  "u": "https://www.uscis.gov/newsroom",
  "cat": "USCIS"
 },
 {
  "t": "USCIS Alerts",
  "u": "https://www.uscis.gov/newsroom/alerts",
  "cat": "USCIS"
 },
 {
  "t": "USCIS Fee Schedule (G-1055)",
  "u": "https://www.uscis.gov/g-1055",
  "cat": "هزینه"
 },
 {
  "t": "USCIS Forms",
  "u": "https://www.uscis.gov/forms/all-forms",
  "cat": "فرم"
 },
 {
  "t": "USCIS Check Case Processing Times",
  "u": "https://egov.uscis.gov/processing-times/",
  "cat": "زمان پردازش"
 },
 {
  "t": "Visa Bulletin — travel.state.gov",
  "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html",
  "cat": "Visa Bulletin"
 },
 {
  "t": "U.S. Department of State — U.S. Visas",
  "u": "https://travel.state.gov/content/travel/en/us-visas.html",
  "cat": "کنسولی"
 },
 {
  "t": "Global Visa Wait Times — travel.state.gov",
  "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html",
  "cat": "کنسولی"
 },
 {
  "t": "Federal Register — USCIS documents",
  "u": "https://www.federalregister.gov/agencies/u-s-citizenship-and-immigration-services",
  "cat": "قانون"
 },
 {
  "t": "USCIS Policy Manual",
  "u": "https://www.uscis.gov/policy-manual",
  "cat": "قانون"
 }
]

HERE = Path(__file__).resolve().parent
STATE = HERE / "monitor_state.json"
REPORT = HERE / "changes.json"
UA = "Mozilla/5.0 (AstraGlobalMigration source monitor; +https://github.com/)"

def clean(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?s)<!--.*?-->", " ", raw)
    text = html.unescape(re.sub(r"(?s)<[^>]+>", " ", raw))
    text = re.sub(r"\b\d{1,2}:\d{2}(:\d{2})?\b", " ", text)  # drop clock times that change every load
    return re.sub(r"\s+", " ", text).strip()

def fetch(src):
    url = src["u"]
    try:
        with urlopen(Request(url, headers={"User-Agent": UA, "Accept-Language": "en"}), timeout=30) as r:
            body = r.read().decode(r.headers.get_content_charset() or "utf-8", "replace")
            text = clean(body)
            return url, {"status": r.status, "text": text, "hash": hashlib.sha256(text.encode()).hexdigest()}
    except Exception as e:  # network errors are reported, not fatal
        return url, {"status": 0, "error": str(e)[:200]}

def run():
    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    results = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for url, res in ex.map(fetch, SOURCES):
            src = next(s for s in SOURCES if s["u"] == url)
            prev = state.get(url, {})
            changed = bool(res.get("hash") and prev.get("hash") and prev["hash"] != res["hash"])
            if res.get("hash"):
                state[url] = {"hash": res["hash"], "checked": now, "text": res["text"][:200000],
                              "prev_text": prev.get("text", "") if changed else prev.get("prev_text", "")}
            results.append({"title": src["t"], "url": url, "cat": src.get("cat", ""), "status": res.get("status"),
                            "error": res.get("error"), "changed": changed, "first_seen": not prev, "checked": now})
            flag = "CHANGED" if changed else ("ERROR " + res.get("error", "")[:60] if res.get("error") else "ok")
            print(f"[{flag:>8}] {src['t']}")
    STATE.write_text(json.dumps(state, ensure_ascii=False))
    REPORT.write_text(json.dumps({"generated": now, "results": results}, ensure_ascii=False, indent=1))
    print(f"\n{sum(r['changed'] for r in results)} changed / {len(results)} sources -> {REPORT.name}")

def report():
    if not REPORT.exists(): print("no report yet; run without arguments first"); return
    r = json.loads(REPORT.read_text())
    print("generated:", r["generated"])
    for x in r["results"]: print(("* " if x["changed"] else "  ") + x["title"], "-", x["url"])

def diff(url):
    st = json.loads(STATE.read_text()).get(url) if STATE.exists() else None
    if not st or not st.get("prev_text"): print("no previous version stored"); return
    a, b = st["prev_text"].split(". "), st["text"].split(". ")
    for line in list(difflib.unified_diff(a, b, lineterm="", n=0))[:80]: print(line)

if __name__ == "__main__":
    if "--report" in sys.argv: report()
    elif "--diff" in sys.argv: diff(sys.argv[sys.argv.index("--diff") + 1])
    else: run()
