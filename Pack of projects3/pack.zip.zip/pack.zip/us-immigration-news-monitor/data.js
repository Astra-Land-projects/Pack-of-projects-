window.APP = {
 "slug": "us-immigration-news-monitor",
 "title": "US Immigration News Monitor",
 "subtitle": "پایش و دسته‌بندی تغییرات رسمی",
 "type": "sources",
 "desc": "منابع رسمی آمریکا با دوره بررسی مشخص پایش می‌شوند؛ اسکریپت monitor.py تغییر صفحات را با هش شناسایی می‌کند و لاگ اخبار با دسته و میزان اثر ذخیره می‌شود.",
 "sources": [
  {
   "t": "USCIS Newsroom",
   "u": "https://www.uscis.gov/newsroom"
  },
  {
   "t": "USCIS Alerts",
   "u": "https://www.uscis.gov/newsroom/alerts"
  },
  {
   "t": "Federal Register — USCIS documents",
   "u": "https://www.federalregister.gov/agencies/u-s-citizenship-and-immigration-services"
  }
 ],
 "code": "US",
 "country": "USA",
 "tags": [
  "قانون/Policy",
  "هزینه",
  "فرم جدید",
  "زمان پردازش",
  "Visa Bulletin",
  "کنسولی"
 ],
 "list": [
  {
   "t": "USCIS Newsroom",
   "u": "https://www.uscis.gov/newsroom",
   "cat": "USCIS",
   "freq": 1
  },
  {
   "t": "USCIS Alerts",
   "u": "https://www.uscis.gov/newsroom/alerts",
   "cat": "USCIS",
   "freq": 1
  },
  {
   "t": "USCIS Fee Schedule (G-1055)",
   "u": "https://www.uscis.gov/g-1055",
   "cat": "هزینه",
   "freq": 7
  },
  {
   "t": "USCIS Forms",
   "u": "https://www.uscis.gov/forms/all-forms",
   "cat": "فرم",
   "freq": 7
  },
  {
   "t": "USCIS Check Case Processing Times",
   "u": "https://egov.uscis.gov/processing-times/",
   "cat": "زمان پردازش",
   "freq": 7
  },
  {
   "t": "Visa Bulletin — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html",
   "cat": "Visa Bulletin",
   "freq": 30
  },
  {
   "t": "U.S. Department of State — U.S. Visas",
   "u": "https://travel.state.gov/content/travel/en/us-visas.html",
   "cat": "کنسولی",
   "freq": 7
  },
  {
   "t": "Global Visa Wait Times — travel.state.gov",
   "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html",
   "cat": "کنسولی",
   "freq": 7
  },
  {
   "t": "Federal Register — USCIS documents",
   "u": "https://www.federalregister.gov/agencies/u-s-citizenship-and-immigration-services",
   "cat": "قانون",
   "freq": 3
  },
  {
   "t": "USCIS Policy Manual",
   "u": "https://www.uscis.gov/policy-manual",
   "cat": "قانون",
   "freq": 7
  }
 ],
 "id": "astra-us-immigration-news-monitor",
 "verified": "2026-10-01"
};
window.MONITOR_PY = "#!/usr/bin/env python3\n\"\"\"Official-source change monitor (Astra Global Migration).\nDownloads each official page, strips markup/scripts, normalises whitespace,\nhashes the text and compares with the previous run. Writes changes.json,\nwhich can be imported into the web dashboard. Standard library only.\n\nUsage:\n  python3 monitor.py            # check all sources\n  python3 monitor.py --report   # print last report\n  python3 monitor.py --diff URL # show a short text diff for one source\n\"\"\"\nimport hashlib, json, re, sys, time, difflib, html\nfrom datetime import datetime, timezone\nfrom pathlib import Path\nfrom urllib.request import Request, urlopen\nfrom concurrent.futures import ThreadPoolExecutor\n\nSOURCES = [\n {\n  \"t\": \"USCIS Newsroom\",\n  \"u\": \"https://www.uscis.gov/newsroom\",\n  \"cat\": \"USCIS\"\n },\n {\n  \"t\": \"USCIS Alerts\",\n  \"u\": \"https://www.uscis.gov/newsroom/alerts\",\n  \"cat\": \"USCIS\"\n },\n {\n  \"t\": \"USCIS Fee Schedule (G-1055)\",\n  \"u\": \"https://www.uscis.gov/g-1055\",\n  \"cat\": \"هزینه\"\n },\n {\n  \"t\": \"USCIS Forms\",\n  \"u\": \"https://www.uscis.gov/forms/all-forms\",\n  \"cat\": \"فرم\"\n },\n {\n  \"t\": \"USCIS Check Case Processing Times\",\n  \"u\": \"https://egov.uscis.gov/processing-times/\",\n  \"cat\": \"زمان پردازش\"\n },\n {\n  \"t\": \"Visa Bulletin — travel.state.gov\",\n  \"u\": \"https://travel.state.gov/content/travel/en/legal/visa-law0/visa-bulletin.html\",\n  \"cat\": \"Visa Bulletin\"\n },\n {\n  \"t\": \"U.S. Department of State — U.S. Visas\",\n  \"u\": \"https://travel.state.gov/content/travel/en/us-visas.html\",\n  \"cat\": \"کنسولی\"\n },\n {\n  \"t\": \"Global Visa Wait Times — travel.state.gov\",\n  \"u\": \"https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/global-visa-wait-times.html\",\n  \"cat\": \"کنسولی\"\n },\n {\n  \"t\": \"Federal Register — USCIS documents\",\n  \"u\": \"https://www.federalregister.gov/agencies/u-s-citizenship-and-immigration-services\",\n  \"cat\": \"قانون\"\n },\n {\n  \"t\": \"USCIS Policy Manual\",\n  \"u\": \"https://www.uscis.gov/policy-manual\",\n  \"cat\": \"قانون\"\n }\n]\n\nHERE = Path(__file__).resolve().parent\nSTATE = HERE / \"monitor_state.json\"\nREPORT = HERE / \"changes.json\"\nUA = \"Mozilla/5.0 (AstraGlobalMigration source monitor; +https://github.com/)\"\n\ndef clean(raw: str) -> str:\n    raw = re.sub(r\"(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\\1>\", \" \", raw)\n    raw = re.sub(r\"(?s)<!--.*?-->\", \" \", raw)\n    text = html.unescape(re.sub(r\"(?s)<[^>]+>\", \" \", raw))\n    text = re.sub(r\"\\b\\d{1,2}:\\d{2}(:\\d{2})?\\b\", \" \", text)  # drop clock times that change every load\n    return re.sub(r\"\\s+\", \" \", text).strip()\n\ndef fetch(src):\n    url = src[\"u\"]\n    try:\n        with urlopen(Request(url, headers={\"User-Agent\": UA, \"Accept-Language\": \"en\"}), timeout=30) as r:\n            body = r.read().decode(r.headers.get_content_charset() or \"utf-8\", \"replace\")\n            text = clean(body)\n            return url, {\"status\": r.status, \"text\": text, \"hash\": hashlib.sha256(text.encode()).hexdigest()}\n    except Exception as e:  # network errors are reported, not fatal\n        return url, {\"status\": 0, \"error\": str(e)[:200]}\n\ndef run():\n    state = json.loads(STATE.read_text()) if STATE.exists() else {}\n    now = datetime.now(timezone.utc).isoformat(timespec=\"seconds\")\n    results = []\n    with ThreadPoolExecutor(max_workers=8) as ex:\n        for url, res in ex.map(fetch, SOURCES):\n            src = next(s for s in SOURCES if s[\"u\"] == url)\n            prev = state.get(url, {})\n            changed = bool(res.get(\"hash\") and prev.get(\"hash\") and prev[\"hash\"] != res[\"hash\"])\n            if res.get(\"hash\"):\n                state[url] = {\"hash\": res[\"hash\"], \"checked\": now, \"text\": res[\"text\"][:200000],\n                              \"prev_text\": prev.get(\"text\", \"\") if changed else prev.get(\"prev_text\", \"\")}\n            results.append({\"title\": src[\"t\"], \"url\": url, \"cat\": src.get(\"cat\", \"\"), \"status\": res.get(\"status\"),\n                            \"error\": res.get(\"error\"), \"changed\": changed, \"first_seen\": not prev, \"checked\": now})\n            flag = \"CHANGED\" if changed else (\"ERROR \" + res.get(\"error\", \"\")[:60] if res.get(\"error\") else \"ok\")\n            print(f\"[{flag:>8}] {src['t']}\")\n    STATE.write_text(json.dumps(state, ensure_ascii=False))\n    REPORT.write_text(json.dumps({\"generated\": now, \"results\": results}, ensure_ascii=False, indent=1))\n    print(f\"\\n{sum(r['changed'] for r in results)} changed / {len(results)} sources -> {REPORT.name}\")\n\ndef report():\n    if not REPORT.exists(): print(\"no report yet; run without arguments first\"); return\n    r = json.loads(REPORT.read_text())\n    print(\"generated:\", r[\"generated\"])\n    for x in r[\"results\"]: print((\"* \" if x[\"changed\"] else \"  \") + x[\"title\"], \"-\", x[\"url\"])\n\ndef diff(url):\n    st = json.loads(STATE.read_text()).get(url) if STATE.exists() else None\n    if not st or not st.get(\"prev_text\"): print(\"no previous version stored\"); return\n    a, b = st[\"prev_text\"].split(\". \"), st[\"text\"].split(\". \")\n    for line in list(difflib.unified_diff(a, b, lineterm=\"\", n=0))[:80]: print(line)\n\nif __name__ == \"__main__\":\n    if \"--report\" in sys.argv: report()\n    elif \"--diff\" in sys.argv: diff(sys.argv[sys.argv.index(\"--diff\") + 1])\n    else: run()\n";
