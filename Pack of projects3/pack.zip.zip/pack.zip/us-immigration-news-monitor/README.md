# US Immigration News Monitor

پایش و دسته‌بندی تغییرات رسمی

منابع رسمی آمریکا با دوره بررسی مشخص پایش می‌شوند؛ اسکریپت monitor.py تغییر صفحات را با هش شناسایی می‌کند و لاگ اخبار با دسته و میزان اثر ذخیره می‌شود.

**نوع ابزار:** پایش منابع رسمی · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- فهرست منابع رسمی با دوره بررسی
- وضعیت به‌روز/نیاز به بررسی/تغییر کرده
- monitor.py برای تشخیص خودکار تغییر
- لاگ اخبار با دسته و اثر

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## پایش خودکار
```bash
python3 monitor.py          # بررسی همه منابع و ساخت changes.json
python3 monitor.py --report # نمایش آخرین گزارش
```
سپس changes.json را در بخش «ورود گزارش monitor.py» وارد کنید. برای اجرای روزانه: `0 8 * * * cd /path && python3 monitor.py`

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS Newsroom](https://www.uscis.gov/newsroom)
- [USCIS Alerts](https://www.uscis.gov/newsroom/alerts)
- [Federal Register — USCIS documents](https://www.federalregister.gov/agencies/u-s-citizenship-and-immigration-services)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
