# US Immigration Cost Calculator

برآورد هزینه‌های اداری، ترجمه، سفر و سایر هزینه‌ها

هزینه‌های رسمی را از جدول USCIS/وزارت خارجه وارد کنید (پیش‌فرض‌ها صفرند تا عدد منسوخ نمایش داده نشود) و هزینه‌های جانبی تخمینی را تنظیم کنید. USCIS تعدیل تورمی برخی هزینه‌ها را از ۱۶ اکتبر ۲۰۲۶ اعلام کرده است.

**نوع ابزار:** ماشین‌حساب هزینه · **کشور/منطقه:** USA · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- گروه‌ها و آیتم‌های قابل ویرایش
- هزینه به ازای هر نفر
- تبدیل ارز و بافر
- نمودار گروه‌ها و خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [USCIS Fee Schedule (G-1055)](https://www.uscis.gov/g-1055)
- [USCIS Fee Calculator](https://www.uscis.gov/feecalculator)
- [USCIS — FY2027 inflation fee increase](https://www.uscis.gov/newsroom/alerts/uscis-announces-fy-2027-inflation-increase-for-certain-immigration-related-fees)
- [Fees for Visa Services](https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
