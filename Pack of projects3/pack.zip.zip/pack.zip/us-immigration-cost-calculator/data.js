window.APP = {
 "slug": "us-immigration-cost-calculator",
 "title": "US Immigration Cost Calculator",
 "subtitle": "برآورد هزینه‌های اداری، ترجمه، سفر و سایر هزینه‌ها",
 "type": "cost",
 "desc": "هزینه‌های رسمی را از جدول USCIS/وزارت خارجه وارد کنید (پیش‌فرض‌ها صفرند تا عدد منسوخ نمایش داده نشود) و هزینه‌های جانبی تخمینی را تنظیم کنید. USCIS تعدیل تورمی برخی هزینه‌ها را از ۱۶ اکتبر ۲۰۲۶ اعلام کرده است.",
 "sources": [
  {
   "t": "USCIS Fee Schedule (G-1055)",
   "u": "https://www.uscis.gov/g-1055"
  },
  {
   "t": "USCIS Fee Calculator",
   "u": "https://www.uscis.gov/feecalculator"
  },
  {
   "t": "USCIS — FY2027 inflation fee increase",
   "u": "https://www.uscis.gov/newsroom/alerts/uscis-announces-fy-2027-inflation-increase-for-certain-immigration-related-fees"
  },
  {
   "t": "Fees for Visa Services",
   "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html"
  }
 ],
 "code": "US",
 "country": "USA",
 "costs": {
  "currency": "USD",
  "alt": "EUR",
  "rate": 0.92,
  "groups": [
   {
    "g": "هزینه‌های رسمی",
    "items": [
     {
      "t": "هزینه فرم اصلی (مثلاً I-130 / I-140 / I-485)",
      "v": 0,
      "official": true,
      "u": "https://www.uscis.gov/g-1055"
     },
     {
      "t": "فرم‌های همراه (I-765 / I-131)",
      "v": 0,
      "official": true,
      "u": "https://www.uscis.gov/feecalculator"
     },
     {
      "t": "MRV / هزینه ویزای کنسولی",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://travel.state.gov/content/travel/en/us-visas/visa-information-resources/fees/fees-visa-services.html"
     },
     {
      "t": "SEVIS I-901 (دانشجو/J)",
      "v": 0,
      "official": true,
      "u": "https://www.fmjfee.com/"
     },
     {
      "t": "USCIS Immigrant Fee (پس از ویزای مهاجرتی)",
      "v": 0,
      "official": true,
      "per": true,
      "u": "https://www.uscis.gov/forms/filing-fees/uscis-immigrant-fee"
     }
    ]
   },
   {
    "g": "مدارک",
    "items": [
     {
      "t": "ترجمه رسمی (به ازای هر سند)",
      "v": 40
     },
     {
      "t": "ارزیابی مدرک تحصیلی (credential evaluation)",
      "v": 200
     },
     {
      "t": "معاینه پزشکی (civil surgeon / panel)",
      "v": 350,
      "per": true
     },
     {
      "t": "عکس، پست، کپی",
      "v": 60
     }
    ]
   },
   {
    "g": "سفر",
    "items": [
     {
      "t": "بلیت هواپیما",
      "v": 900,
      "per": true
     },
     {
      "t": "سفر به کشور محل مصاحبه + اقامت",
      "v": 600,
      "per": true
     },
     {
      "t": "بیمه سفر",
      "v": 80,
      "per": true
     }
    ]
   },
   {
    "g": "استقرار",
    "items": [
     {
      "t": "اجاره ماه اول + ودیعه",
      "v": 4000
     },
     {
      "t": "زندگی ۳ ماه اول",
      "v": 4500
     }
    ]
   },
   {
    "g": "خدمات حرفه‌ای (اختیاری)",
    "items": [
     {
      "t": "وکیل یا مشاور مجاز",
      "v": 0
     }
    ]
   }
  ]
 },
 "id": "astra-us-immigration-cost-calculator",
 "verified": "2026-10-01"
};
