# Netherlands Housing Search Dashboard

داشبورد جست‌وجوی مسکن هلند

جست‌وجو در پلتفرم‌های اجاره، پیگیری آگهی‌ها (قیمت، متراژ، وضعیت) و نکات ضدکلاهبرداری.

**نوع ابزار:** جست‌وجو + ردیاب · **کشور/منطقه:** Netherlands · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- سازنده لینک جست‌وجو در چند پورتال
- جست‌وجوی CSV رسمی داخل مرورگر (در صورت وجود)
- ردیاب وضعیت با KPI
- خروجی CSV

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Huurcommissie (Rent Tribunal)](https://www.huurcommissie.nl/)
- [Government.nl — Renting a house](https://www.government.nl/topics/housing/rented-housing)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
