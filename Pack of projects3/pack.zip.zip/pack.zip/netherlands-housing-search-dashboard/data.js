window.APP = {
 "slug": "netherlands-housing-search-dashboard",
 "title": "Netherlands Housing Search Dashboard",
 "subtitle": "داشبورد جست‌وجوی مسکن هلند",
 "type": "jobs",
 "desc": "جست‌وجو در پلتفرم‌های اجاره، پیگیری آگهی‌ها (قیمت، متراژ، وضعیت) و نکات ضدکلاهبرداری.",
 "sources": [
  {
   "t": "Huurcommissie (Rent Tribunal)",
   "u": "https://www.huurcommissie.nl/"
  },
  {
   "t": "Government.nl — Renting a house",
   "u": "https://www.government.nl/topics/housing/rented-housing"
  }
 ],
 "code": "NL",
 "country": "Netherlands",
 "jobs": {
  "searchTitle": "جست‌وجوی آگهی اجاره",
  "qHint": "appartement",
  "lHint": "amsterdam",
  "boards": [
   {
    "t": "Pararius",
    "u": "https://www.pararius.com/apartments/{l}"
   },
   {
    "t": "Funda (huur)",
    "u": "https://www.funda.nl/zoeken/huur?selected_area=[%22{l}%22]"
   },
   {
    "t": "Kamernet (اتاق)",
    "u": "https://kamernet.nl/en/for-rent/rooms-{l}"
   },
   {
    "t": "HousingAnywhere",
    "u": "https://housinganywhere.com/s/{l}--Netherlands"
   },
   {
    "t": "Huurcommissie — rent check",
    "u": "https://www.huurcommissie.nl/",
    "d": "بررسی منصفانه بودن اجاره"
   }
  ],
  "trackTitle": "آگهی‌های من",
  "statuses": [
   "ذخیره‌شده",
   "پیام داده شد",
   "بازدید",
   "درخواست داده شد",
   "قرارداد",
   "رد شد"
  ],
  "fields": [
   {
    "id": "title",
    "l": "آدرس/عنوان"
   },
   {
    "id": "price",
    "l": "اجاره ماهانه (EUR)",
    "type": "number"
   },
   {
    "id": "m2",
    "l": "متراژ (m²)",
    "type": "number"
   },
   {
    "id": "area",
    "l": "محله"
   },
   {
    "id": "url",
    "l": "لینک"
   }
  ],
  "tips": [
   "هرگز پیش از بازدید (حضوری یا تصویری معتبر) و قرارداد، پول واریز نکنید.",
   "مطمئن شوید آدرس امکان ثبت در شهرداری (inschrijving) دارد—برای BSN لازم است.",
   "ودیعه معمولاً حداکثر ۲ ماه اجاره پایه است (قوانین جدید)؛ از Huurcommissie بررسی کنید.",
   "مالک واقعی را از Kadaster بررسی کنید."
  ]
 },
 "id": "astra-netherlands-housing-search-dashboard",
 "verified": "2026-10-01"
};
