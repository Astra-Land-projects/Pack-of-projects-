window.APP = {
 "slug": "germany-student-planner",
 "title": "Germany Student Planner",
 "subtitle": "برنامه تحصیل در آلمان",
 "type": "planner",
 "desc": "از انتخاب برنامه در DAAD تا uni-assist، حساب مسدود (۱۱٬۹۰۴ یورو برای ۲۰۲۶)، ویزا، Anmeldung و کارت اقامت.",
 "sources": [
  {
   "t": "DAAD — Study in Germany",
   "u": "https://www.daad.de/en/"
  },
  {
   "t": "uni-assist",
   "u": "https://www.uni-assist.de/en/"
  },
  {
   "t": "Federal Foreign Office — Blocked account information",
   "u": "https://www.auswaertiges-amt.de/en/visa-service/-/2639790"
  }
 ],
 "code": "DE",
 "country": "Germany",
 "plan": {
  "targetLabel": "شروع ترم (WiSe: اکتبر، SoSe: آوریل)",
  "phases": [
   {
    "name": "تحقیق",
    "off": -420,
    "tasks": [
     {
      "t": "جست‌وجوی برنامه در DAAD International Programmes",
      "u": "https://www.daad.de/en/"
     },
     {
      "t": "بررسی anabin برای مدرک",
      "u": "https://anabin.kmk.org/"
     },
     "آزمون زبان (TestDaF/DSH یا IELTS/TOEFL)"
    ]
   },
   {
    "name": "اپلای",
    "off": -300,
    "tasks": [
     {
      "t": "ارسال از طریق uni-assist یا پورتال دانشگاه",
      "u": "https://www.uni-assist.de/en/"
     },
     "VPD در صورت نیاز",
     "انگیزه‌نامه و رزومه آلمانی"
    ]
   },
   {
    "name": "پذیرش و مالی",
    "off": -150,
    "tasks": [
     {
      "t": "افتتاح حساب مسدود (۱۱٬۹۰۴ یورو برای ۲۰۲۶)",
      "u": "https://www.auswaertiges-amt.de/en/visa-service/-/2639790"
     },
     "بیمه درمانی دانشجویی (ورود: بیمه سفر)"
    ]
   },
   {
    "name": "ویزا",
    "off": -120,
    "tasks": [
     {
      "t": "درخواست ویزای دانشجویی (Consular Services Portal)",
      "u": "https://digital.diplo.de/visa"
     },
     "مدارک: پذیرش، حساب مسدود، بیمه، مدارک تحصیلی"
    ]
   },
   {
    "name": "ورود",
    "off": 0,
    "tasks": [
     "Anmeldung ظرف ۱۴ روز",
     "Immatrikulation و Semesterticket",
     "بیمه درمانی قانونی (TK/AOK…)"
    ]
   },
   {
    "name": "ماه‌های اول",
    "off": 60,
    "tasks": [
     "درخواست کارت اقامت در Ausländerbehörde",
     "حساب بانکی جاری و Steuer-ID",
     "قواعد کار دانشجویی (روزهای مجاز در سال)"
    ]
   },
   {
    "name": "پس از فارغ‌التحصیلی",
    "off": 730,
    "tasks": [
     "اقامت جست‌وجوی کار پس از تحصیل (تا ۱۸ ماه)",
     "Blue Card یا اقامت نیروی ماهر"
    ]
   }
  ]
 },
 "id": "astra-germany-student-planner",
 "verified": "2026-10-01"
};
