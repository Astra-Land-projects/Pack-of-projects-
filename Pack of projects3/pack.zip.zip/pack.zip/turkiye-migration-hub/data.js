window.APP = {
 "slug": "turkiye-migration-hub",
 "title": "Türkiye Migration Hub",
 "subtitle": "مرکز ابزارهای مهاجرتی ترکیه",
 "type": "hub",
 "desc": "همه ابزارهای مستقل ترکیه.",
 "sources": [
  {
   "t": "Göç İdaresi Başkanlığı (Presidency of Migration Management)",
   "u": "https://www.goc.gov.tr/"
  },
  {
   "t": "e-İkamet — Residence Permit Online Application",
   "u": "https://e-ikamet.goc.gov.tr/"
  },
  {
   "t": "MFA Türkiye — Visa Information for Foreigners",
   "u": "https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa"
  }
 ],
 "code": "TR",
 "country": "Türkiye",
 "intro": "درخواست‌های اقامت در ترکیه از طریق سامانه رسمی e-İkamet ثبت می‌شوند و اداره مهاجرت درباره سایت‌های واسطه و جعلی هشدار داده است. این مجموعه برای برنامه‌ریزی، مدارک و پیگیری طراحی شده است.",
 "links": [
  {
   "slug": "turkiye-residence-explorer",
   "title": "Türkiye Residence Explorer",
   "desc": "معرفی و مقایسه انواع اقامت ترکیه"
  },
  {
   "slug": "e-ikamet-assistant",
   "title": "e-İkamet Assistant",
   "desc": "راهنمای مرحله‌به‌مرحله فرآیند آنلاین اقامت"
  },
  {
   "slug": "turkiye-residence-document-checklist",
   "title": "Türkiye Residence Document Checklist",
   "desc": "چک‌لیست مدارک اقامت ترکیه"
  },
  {
   "slug": "turkiye-residence-renewal-reminder",
   "title": "Residence Renewal Reminder",
   "desc": "یادآوری زمان تمدید اقامت"
  },
  {
   "slug": "turkiye-visa-checker",
   "title": "Türkiye Visa Checker",
   "desc": "بررسی اولیه نیاز به ویزا بر اساس تابعیت و نوع سفر"
  },
  {
   "slug": "turkiye-e-visa-assistant",
   "title": "Türkiye e-Visa Assistant",
   "desc": "راهنمای استفاده از پورتال رسمی e-Visa"
  },
  {
   "slug": "turkiye-relocation-planner",
   "title": "Türkiye Relocation Planner",
   "desc": "برنامه انتقال به ترکیه"
  },
  {
   "slug": "turkiye-cost-of-living-calculator",
   "title": "Türkiye Cost of Living Calculator",
   "desc": "مقایسه شهرها و هزینه‌های زندگی ترکیه"
  },
  {
   "slug": "turkiye-student-migration-planner",
   "title": "Türkiye Student Migration Planner",
   "desc": "تحصیل و برنامه‌ریزی زندگی دانشجویی در ترکیه"
  },
  {
   "slug": "turkiye-job-residence-matcher",
   "title": "Türkiye Job & Residence Matcher",
   "desc": "اتصال مسیر شغلی به نوع اقامت/مجوز"
  },
  {
   "slug": "turkiye-immigration-document-vault",
   "title": "Türkiye Immigration Document Vault",
   "desc": "مدیریت امن اسناد مهاجرتی ترکیه"
  },
  {
   "slug": "turkiye-immigration-scam-detector",
   "title": "Türkiye Immigration Scam Detector",
   "desc": "تشخیص سایت‌ها، دامنه‌ها و ادعاهای مشکوک"
  }
 ],
 "facts": [
  "مرجع رسمی اقامت: Göç İdaresi Başkanlığı (goc.gov.tr)",
  "ثبت درخواست اقامت: e-ikamet.goc.gov.tr",
  "e-Visa فقط از evisa.gov.tr",
  "مرکز تماس خارجیان: YİMER 157"
 ],
 "id": "astra-turkiye-migration-hub",
 "verified": "2026-10-01"
};
