# Türkiye Migration Hub

مرکز ابزارهای مهاجرتی ترکیه

همه ابزارهای مستقل ترکیه.

**نوع ابزار:** هاب کشوری · **کشور/منطقه:** Türkiye · **مجموعه:** Astra Global Migration

## قابلیت‌ها
- لینک به ابزارهای مستقل کشور

## اجرا
این پروژه مستقل است و به سرور یا build نیاز ندارد:
1. فایل `index.html` را مستقیم در مرورگر باز کنید، یا
2. `python3 -m http.server 8000` و سپس `http://localhost:8000`

داده‌های کاربر فقط در `localStorage`/`IndexedDB` همین مرورگر ذخیره می‌شود.

## ساختار
```
index.html   صفحه
style.css    استایل (RTL، حالت تاریک)
app.js       موتور ابزار (vanilla JS، بدون وابستگی)
data.js      داده و پیکربندی همین پروژه
```

## منابع رسمی
- [Göç İdaresi Başkanlığı (Presidency of Migration Management)](https://www.goc.gov.tr/)
- [e-İkamet — Residence Permit Online Application](https://e-ikamet.goc.gov.tr/)
- [MFA Türkiye — Visa Information for Foreigners](https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa)

آخرین بازبینی منابع: 2026-10-01

## سلب مسئولیت
این ابزار «مطابقت اولیه با معیارهای منتشرشده» و اطلاعات عمومی ارائه می‌دهد، نه مشاوره حقوقی یا تضمین نتیجه. همیشه با منبع رسمی تطبیق دهید.
