# Astra PhotoMedic

**Category:** Photography
**Status:** green
**Mode:** photo_medic

## Problem
Find duplicate/similar photo names using hashes and metadata fields.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10131`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
