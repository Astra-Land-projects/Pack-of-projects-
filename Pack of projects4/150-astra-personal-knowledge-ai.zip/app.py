#!/usr/bin/env python3
import sqlite3, json, re, csv, io, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

TITLE='Astra Personal Knowledge AI'
CATEGORY='Knowledge / AI'
PORT=10150
DESC='Search local notes and generate structured summaries from selected entries.'
DB='data.db'
FIELDS=[('title', 'Note title', 'text'), ('tags', 'Tags', 'text'), ('content', 'Content', 'textarea')]
MODE='personal_knowledge'

HTML='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Astra Personal Knowledge AI</title><style>body{font-family:system-ui;margin:0;background:#0b0f16;color:#e8edf5}header{padding:22px;background:#111827;position:sticky;top:0}h1{margin:0 0 6px;font-size:24px}main{max-width:1100px;margin:auto;padding:18px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.card{background:#111827;border:1px solid #263041;border-radius:14px;padding:14px;margin-bottom:14px}input,textarea{width:100%;box-sizing:border-box;padding:9px;border-radius:8px;border:1px solid #39465c;background:#0f1723;color:#fff}textarea{min-height:86px}label{font-size:12px;opacity:.8}button{padding:9px 14px;border:0;border-radius:9px;background:#d7b75b;color:#1a1a1a;font-weight:700;margin:6px 4px 0 0;cursor:pointer}.muted{opacity:.75}.table{width:100%;border-collapse:collapse;font-size:13px}.table th,.table td{border-bottom:1px solid #263041;padding:8px;text-align:left;vertical-align:top}.result{white-space:pre-wrap;background:#0a0f18;padding:12px;border-radius:10px;min-height:80px}.tag{display:inline-block;padding:3px 7px;border-radius:999px;background:#243149;margin-right:5px;font-size:11px}</style></head><body><header><main><h1>Astra Personal Knowledge AI</h1><div class="muted">Knowledge / AI · Port 10150 · Independent local MVP</div></main></header><main><div class="card"><b>Problem → solution</b><p>Search local notes and generate structured summaries from selected entries.</p><div><span class="tag">offline/local</span><span class="tag">SQLite</span><span class="tag">CSV export</span></div></div><div class="card"><h3>Add record</h3><form id="f" class="grid"><div><label>Note title</label><input id="title" type="text"></input></div><div><label>Tags</label><input id="tags" type="text"></input></div><div><label>Content</label><textarea id="content" ></textarea></div></form><button onclick="add(event)">Add</button><button onclick="analyze(event)">Run core analysis</button><button onclick="load(event)">Refresh</button><a id="csv" href="/api/export" style="color:#d7b75b;margin-left:8px">Export CSV</a></div><div class="card"><h3>Analysis</h3><div id="analysis" class="result">Ready.</div></div><div class="card"><h3>Records</h3><div id="rows" class="muted">Loading…</div></div></main><script>const fields=[["title", "Note title", "text"], ["tags", "Tags", "text"], ["content", "Content", "textarea"]];async function load(){let r=await fetch(\'/api/items\');let j=await r.json();let t=\'<table class="table"><tr>\'+fields.map(x=>\'<th>\'+x[1]+\'</th>\').join(\'\')+\'<th>Action</th></tr>\';for(let row of j.items){t+=\'<tr>\'+fields.map(x=>\'<td>\'+((row[x[0]]??\'\')).toString().replaceAll(\'<\',\'&lt;\')+\'</td>\').join(\'\')+\'<td><button onclick="del(event,\'+row.id+\')">Delete</button></td></tr>\'}t+=\'</table>\';document.getElementById(\'rows\').innerHTML=t}async function add(e){e.preventDefault();let o={};for(let x of fields)o[x[0]]=document.getElementById(x[0]).value;await fetch(\'/api/items\',{method:\'POST\',headers:{\'Content-Type\':\'application/json\'},body:JSON.stringify(o)});document.getElementById(\'f\').reset();load()}async function analyze(e){e.preventDefault();let r=await fetch(\'/api/analyze\',{method:\'POST\'});document.getElementById(\'analysis\').innerText=JSON.stringify(await r.json(),null,2)}async function del(e,id){e.preventDefault();await fetch(\'/api/items/\'+id,{method:\'DELETE\'});load()}load();</script></body></html>'

def num(v, default=0.0):
    try: return float(v)
    except: return default

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    cols=', '.join([f'"{n}" TEXT' for n,_,_ in FIELDS])
    c.execute(f'CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT,{cols})')
    c.commit(); return c

def get_rows():
    c=db(); rows=[dict(r) for r in c.execute('SELECT * FROM items ORDER BY id DESC')]; c.close(); return rows

def analyze_rows(rows):
    if not rows: return {'message':'No records yet. Add data and run the analysis.'}
    # specialized logic
    terms=' '.join(str(r.get('content','')) for r in rows); words={}
    for w in re.findall(r'[A-Za-z]{5,}',terms.lower()): words[w]=words.get(w,0)+1
    return {'notes':len(rows),'top_terms':sorted(words.items(),key=lambda x:x[1],reverse=True)[:20]}

class Handler(BaseHTTPRequestHandler):
    def _send(self, body, status=200, ctype='application/json'):
        b=body.encode() if isinstance(body,str) else body; self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def _json(self):
        n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or '{}')
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/':
            html=HTML
            self._send(html,ctype='text/html; charset=utf-8'); return
        if p=='/api/items':
            self._send(json.dumps({'items':get_rows()},ensure_ascii=False)); return
        if p=='/api/export':
            rows=get_rows(); out=io.StringIO(); w=csv.writer(out); w.writerow([n for n,_,_ in FIELDS]);
            for r in rows: w.writerow([r.get(n,'') for n,_,_ in FIELDS])
            self._send(out.getvalue(),ctype='text/csv; charset=utf-8'); return
        self._send(json.dumps({'error':'not found'}),404)
    def do_POST(self):
        p=urlparse(self.path).path
        if p=='/api/items':
            data=self._json(); c=db(); cols=[n for n,_,_ in FIELDS]; vals=[data.get(n,'') for n in cols]; marks=','.join(['?']*len(cols)); c.execute(f'INSERT INTO items ({",".join(cols)}) VALUES ({marks})',vals); c.commit(); c.close(); self._send(json.dumps({'ok':True})); return
        if p=='/api/analyze': self._send(json.dumps(analyze_rows(get_rows()),ensure_ascii=False)); return
        self._send(json.dumps({'error':'not found'}),404)
    def do_DELETE(self):
        p=urlparse(self.path).path
        m=re.match(r'/api/items/(\\d+)$',p)
        if m:
            c=db(); c.execute('DELETE FROM items WHERE id=?',(int(m.group(1)),)); c.commit(); c.close(); self._send(json.dumps({'ok':True})); return
        self._send(json.dumps({'error':'not found'}),404)
    def log_message(self, fmt,*args): pass

def self_test():
    # Use in-memory examples without modifying on-disk data
    sample=[]
    for k,_,_ in FIELDS: sample.append((k,'1' if k in ('number','') else 'test'))
    try:
        result=analyze_rows([{k:'test' for k,_,_ in FIELDS}])
        print('SELF_TEST_OK', TITLE, 'keys=', list(result)[:5]); return 0
    except Exception as e:
        print('SELF_TEST_FAIL', TITLE, repr(e)); return 1

if __name__=='__main__':
    if '--self-test' in sys.argv: raise SystemExit(self_test())
    db()
    print(f'{TITLE} running at http://127.0.0.1:{PORT}')
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
