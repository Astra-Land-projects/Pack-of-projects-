# Astra CultureBridge

**Category:** Migration / Language
**Status:** green
**Mode:** culture_bridge

## Problem
Practice common intercultural workplace and daily-life situations.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10060`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
