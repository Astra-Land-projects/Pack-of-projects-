# Astra LabFlow

**Category:** Research
**Status:** green
**Mode:** lab_flow

## Problem
Track samples, stages, owners, and overdue lab tasks.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10026`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
