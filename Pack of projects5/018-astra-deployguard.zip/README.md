# Astra DeployGuard

**Category:** DevOps
**Status:** green
**Mode:** deploy_guard

## Problem
Pre-deployment checklist with risk scoring and rollback readiness.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10018`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
