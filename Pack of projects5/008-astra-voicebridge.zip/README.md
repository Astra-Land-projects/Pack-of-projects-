# Astra VoiceBridge

**Category:** AI / Language
**Status:** yellow
**Mode:** voice_bridge

## Problem
Translate short phrases between a local phrasebook of English and Persian for basic communication.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10008`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
