# Astra AI QualityGuard

**Category:** AI
**Status:** green
**Mode:** ai_quality

## Problem
Check an AI answer for missing evidence, hedging, contradictions, and unsupported certainty.

## Run
```bash
python app.py
```
Then open `http://127.0.0.1:10003`.

## Notes
This is an independent local MVP. It uses SQLite and the Python standard library, with no package installation required.

Color meaning: green = can be used locally with minimal external dependencies; yellow = useful core exists but real-world data or domain validation may be needed; blue = advanced/simulation-oriented MVP where production-grade capability would need specialist validation, external data, or ML infrastructure.
