# Source Notebook — Project 21

Save official links and notes for information you need to verify.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8121

No third-party packages required. Data is stored in `data.db`.
