# Transport Planner — Project 19

Track driving-document research and local transportation options.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8119

No third-party packages required. Data is stored in `data.db`.
