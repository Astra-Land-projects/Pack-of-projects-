# Document Checklist — Project 04

Track document collection, expiry dates, and translation status.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8104

No third-party packages required. Data is stored in `data.db`.
