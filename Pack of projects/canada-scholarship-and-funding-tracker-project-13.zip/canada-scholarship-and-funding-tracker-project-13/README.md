# Funding Tracker — Project 13

Track scholarships, funding opportunities, and deadlines.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8113

No third-party packages required. Data is stored in `data.db`.
