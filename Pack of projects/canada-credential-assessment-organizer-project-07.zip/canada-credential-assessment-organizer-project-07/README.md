# Credential Organizer — Project 07

Organize education records and credential assessment steps.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8107

No third-party packages required. Data is stored in `data.db`.
