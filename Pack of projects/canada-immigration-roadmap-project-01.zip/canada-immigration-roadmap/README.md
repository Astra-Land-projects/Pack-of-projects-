# Canada Immigration Roadmap — Project 01 of 22

Standalone local web app for organizing personal Canada-related planning tasks. **Independent from Astra Core.** Uses only Python's standard library: no Django, Flask, Node, or third-party packages.

## Features
- Responsive dashboard and progress counters
- SQLite persistence; `roadmap.db` is created automatically
- 8 starter milestones
- Add, edit, delete, search, filter and change status
- Categories, notes and target dates
- CSV export
- JSON API endpoints
- Link to the official IRCC program explorer

## Run on Windows
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run `python app.py`
4. Open http://127.0.0.1:8000

## Run on Linux/macOS/Termux
Run `python3 app.py`, then open http://127.0.0.1:8000

No virtual environment is required. Optional Windows venv: `python -m venv .venv` then `\.venv\Scripts\Activate.ps1`.

## API
- `GET /api/health`
- `GET /api/tasks`
- `POST /api/tasks` JSON: `title` (required), `category`, `status`, `notes`, `due_date`
- `PATCH /api/tasks/<id>` JSON fields: `title`, `category`, `status`, `notes`, `due_date`
- `DELETE /api/tasks/<id>`
- `GET /api/stats`
- `GET /api/export.csv`

## Privacy and scope
Data is saved locally in `roadmap.db`. This local single-user starter has no login and should not be exposed publicly as-is. This is a planning organizer, not legal advice, an eligibility assessment, or an immigration application. Rules change; verify requirements at https://ircc.canada.ca/explore-programs/
