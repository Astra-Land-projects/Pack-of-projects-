#!/usr/bin/env python3
"""Standalone Canada Immigration Roadmap. Python standard library only."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone
import sqlite3, json, os, csv, io
ROOT=Path(__file__).resolve().parent
DB=Path(os.environ.get('ROADMAP_DB', ROOT/'roadmap.db'))
HOST=os.environ.get('HOST','127.0.0.1'); PORT=int(os.environ.get('PORT','8000'))
SEED=[
('Clarify your main goal (study, work, visit, or permanent residence)','Planning','Decide what you want to do in Canada. This app does not determine eligibility.'),
('Explore official Canadian immigration programs','Research','Use the official IRCC program explorer and confirm current requirements.'),
('Create a personal document checklist','Documents','List documents you may need and verify requirements for your chosen pathway.'),
('Set a language-learning and test-preparation goal','Language','Track language learning and research accepted tests for your pathway.'),
('Research education and credential assessment needs','Education','Check whether assessment or recognition applies to your chosen route.'),
('Estimate application and relocation expenses','Budget','Use current official fee information and build a realistic budget.'),
('Research cities, housing, and cost of living','Settlement','Compare places based on your needs and reliable current information.'),
('Review the plan and set your next check-in date','Planning','Review progress and update tasks as circumstances change.')]
def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with db() as c:
  c.execute("CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT NOT NULL DEFAULT 'Planning',status TEXT NOT NULL DEFAULT 'To do' CHECK(status IN ('To do','In progress','Done')),notes TEXT NOT NULL DEFAULT '',due_date TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")
  if c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]==0:
   now=datetime.now(timezone.utc).isoformat(timespec='seconds')
   c.executemany('INSERT INTO tasks(title,category,status,notes,created_at,updated_at) VALUES(?,?,?,?,?,?)',[(t,cat,'To do',note,now,now) for t,cat,note in SEED])
def stamp(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
class H(BaseHTTPRequestHandler):
 def send(self,code,data,typ='application/json; charset=utf-8',extra=None):
  self.send_response(code); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(data))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store')
  for k,v in (extra or {}).items(): self.send_header(k,v)
  self.end_headers(); self.wfile.write(data)
 def js(self,code,obj): self.send(code,json.dumps(obj,ensure_ascii=False).encode())
 def body(self):
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n>100000: raise ValueError()
   o=json.loads(self.rfile.read(n) or b'{}')
   if not isinstance(o,dict): raise ValueError()
   return o
  except Exception: raise ValueError('Invalid JSON request')
 def do_GET(self):
  p=urlparse(self.path).path
  files={'/':'index.html','/index.html':'index.html','/static/app.css':'app.css','/static/app.js':'app.js'}
  if p in files:
   f=ROOT/'static'/files[p]; typ='text/html; charset=utf-8' if f.suffix=='.html' else ('text/css; charset=utf-8' if f.suffix=='.css' else 'application/javascript; charset=utf-8'); return self.send(200,f.read_bytes(),typ)
  if p=='/api/health': return self.js(200,{'ok':True,'app':'Canada Immigration Roadmap'})
  if p=='/api/tasks':
   with db() as c: rows=c.execute("SELECT * FROM tasks ORDER BY CASE status WHEN 'In progress' THEN 0 WHEN 'To do' THEN 1 ELSE 2 END,id DESC").fetchall()
   return self.js(200,[dict(r) for r in rows])
  if p=='/api/stats':
   with db() as c:
    total=c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]; done=c.execute("SELECT COUNT(*) FROM tasks WHERE status='Done'").fetchone()[0]; prog=c.execute("SELECT COUNT(*) FROM tasks WHERE status='In progress'").fetchone()[0]
   return self.js(200,{'total':total,'done':done,'in_progress':prog,'percent':round(done*100/total) if total else 0})
  if p=='/api/export.csv':
   with db() as c: rows=c.execute('SELECT id,title,category,status,due_date,notes,created_at,updated_at FROM tasks ORDER BY id').fetchall()
   s=io.StringIO(); w=csv.writer(s); w.writerow(['id','title','category','status','due_date','notes','created_at','updated_at']); w.writerows([tuple(r) for r in rows])
   return self.send(200,s.getvalue().encode('utf-8-sig'),'text/csv; charset=utf-8',{'Content-Disposition':'attachment; filename="canada-roadmap.csv"'})
  return self.js(404,{'error':'Not found'})
 def do_POST(self):
  if urlparse(self.path).path!='/api/tasks': return self.js(404,{'error':'Not found'})
  try: d=self.body()
  except ValueError as e: return self.js(400,{'error':str(e)})
  title=str(d.get('title','')).strip(); status=d.get('status','To do')
  if not title or len(title)>180: return self.js(400,{'error':'Title is required (max 180 characters)'})
  if status not in ('To do','In progress','Done'): return self.js(400,{'error':'Invalid status'})
  now=stamp()
  with db() as c:
   cur=c.execute('INSERT INTO tasks(title,category,status,notes,due_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(title,str(d.get('category','Planning')).strip()[:60] or 'Planning',status,str(d.get('notes','')).strip()[:3000],str(d.get('due_date',''))[:10],now,now)); row=c.execute('SELECT * FROM tasks WHERE id=?',(cur.lastrowid,)).fetchone()
  return self.js(201,dict(row))
 def do_PATCH(self):
  p=urlparse(self.path).path.rstrip('/')
  if not p.startswith('/api/tasks/'): return self.js(404,{'error':'Not found'})
  try: tid=int(p.rsplit('/',1)[-1]); d=self.body()
  except Exception: return self.js(400,{'error':'Invalid task ID or JSON'})
  allowed={'title','category','status','notes','due_date'}
  if not d or not set(d).issubset(allowed): return self.js(400,{'error':'No valid fields supplied'})
  with db() as c:
   row=c.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone()
   if not row: return self.js(404,{'error':'Task not found'})
   v=dict(row); v.update(d); v['title']=str(v['title']).strip()
   if not v['title'] or len(v['title'])>180: return self.js(400,{'error':'Title is required (max 180 characters)'})
   if v['status'] not in ('To do','In progress','Done'): return self.js(400,{'error':'Invalid status'})
   v['category']=str(v['category']).strip()[:60] or 'Planning'; v['notes']=str(v['notes']).strip()[:3000]; v['due_date']=str(v['due_date'])[:10]; v['updated_at']=stamp()
   c.execute('UPDATE tasks SET title=?,category=?,status=?,notes=?,due_date=?,updated_at=? WHERE id=?',(v['title'],v['category'],v['status'],v['notes'],v['due_date'],v['updated_at'],tid)); updated=c.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone()
  return self.js(200,dict(updated))
 def do_DELETE(self):
  p=urlparse(self.path).path.rstrip('/')
  if not p.startswith('/api/tasks/'): return self.js(404,{'error':'Not found'})
  try: tid=int(p.rsplit('/',1)[-1])
  except ValueError: return self.js(400,{'error':'Invalid task ID'})
  with db() as c: cur=c.execute('DELETE FROM tasks WHERE id=?',(tid,))
  return self.js(200,{'deleted':tid}) if cur.rowcount else self.js(404,{'error':'Task not found'})
 def log_message(self,fmt,*args): print(fmt%args)
if __name__=='__main__':
 init(); print(f'Canada Immigration Roadmap: http://{HOST}:{PORT}'); print(f'Database: {DB}'); ThreadingHTTPServer((HOST,PORT),H).serve_forever()
