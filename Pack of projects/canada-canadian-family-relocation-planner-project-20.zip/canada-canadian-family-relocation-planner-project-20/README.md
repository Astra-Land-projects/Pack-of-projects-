# Family Relocation — Project 20

Coordinate family tasks, responsibilities, and deadlines.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8120

No third-party packages required. Data is stored in `data.db`.
