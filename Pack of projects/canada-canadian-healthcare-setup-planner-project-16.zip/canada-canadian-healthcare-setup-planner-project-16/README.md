# Healthcare Setup — Project 16

Organize research and tasks for healthcare registration after arrival.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8116

No third-party packages required. Data is stored in `data.db`.
