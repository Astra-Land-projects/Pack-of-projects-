# Housing Search — Project 10

Compare rental listings and keep notes on neighborhoods.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8110

No third-party packages required. Data is stored in `data.db`.
