# Relocation Dashboard — Project 22

Track major relocation milestones and completion status.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8122

No third-party packages required. Data is stored in `data.db`.
