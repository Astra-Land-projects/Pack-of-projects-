# Interview Practice — Project 15

Log practice interviews, questions, and improvement notes.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8115

No third-party packages required. Data is stored in `data.db`.
