# Networking CRM — Project 14

Keep contact notes and follow-up reminders for professional networking.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8114

No third-party packages required. Data is stored in `data.db`.
