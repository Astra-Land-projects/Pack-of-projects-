# Resume Builder — Project 09

Create and maintain resume sections for Canadian job applications.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8109

No third-party packages required. Data is stored in `data.db`.
