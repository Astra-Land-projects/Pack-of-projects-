# Visa Pathway Explorer — Project 02 of 22

Standalone local web application, separate from Astra Core. No third-party dependencies are required.

## Features
- Browse 8 broad pathway categories with official IRCC links
- Review pathway-specific research checklists
- Save/shortlist pathways with status
- Search pathways
- Save a planning profile (goal, province, education, language, budget)
- SQLite persistence and JSON API

## Run
Windows/macOS/Linux/Termux with Python 3.9+:
```bash
python app.py
```
Open http://127.0.0.1:8001

No venv or pip install is required. The database `pathways.db` is created automatically.

## API
`GET /api/health`, `/api/pathways`, `/api/saved`, `/api/profile`
`POST /api/saved` JSON: pathway_id, status
`DELETE /api/saved/{pathway_id}`
`POST /api/profile` JSON: goal, province, education, language, budget

## Important
This is a general research organizer, not legal advice, an eligibility assessment, or a guarantee. Pathway availability and requirements change. Verify every detail with the linked official Government of Canada pages. Local single-user app; do not expose publicly without adding appropriate security.
