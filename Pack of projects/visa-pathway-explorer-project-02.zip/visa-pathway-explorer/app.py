from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from pathlib import Path
import json, sqlite3, os
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
DB=Path(os.environ.get("VISA_DB", ROOT/"pathways.db"))
HOST=os.environ.get("HOST","127.0.0.1")
PORT=int(os.environ.get("PORT","8001"))

PATHWAYS=[
 {"id":"study","name":"Study permit pathway","type":"Temporary stay","summary":"For people planning to study at a Canadian designated learning institution. Admission and study-permit requirements must be checked separately.","checks":["Research eligible designated learning institutions (DLI) and the program","Review current study permit requirements and any provincial/territorial attestation rules","Prepare admission, identity, financial and supporting documents as applicable"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/study-canada.html"},
 {"id":"work","name":"Work permit pathway","type":"Temporary stay","summary":"For people who plan to work in Canada. Permit types and requirements depend on the job, employer, and applicable program.","checks":["Research whether the role and situation require a work permit","Check whether an employer-specific or open work permit category may apply","Review current requirements and gather supporting documents"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/work-canada.html"},
 {"id":"express-entry","name":"Express Entry","type":"Permanent residence","summary":"A system used to manage applications for certain economic immigration programs. Eligibility and selection rules vary and can change.","checks":["Review the programs managed through Express Entry","Check language testing and education credential assessment requirements, if applicable","Gather accurate work-history, education, language and identity details"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry.html"},
 {"id":"provincial","name":"Provincial Nominee Program (PNP)","type":"Permanent residence","summary":"Provinces and territories have nomination streams with distinct criteria; not every stream is open at all times.","checks":["Identify provinces or territories relevant to your goals","Check each official province/territory stream's current intake and criteria","Record any job offer, education, language or connection requirements that apply"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/provincial-nominees.html"},
 {"id":"family","name":"Family sponsorship","type":"Family-based immigration","summary":"Certain Canadian citizens and permanent residents may be able to sponsor eligible family members, subject to program rules.","checks":["Confirm whether the relationship is within an eligible sponsorship category","Review sponsor and applicant requirements on the official site","Collect relationship and identity evidence as required"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/family-sponsorship.html"},
 {"id":"visitor","name":"Visitor visa / eTA research","type":"Temporary visit","summary":"For a temporary visit. Whether a visa or eTA is required depends on factors such as nationality and travel document.","checks":["Check the official visa/eTA requirement tool for your passport and travel circumstances","Review visitor eligibility and supporting-document guidance","Plan a temporary visit and ensure the stated purpose matches the application"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/visit-canada.html"},
 {"id":"caregiver","name":"Caregiver program research","type":"Work / possible PR pathway","summary":"Caregiver immigration options can change and may have intake limits or specific eligibility rules. Verify current program availability.","checks":["Check whether a caregiver program is currently open","Review the official occupation, experience and job-offer criteria","Confirm whether the program offers temporary status, permanent residence, or another outcome"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada.html"},
 {"id":"start-business","name":"Business / entrepreneur pathway research","type":"Business immigration","summary":"Business immigration options depend on program availability and eligibility. Some programs may be paused or have changing intake rules.","checks":["Check current federal and provincial business immigration program availability","Review investment, business, language and experience criteria if applicable","Use official government pages to verify whether applications are being accepted"],"url":"https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada.html"}
]

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with db() as c:
  c.execute("""CREATE TABLE IF NOT EXISTS saved_pathways(id INTEGER PRIMARY KEY AUTOINCREMENT,pathway_id TEXT NOT NULL UNIQUE,status TEXT NOT NULL DEFAULT 'Researching',notes TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL)""")
  c.execute("""CREATE TABLE IF NOT EXISTS profile(id INTEGER PRIMARY KEY CHECK(id=1),goal TEXT NOT NULL DEFAULT '',province TEXT NOT NULL DEFAULT '',education TEXT NOT NULL DEFAULT '',language TEXT NOT NULL DEFAULT '',budget TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL)""")
  c.execute("INSERT OR IGNORE INTO profile(id,updated_at) VALUES(1,?)",(datetime.now(timezone.utc).isoformat(),))
class H(BaseHTTPRequestHandler):
 def send(self,code,obj,ctype="application/json; charset=utf-8"):
  b=obj if isinstance(obj,bytes) else json.dumps(obj,ensure_ascii=False).encode()
  self.send_response(code); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(b))); self.send_header("X-Content-Type-Options","nosniff"); self.end_headers(); self.wfile.write(b)
 def body(self):
  n=int(self.headers.get("Content-Length","0"))
  if n>50000: raise ValueError()
  x=json.loads(self.rfile.read(n) or b"{}")
  if not isinstance(x,dict): raise ValueError()
  return x
 def do_GET(self):
  p=urlparse(self.path).path
  if p=="/": return self.send(200,(ROOT/"static/index.html").read_bytes(),"text/html; charset=utf-8")
  if p=="/static/app.css": return self.send(200,(ROOT/"static/app.css").read_bytes(),"text/css; charset=utf-8")
  if p=="/static/app.js": return self.send(200,(ROOT/"static/app.js").read_bytes(),"application/javascript; charset=utf-8")
  if p=="/api/pathways": return self.send(200,PATHWAYS)
  if p=="/api/saved":
   with db() as c: rows=c.execute("SELECT * FROM saved_pathways ORDER BY id DESC").fetchall()
   return self.send(200,[dict(r) for r in rows])
  if p=="/api/profile":
   with db() as c: row=c.execute("SELECT * FROM profile WHERE id=1").fetchone()
   return self.send(200,dict(row))
  if p=="/api/health": return self.send(200,{"ok":True,"app":"Visa Pathway Explorer"})
  return self.send(404,{"error":"Not found"})
 def do_POST(self):
  p=urlparse(self.path).path
  try: data=self.body()
  except: return self.send(400,{"error":"Invalid JSON"})
  if p=="/api/saved":
   pid=str(data.get("pathway_id",""))
   if pid not in {x["id"] for x in PATHWAYS}: return self.send(400,{"error":"Unknown pathway"})
   status=str(data.get("status","Researching"))
   if status not in ("Researching","Shortlisted","Not pursuing"): return self.send(400,{"error":"Invalid status"})
   now=datetime.now(timezone.utc).isoformat()
   with db() as c:
    c.execute("INSERT INTO saved_pathways(pathway_id,status,notes,updated_at) VALUES(?,?,?,?) ON CONFLICT(pathway_id) DO UPDATE SET status=excluded.status,notes=excluded.notes,updated_at=excluded.updated_at",(pid,status,str(data.get("notes",""))[:2500],now))
    row=c.execute("SELECT * FROM saved_pathways WHERE pathway_id=?",(pid,)).fetchone()
   return self.send(201,dict(row))
  if p=="/api/profile":
   now=datetime.now(timezone.utc).isoformat()
   keys=["goal","province","education","language","budget"]
   vals=[str(data.get(k,""))[:500] for k in keys]
   with db() as c: c.execute("UPDATE profile SET goal=?,province=?,education=?,language=?,budget=?,updated_at=? WHERE id=1",(*vals,now))
   return self.send(200,{"saved":True})
  return self.send(404,{"error":"Not found"})
 def do_DELETE(self):
  p=urlparse(self.path).path
  if not p.startswith("/api/saved/"): return self.send(404,{"error":"Not found"})
  pid=p.rsplit("/",1)[-1]
  with db() as c: cur=c.execute("DELETE FROM saved_pathways WHERE pathway_id=?",(pid,))
  return self.send(200,{"deleted":pid}) if cur.rowcount else self.send(404,{"error":"Not found"})
 def log_message(self,*a): pass
if __name__=="__main__":
 init(); print(f"Visa Pathway Explorer: http://{HOST}:{PORT}"); ThreadingHTTPServer((HOST,PORT),H).serve_forever()
