from http.server import BaseHTTPRequestHandler,HTTPServer
from urllib.parse import urlparse
import json,sqlite3,os
TITLE='Language Test Tracker'; DESC='Record practice sessions, scores, and target milestones.'; SEEDS=["Listening practice", "Reading practice", "Writing practice", "Speaking practice", "Mock test"]
DB=os.path.join(os.path.dirname(__file__),'data.db')
def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init():
 with db() as c:
  c.execute("CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY,title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Not started',notes TEXT DEFAULT '',due TEXT DEFAULT '')")
  if not c.execute('SELECT COUNT(*) FROM records').fetchone()[0]: c.executemany("INSERT INTO records(title) VALUES(?)",[(x,) for x in SEEDS])
class H(BaseHTTPRequestHandler):
 def sendj(self,n,o):
  b=json.dumps(o).encode();self.send_response(n);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def body(self): return json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))) or b'{}')
 def do_GET(self):
  p=urlparse(self.path).path
  if p=='/':
   b=open(os.path.join(os.path.dirname(__file__),'index.html'),'rb').read();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
  elif p=='/api':
   with db() as c:r=[dict(x) for x in c.execute('SELECT * FROM records ORDER BY id DESC')]
   self.sendj(200,r)
  else:self.sendj(404,{'error':'Not found'})
 def do_POST(self):
  d=self.body()
  if urlparse(self.path).path!='/api':return self.sendj(404,{'error':'Not found'})
  if not d.get('title'):return self.sendj(400,{'error':'Title required'})
  with db() as c:cur=c.execute('INSERT INTO records(title,status,notes,due) VALUES(?,?,?,?)',(d['title'],d.get('status','Not started'),d.get('notes',''),d.get('due','')))
  self.sendj(201,{'id':cur.lastrowid})
 def do_PATCH(self):
  i=urlparse(self.path).path.rsplit('/',1)[-1];d=self.body();ks=[k for k in ('title','status','notes','due') if k in d]
  if not ks:return self.sendj(400,{'error':'No changes'})
  with db() as c:c.execute('UPDATE records SET '+','.join(k+'=?' for k in ks)+' WHERE id=?',[d[k] for k in ks]+[i])
  self.sendj(200,{'ok':True})
 def do_DELETE(self):
  i=urlparse(self.path).path.rsplit('/',1)[-1]
  with db() as c:c.execute('DELETE FROM records WHERE id=?',(i,))
  self.sendj(200,{'ok':True})
 def log_message(self,*a):pass
if __name__=='__main__':init();print('Open http://127.0.0.1:8106');HTTPServer(('127.0.0.1',8106),H).serve_forever()
