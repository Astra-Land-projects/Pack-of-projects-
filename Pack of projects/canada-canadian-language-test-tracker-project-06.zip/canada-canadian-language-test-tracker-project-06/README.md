# Language Test Tracker — Project 06

Record practice sessions, scores, and target milestones.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8106

No third-party packages required. Data is stored in `data.db`.
