# Finance Records — Project 18

Keep a personal log of finance-related setup tasks and records.

Standalone local web app using Python standard library and SQLite.

## Run
`python app.py` then open http://127.0.0.1:8118

No third-party packages required. Data is stored in `data.db`.
