from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
import json, sqlite3, os
DB=os.path.join(os.path.dirname(__file__),"tracker.db")
DEFAULTS=[
("Identity & documents","Check passport validity and name consistency","Not started"),
("Language","Record language test type, score, and test date","Not started"),
("Education","Collect diplomas, transcripts, and credential assessment notes","Not started"),
("Work experience","Record job titles, dates, duties, and proof available","Not started"),
("Funds","Record available funds and source-of-funds documents","Not started"),
("Family","List accompanying family members and relevant documents","Not started"),
("Medical & police","Track whether medical exam or police certificates may be required","Not started"),
("Official verification","Verify current requirements on the official IRCC website","Not started")]
def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with conn() as c:
  c.execute("""CREATE TABLE IF NOT EXISTS checks(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, item TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Not started', notes TEXT DEFAULT '', due_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
  if c.execute("SELECT COUNT(*) FROM checks").fetchone()[0]==0:
   c.executemany("INSERT INTO checks(category,item,status) VALUES(?,?,?)",DEFAULTS)
  c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
  c.execute("INSERT OR IGNORE INTO settings VALUES('pathway','Not selected')")
class Handler(BaseHTTPRequestHandler):
 def send(self,code,obj):
  data=json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
 def body(self):
  n=int(self.headers.get("Content-Length",0)); return json.loads(self.rfile.read(n) or b"{}")
 def do_GET(self):
  p=urlparse(self.path).path
  if p=="/": 
   try:
    with open(os.path.join(os.path.dirname(__file__),"index.html"),encoding="utf8") as f: data=f.read().encode()
    self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
   except Exception as e: self.send(500,{"error":str(e)})
  elif p=="/api/checks":
   with conn() as c: rows=[dict(x) for x in c.execute("SELECT * FROM checks ORDER BY id DESC")]
   self.send(200,rows)
  elif p=="/api/settings":
   with conn() as c: row=c.execute("SELECT value FROM settings WHERE key='pathway'").fetchone()
   self.send(200,{"pathway":row["value"]})
  elif p=="/api/summary":
   with conn() as c:
    total=c.execute("SELECT COUNT(*) FROM checks").fetchone()[0]
    done=c.execute("SELECT COUNT(*) FROM checks WHERE status='Verified'").fetchone()[0]
    progress=round(done*100/total) if total else 0
   self.send(200,{"total":total,"verified":done,"progress":progress})
  else: self.send(404,{"error":"Not found"})
 def do_POST(self):
  p=urlparse(self.path).path; d=self.body()
  try:
   if p=="/api/checks":
    if not d.get("category") or not d.get("item"): return self.send(400,{"error":"Category and item are required"})
    with conn() as c: cur=c.execute("INSERT INTO checks(category,item,status,notes,due_date) VALUES(?,?,?,?,?)",(d["category"],d["item"],d.get("status","Not started"),d.get("notes",""),d.get("due_date",""))); ident=cur.lastrowid
    return self.send(201,{"id":ident})
   if p=="/api/settings":
    with conn() as c: c.execute("INSERT OR REPLACE INTO settings VALUES('pathway',?)",(d.get("pathway","Not selected"),))
    return self.send(200,{"ok":True})
   self.send(404,{"error":"Not found"})
  except Exception as e: self.send(400,{"error":str(e)})
 def do_PATCH(self):
  ident=urlparse(self.path).path.rsplit("/",1)[-1]; d=self.body()
  try:
   fields=[k for k in ("category","item","status","notes","due_date") if k in d]
   if not fields: return self.send(400,{"error":"No fields"})
   with conn() as c: c.execute("UPDATE checks SET "+",".join(k+"=?" for k in fields)+" WHERE id=?",[*[d[k] for k in fields],ident])
   self.send(200,{"ok":True})
  except Exception as e: self.send(400,{"error":str(e)})
 def do_DELETE(self):
  ident=urlparse(self.path).path.rsplit("/",1)[-1]
  with conn() as c: c.execute("DELETE FROM checks WHERE id=?",(ident,))
  self.send(200,{"ok":True})
 def log_message(self,*a): pass
if __name__=="__main__":
 init(); print("Immigration Eligibility Tracker: http://127.0.0.1:8002"); HTTPServer(("127.0.0.1",8002),Handler).serve_forever()
