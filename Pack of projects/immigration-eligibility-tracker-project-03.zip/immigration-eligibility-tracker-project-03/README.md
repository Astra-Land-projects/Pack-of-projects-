# Immigration Eligibility Tracker — Project 03

A standalone local checklist app for organizing requirements to verify for a Canadian immigration pathway. It does **not** decide eligibility or provide legal advice.

## Run
Requires Python 3.9+ and no third-party packages.

```bash
python app.py
```
Open http://127.0.0.1:8002

Data is stored in `tracker.db` beside `app.py`. Stop the server with Ctrl+C.
