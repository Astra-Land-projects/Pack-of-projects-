# Product Roadmap

Astra Core project **86/100** · Domain: **Product**

A dedicated Product workspace for product roadmap.

## Project-specific functionality
- Roadmap item
- Quarter
- Owner
- Status
- Priority
- Target date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9086`.

Each project has its own folder, source files, and database file.
