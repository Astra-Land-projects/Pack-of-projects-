# Decision Matrix

Astra Core project **14/100** · Domain: **Decision**

A dedicated Decision workspace for decision matrix.

## Project-specific functionality
- Decision
- Option
- Criterion
- Score
- Weight
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9014`.

Each project has its own folder, source files, and database file.
