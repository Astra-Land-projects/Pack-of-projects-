# Data Dashboard

Astra Core project **87/100** · Domain: **Data**

A dedicated Data workspace for data dashboard.

## Project-specific functionality
- Dataset
- Source
- Rows
- Quality (%)
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9087`.

Each project has its own folder, source files, and database file.
