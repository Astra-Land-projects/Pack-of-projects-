# Backup Manager

Astra Core project **98/100** · Domain: **Infrastructure**

A dedicated Infrastructure workspace for backup manager.

## Project-specific functionality
- Resource
- Host
- Status
- Metric
- Value
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9098`.

Each project has its own folder, source files, and database file.
