# Market Research

Astra Core project **81/100** · Domain: **Business**

Capture market findings, sources, estimated size and confidence.

## Project-specific functionality
- Market / segment
- Source
- Finding
- Estimated size
- Confidence (%)
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9081`.

Each project has its own folder, source files, and database file.
