# PCB Project Manager

Astra Core project **62/100** · Domain: **Electronics**

Track board revisions, layers, layout/routing stages and manufacturing handoff.

## Project-specific functionality
- Board
- Revision
- Layers
- Status
- Gerber path
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9062`.

Each project has its own folder, source files, and database file.
