# Business Model

Astra Core project **83/100** · Domain: **Business**

A dedicated Business workspace for business model.

## Project-specific functionality
- Business model block
- Value proposition
- Customer segment
- Channel
- Cost estimate
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9083`.

Each project has its own folder, source files, and database file.
