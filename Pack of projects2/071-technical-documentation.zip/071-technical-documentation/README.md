# Technical Documentation

Astra Core project **71/100** · Domain: **Knowledge**

A dedicated Knowledge workspace for technical documentation.

## Project-specific functionality
- Knowledge item
- Topic
- Source
- Summary
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9071`.

Each project has its own folder, source files, and database file.
