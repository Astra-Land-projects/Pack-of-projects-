# Content Planner

Astra Core project **43/100** · Domain: **Content**

A dedicated Content workspace for content planner.

## Project-specific functionality
- Content piece
- Platform
- Topic
- Status
- Publish date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9043`.

Each project has its own folder, source files, and database file.
