# Job Application Tracker

Astra Core project **76/100** · Domain: **Career**

Track roles, companies, application states, priority and dates.

## Project-specific functionality
- Company
- Role
- Job URL
- Status
- Priority
- Applied date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9076`.

Each project has its own folder, source files, and database file.
