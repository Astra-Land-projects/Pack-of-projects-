# Sensor Log

Astra Core project **68/100** · Domain: **IoT**

A dedicated IoT workspace for sensor log.

## Project-specific functionality
- Device
- Sensor
- Reading
- Unit
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9068`.

Each project has its own folder, source files, and database file.
