# Logistics Planner

Astra Core project **91/100** · Domain: **Operations**

A dedicated Operations workspace for logistics planner.

## Project-specific functionality
- Operational item
- Owner
- Quantity
- Status
- Due date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9091`.

Each project has its own folder, source files, and database file.
