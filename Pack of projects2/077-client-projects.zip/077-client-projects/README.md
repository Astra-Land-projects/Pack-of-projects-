# Client Projects

Astra Core project **77/100** · Domain: **Business**

A dedicated Business workspace for client projects.

## Project-specific functionality
- Business item
- Contact / organization
- Value
- Status
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9077`.

Each project has its own folder, source files, and database file.
