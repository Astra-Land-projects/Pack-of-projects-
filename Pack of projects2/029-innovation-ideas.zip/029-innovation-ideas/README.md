# Innovation Ideas

Astra Core project **29/100** · Domain: **Innovation**

A dedicated Innovation workspace for innovation ideas.

## Project-specific functionality
- Idea
- Problem
- Solution
- Impact (1-10)
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9029`.

Each project has its own folder, source files, and database file.
