# Compliance Checklist

Astra Core project **95/100** · Domain: **Compliance**

A dedicated Compliance workspace for compliance checklist.

## Project-specific functionality
- Requirement
- Regulation
- Evidence
- Status
- Owner
- Review date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9095`.

Each project has its own folder, source files, and database file.
