# Database Explorer

Astra Core project **57/100** · Domain: **Development**

A dedicated Development workspace for database explorer.

## Project-specific functionality
- Table
- Rows
- Columns
- Schema
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9057`.

Each project has its own folder, source files, and database file.
