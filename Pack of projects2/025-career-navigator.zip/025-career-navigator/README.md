# Career Navigator

Astra Core project **25/100** · Domain: **Career**

A dedicated Career workspace for career navigator.

## Project-specific functionality
- Career target
- Organization
- Link
- Status
- Priority
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9025`.

Each project has its own folder, source files, and database file.
