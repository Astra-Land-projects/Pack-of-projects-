# Robotics Projects

Astra Core project **70/100** · Domain: **Robotics**

A dedicated Robotics workspace for robotics projects.

## Project-specific functionality
- Robot / project
- Component
- Task
- Status
- Test result
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9070`.

Each project has its own folder, source files, and database file.
