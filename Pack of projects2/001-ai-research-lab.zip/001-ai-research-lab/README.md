# AI Research Lab

Astra Core project **1/100** · Domain: **Research / AI**

Run structured AI experiments with hypotheses, datasets, findings and confidence tracking.

## Project-specific functionality
- Research question
- Method
- Dataset
- Finding
- Confidence (%)
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9001`.

Each project has its own folder, source files, and database file.
