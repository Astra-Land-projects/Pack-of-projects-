# Research Hypothesis

Astra Core project **51/100** · Domain: **Research**

A dedicated Research workspace for research hypothesis.

## Project-specific functionality
- Research item
- Source / DOI
- Summary
- Tag
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9051`.

Each project has its own folder, source files, and database file.
