# Privacy Checklist

Astra Core project **97/100** · Domain: **Privacy**

A dedicated Privacy workspace for privacy checklist.

## Project-specific functionality
- Data / privacy item
- Purpose
- Retention
- Legal basis
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9097`.

Each project has its own folder, source files, and database file.
