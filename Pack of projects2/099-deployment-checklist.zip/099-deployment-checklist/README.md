# Deployment Checklist

Astra Core project **99/100** · Domain: **DevOps**

Track deployments by environment, version and release checks.

## Project-specific functionality
- Deployment
- Environment
- Version
- Checklist item
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9099`.

Each project has its own folder, source files, and database file.
