# Air Quality Monitor

Astra Core project **38/100** · Domain: **Environment**

A dedicated Environment workspace for air quality monitor.

## Project-specific functionality
- Location
- Pollutant
- Value
- Unit
- AQI
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9038`.

Each project has its own folder, source files, and database file.
