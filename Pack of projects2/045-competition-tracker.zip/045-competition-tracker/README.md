# Competition Tracker

Astra Core project **45/100** · Domain: **Competitions**

A dedicated Competitions workspace for competition tracker.

## Project-specific functionality
- Competition
- Deadline
- Category
- Status
- Link
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9045`.

Each project has its own folder, source files, and database file.
