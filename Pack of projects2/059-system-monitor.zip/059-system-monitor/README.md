# System Monitor

Astra Core project **59/100** · Domain: **Infrastructure**

A dedicated Infrastructure workspace for system monitor.

## Project-specific functionality
- Host
- CPU (%)
- Memory (%)
- Disk (%)
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9059`.

Each project has its own folder, source files, and database file.
