# Study Sprint

Astra Core project **13/100** · Domain: **Education**

A dedicated Education workspace for study sprint.

## Project-specific functionality
- Subject / course
- Topic
- Resource
- Progress (%)
- Next step
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9013`.

Each project has its own folder, source files, and database file.
