# Customer Feedback

Astra Core project **84/100** · Domain: **Product**

Store customer feedback with sentiment, priority and follow-up date.

## Project-specific functionality
- Feedback
- Customer
- Sentiment
- Priority
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9084`.

Each project has its own folder, source files, and database file.
