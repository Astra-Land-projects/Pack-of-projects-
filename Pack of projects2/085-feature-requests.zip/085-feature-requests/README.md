# Feature Requests

Astra Core project **85/100** · Domain: **Product**

Prioritize feature requests by impact, priority and delivery state.

## Project-specific functionality
- Feature
- Problem solved
- Impact
- Priority
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9085`.

Each project has its own folder, source files, and database file.
