# Requirements Manager

Astra Core project **31/100** · Domain: **Engineering**

A dedicated Engineering workspace for requirements manager.

## Project-specific functionality
- Requirement
- Source
- Acceptance criteria
- Status
- Priority
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9031`.

Each project has its own folder, source files, and database file.
