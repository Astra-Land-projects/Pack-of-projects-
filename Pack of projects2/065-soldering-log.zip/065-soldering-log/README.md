# Soldering Log

Astra Core project **65/100** · Domain: **Electronics**

A dedicated Electronics workspace for soldering log.

## Project-specific functionality
- Soldering task
- Board
- Temperature °C
- Result
- Time (min)
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9065`.

Each project has its own folder, source files, and database file.
