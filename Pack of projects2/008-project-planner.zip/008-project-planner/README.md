# Project Planner

Astra Core project **8/100** · Domain: **Productivity**

A dedicated Productivity workspace for project planner.

## Project-specific functionality
- Task / habit
- Frequency
- Streak
- Status
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9008`.

Each project has its own folder, source files, and database file.
