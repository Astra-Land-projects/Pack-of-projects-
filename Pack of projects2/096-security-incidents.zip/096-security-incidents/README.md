# Security Incidents

Astra Core project **96/100** · Domain: **Security**

A dedicated Security workspace for security incidents.

## Project-specific functionality
- Security control / item
- Asset
- Severity
- Owner
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9096`.

Each project has its own folder, source files, and database file.
