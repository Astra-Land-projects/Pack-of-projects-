# Industry Intelligence

Astra Core project **4/100** · Domain: **Industry**

Capture industrial intelligence, issues, owners and actions for operations.

## Project-specific functionality
- Asset / area
- Issue / intelligence
- Action
- Owner
- Priority
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9004`.

Each project has its own folder, source files, and database file.
