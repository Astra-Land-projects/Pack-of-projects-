# Waste Tracker

Astra Core project **90/100** · Domain: **Environment**

A dedicated Environment workspace for waste tracker.

## Project-specific functionality
- Location
- Metric
- Value
- Unit
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9090`.

Each project has its own folder, source files, and database file.
