# Budget & Expense Tracker

Astra Core project **11/100** · Domain: **Finance**

Track income and expenses and calculate the current balance.

## Project-specific functionality
- Description
- Type
- Amount
- Category
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9011`.

Each project has its own folder, source files, and database file.
