# Automation Planner

Astra Core project **69/100** · Domain: **Automation**

A dedicated Automation workspace for automation planner.

## Project-specific functionality
- Workflow
- Trigger
- Action
- Status
- Owner
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9069`.

Each project has its own folder, source files, and database file.
