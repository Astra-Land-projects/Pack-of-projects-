# Server Checklist

Astra Core project **60/100** · Domain: **Infrastructure**

A dedicated Infrastructure workspace for server checklist.

## Project-specific functionality
- Server
- Check
- Status
- Evidence
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9060`.

Each project has its own folder, source files, and database file.
