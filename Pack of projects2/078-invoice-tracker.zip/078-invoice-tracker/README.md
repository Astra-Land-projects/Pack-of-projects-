# Invoice Tracker

Astra Core project **78/100** · Domain: **Finance**

Track invoices, clients, amounts, due dates and payment status.

## Project-specific functionality
- Invoice
- Client
- Amount
- Status
- Due date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9078`.

Each project has its own folder, source files, and database file.
