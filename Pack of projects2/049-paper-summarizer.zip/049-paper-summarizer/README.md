# Paper Summarizer

Astra Core project **49/100** · Domain: **Research / AI**

Store papers and turn abstracts into concise reusable research summaries.

## Project-specific functionality
- Paper title
- Authors
- Abstract
- Summary
- Keywords
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9049`.

Each project has its own folder, source files, and database file.
