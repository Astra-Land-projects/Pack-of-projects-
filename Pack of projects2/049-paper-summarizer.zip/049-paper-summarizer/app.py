from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
import sqlite3, json, os

PROJECT='Paper Summarizer'
DOMAIN='Research / AI'
PORT=9049
FIELDS=[{'name': 'paper', 'label': 'Paper title', 'type': 'text', 'required': True, 'choices': []}, {'name': 'authors', 'label': 'Authors', 'type': 'text', 'required': False, 'choices': []}, {'name': 'abstract', 'label': 'Abstract', 'type': 'textarea', 'required': False, 'choices': []}, {'name': 'summary', 'label': 'Summary', 'type': 'textarea', 'required': False, 'choices': []}, {'name': 'keywords', 'label': 'Keywords', 'type': 'text', 'required': False, 'choices': []}, {'name': 'date', 'label': 'Date', 'type': 'date', 'required': False, 'choices': []}]
SPECIAL='none'
BASE=os.path.dirname(__file__)
DB=os.path.join(BASE,"data.sqlite3")

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def init():
    with db() as c:
        cols=", ".join(f'"{x["name"]}" TEXT' for x in FIELDS)
        c.execute(f'CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, {cols})')

def stats():
    with db() as c:
        total=c.execute("SELECT COUNT(*) FROM records").fetchone()[0]
        done=0
        st=next((x for x in FIELDS if x["name"]=="status"),None)
        if st:
            done=c.execute("SELECT COUNT(*) FROM records WHERE status IN ('Done','Completed','Verified','Ready','Paid','Won','Published','Succeeded')").fetchone()[0]
        return {"total":total,"done":done,"open":max(total-done,0)}

class Handler(BaseHTTPRequestHandler):
    def sendj(self,code,obj):
        b=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def body(self):
        n=int(self.headers.get("Content-Length",0))
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/":
            b=open(os.path.join(BASE,"index.html"),"rb").read()
            self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b); return
        if p=="/api/config": return self.sendj(200,{"project":PROJECT,"domain":DOMAIN,"fields":FIELDS,"special":SPECIAL})
        if p=="/api/records":
            with db() as c: rows=[dict(r) for r in c.execute("SELECT * FROM records ORDER BY id DESC")]
            return self.sendj(200,rows)
        if p=="/api/stats": return self.sendj(200,stats())
        if p=="/api/health": return self.sendj(200,{"ok":True,"project":PROJECT})
        return self.sendj(404,{"error":"Not found"})
    def do_POST(self):
        p=urlparse(self.path).path; d=self.body()
        if p=="/api/records":
            for x in FIELDS:
                if x["required"] and not str(d.get(x["name"],"")).strip():
                    return self.sendj(400,{"error":x["label"]+" is required"})
            names=[x["name"] for x in FIELDS]; vals=[d.get(n,"") for n in names]
            with db() as c:
                cur=c.execute(f'INSERT INTO records({",".join(names)}) VALUES({",".join("?" for _ in names)})',vals)
            return self.sendj(201,{"id":cur.lastrowid})
        if p=="/api/special":
            action=d.get("action")
            if action=="ohms":
                v=float(d.get("voltage") or 0); i=float(d.get("current") or 0); r=float(d.get("resistance") or 0)
                out={}
                if v and i: out["resistance"]=v/i
                if v and r: out["current"]=v/r
                if i and r: out["voltage"]=i*r
                if v and i: out["power"]=v*i
                return self.sendj(200,out)
            if action=="budget":
                with db() as c:
                    inc=c.execute("SELECT COALESCE(SUM(CASE WHEN type='Income' THEN CAST(amount AS REAL) ELSE 0 END),0) FROM records").fetchone()[0]
                    exp=c.execute("SELECT COALESCE(SUM(CASE WHEN type='Expense' THEN CAST(amount AS REAL) ELSE 0 END),0) FROM records").fetchone()[0]
                return self.sendj(200,{"income":inc,"expense":exp,"balance":inc-exp})
            if action=="kpi":
                t=float(d.get("target") or 0); a=float(d.get("actual") or 0)
                return self.sendj(200,{"variance":a-t,"achievement":(a/t*100 if t else None)})
            return self.sendj(400,{"error":"Unknown special action"})
        return self.sendj(404,{"error":"Not found"})
    def do_PATCH(self):
        ident=urlparse(self.path).path.rsplit("/",1)[-1]; d=self.body()
        fields=[x["name"] for x in FIELDS if x["name"] in d]
        if not fields:return self.sendj(400,{"error":"No editable fields"})
        with db() as c: c.execute("UPDATE records SET "+",".join(f'"{x}"=?' for x in fields)+" WHERE id=?", [d[x] for x in fields]+[ident])
        return self.sendj(200,{"ok":True})
    def do_DELETE(self):
        ident=urlparse(self.path).path.rsplit("/",1)[-1]
        with db() as c:c.execute("DELETE FROM records WHERE id=?",(ident,))
        return self.sendj(200,{"ok":True})
    def log_message(self,*args): pass

if __name__=="__main__":
    init()
    print(f"{PROJECT} — http://127.0.0.1:{PORT}")
    HTTPServer(("127.0.0.1",PORT),Handler).serve_forever()
