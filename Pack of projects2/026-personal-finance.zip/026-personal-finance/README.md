# Personal Finance

Astra Core project **26/100** · Domain: **Finance**

A dedicated Finance workspace for personal finance.

## Project-specific functionality
- Account
- Type
- Amount
- Category
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9026`.

Each project has its own folder, source files, and database file.
