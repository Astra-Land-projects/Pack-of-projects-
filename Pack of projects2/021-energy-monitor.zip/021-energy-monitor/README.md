# Energy Monitor

Astra Core project **21/100** · Domain: **Energy**

A dedicated Energy workspace for energy monitor.

## Project-specific functionality
- Device
- Energy (kWh)
- Rate / kWh
- Cost
- Date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9021`.

Each project has its own folder, source files, and database file.
