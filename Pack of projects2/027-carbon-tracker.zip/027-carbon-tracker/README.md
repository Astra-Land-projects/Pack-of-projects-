# Carbon Tracker

Astra Core project **27/100** · Domain: **Environment**

A dedicated Environment workspace for carbon tracker.

## Project-specific functionality
- Activity
- Category
- Quantity
- Emission factor
- CO₂e
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9027`.

Each project has its own folder, source files, and database file.
