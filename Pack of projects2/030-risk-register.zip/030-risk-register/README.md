# Risk Register

Astra Core project **30/100** · Domain: **Management**

A dedicated Management workspace for risk register.

## Project-specific functionality
- Risk
- Impact
- Likelihood
- Mitigation
- Owner
- Review date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9030`.

Each project has its own folder, source files, and database file.
