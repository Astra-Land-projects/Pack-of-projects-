# Goal Roadmap

Astra Core project **15/100** · Domain: **Goals**

A dedicated Goals workspace for goal roadmap.

## Project-specific functionality
- Goal
- Milestone
- Progress (%)
- Deadline
- Status
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9015`.

Each project has its own folder, source files, and database file.
