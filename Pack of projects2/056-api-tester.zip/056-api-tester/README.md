# API Tester

Astra Core project **56/100** · Domain: **Development**

Record endpoint tests, expected/actual status codes and pass/fail results.

## Project-specific functionality
- Endpoint
- Method
- Expected status
- Actual status
- Result
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9056`.

Each project has its own folder, source files, and database file.
