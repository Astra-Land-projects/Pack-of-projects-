# Electronics Parts

Astra Core project **61/100** · Domain: **Electronics**

A dedicated Electronics workspace for electronics parts.

## Project-specific functionality
- Part number
- Part name
- Manufacturer
- Value / rating
- Quantity
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9061`.

Each project has its own folder, source files, and database file.
