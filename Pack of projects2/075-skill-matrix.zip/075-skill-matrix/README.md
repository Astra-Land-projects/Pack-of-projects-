# Skill Matrix

Astra Core project **75/100** · Domain: **Career**

A dedicated Career workspace for skill matrix.

## Project-specific functionality
- Skill
- Level (1-10)
- Target (1-10)
- Evidence
- Reviewed

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9075`.

Each project has its own folder, source files, and database file.
