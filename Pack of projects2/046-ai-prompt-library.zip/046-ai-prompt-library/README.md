# AI Prompt Library

Astra Core project **46/100** · Domain: **AI**

Store reusable prompts with use cases, models, versions and quality ratings.

## Project-specific functionality
- Prompt
- Use case
- Model
- Quality (1-10)
- Version
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9046`.

Each project has its own folder, source files, and database file.
