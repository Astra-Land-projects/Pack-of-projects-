# Scientific Notebook

Astra Core project **18/100** · Domain: **Research**

A dedicated Research workspace for scientific notebook.

## Project-specific functionality
- Research item
- Source / DOI
- Summary
- Tag
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9018`.

Each project has its own folder, source files, and database file.
