# Crop Yield Planner

Astra Core project **37/100** · Domain: **Agriculture**

A dedicated Agriculture workspace for crop yield planner.

## Project-specific functionality
- Field / crop
- Season
- Expected yield
- Area
- Plant/harvest date
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9037`.

Each project has its own folder, source files, and database file.
