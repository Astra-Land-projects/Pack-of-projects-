# Certificate Tracker

Astra Core project **74/100** · Domain: **Career**

Track credentials, issuers, links, status and earned dates.

## Project-specific functionality
- Certificate
- Issuer
- Topic
- Credential URL
- Status
- Earned date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9074`.

Each project has its own folder, source files, and database file.
