# Security Checklist

Astra Core project **33/100** · Domain: **Security**

A dedicated Security workspace for security checklist.

## Project-specific functionality
- Security control / item
- Asset
- Severity
- Owner
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9033`.

Each project has its own folder, source files, and database file.
