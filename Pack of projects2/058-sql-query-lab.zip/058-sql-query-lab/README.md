# SQL Query Lab

Astra Core project **58/100** · Domain: **Development**

Keep reusable SQL queries with purpose, runtime and result notes.

## Project-specific functionality
- SQL query
- Database
- Purpose
- Runtime (ms)
- Result
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9058`.

Each project has its own folder, source files, and database file.
