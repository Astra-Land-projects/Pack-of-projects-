# KPI Tracker

Astra Core project **88/100** · Domain: **Business**

A dedicated Business workspace for kpi tracker.

## Project-specific functionality
- KPI
- Target
- Actual
- Unit
- Period end
- Notes

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9088`.

Each project has its own folder, source files, and database file.
