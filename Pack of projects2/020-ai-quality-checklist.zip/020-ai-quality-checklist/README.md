# AI Quality Checklist

Astra Core project **20/100** · Domain: **AI**

A dedicated AI workspace for ai quality checklist.

## Project-specific functionality
- AI task
- Model
- Input summary
- Output summary
- Quality (1-10)
- Status
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9020`.

Each project has its own folder, source files, and database file.
