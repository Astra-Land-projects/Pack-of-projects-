# Code Lab

Astra Core project **3/100** · Domain: **Development**

Organize implementation work with language, repository, priority and delivery state.

## Project-specific functionality
- Build item
- Language
- Repository
- Status
- Priority
- Target date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9003`.

Each project has its own folder, source files, and database file.
