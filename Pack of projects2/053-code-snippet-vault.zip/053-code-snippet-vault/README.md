# Code Snippet Vault

Astra Core project **53/100** · Domain: **Development**

A dedicated Development workspace for code snippet vault.

## Project-specific functionality
- Build item
- Language
- Repository
- Status
- Priority
- Target date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9053`.

Each project has its own folder, source files, and database file.
