# AI Model Tracker

Astra Core project **47/100** · Domain: **AI**

Compare models by provider, task, context size and evaluation score.

## Project-specific functionality
- Model name
- Provider
- Primary task
- Context window
- Evaluation score
- Date

Common capabilities: local SQLite persistence, create/edit/delete, search, status filtering where applicable, CSV export, dashboard counts, and standalone execution.

## Run

Requires Python 3.9+ with no third-party packages.

```bash
python app.py
```

Open `http://127.0.0.1:9047`.

Each project has its own folder, source files, and database file.
